---
name: yz-infographic-v3-1
description: 按“娱乐资本论 Entertainment Capital”视觉规范制作文章静态信息图（A）、1080×1080 视频分解图（B）和 16 秒动效视频（C）。用于原文图片表格化、排行图、人物头像气泡、图表拆页、B 转 C 动画及相关 HTML/PNG/MP4 交付。
---

# 娱乐资本论信息图 A/B/C v3.1

## 0. 执行方式

完整阅读本文件后再工作。不要读取 SVG 路径或字体二进制；只按相对路径引用 `assets/`。A 是数据与视觉母版，B 必须由 A 拆解，C 必须复制已批准的 B 后增加动效。

优先级：用户对当前项目的明确要求 > 本文件 > HTML 模板。用户没有明确要求时不得自行覆盖规范。

只有三种结果：

- `compliant`：全部检查通过，可以交付。
- `diagnosable_failure`：缺少数据、身份、字体、Logo、浏览器或编码器，停止并说明缺项。
- `noncompliant_fallback`：使用了替代字体、文字 Logo、估算数据等回退；禁止交付。

## 1. 固定文件及用途

- `style-a.html`：900px 宽的静态信息图完整模板。
- `style-b.html`：1080×1080 分解图完整模板。
- `style-c.html`：复制 B 结构并提供 16 秒确定性动效。
- `assets/logo-icon.svg`：独立河豚图标。
- `assets/logo-text.svg`：独立“娱乐资本论 Entertainment Capital”字标。
- 三个字体文件：AliPuHui 400/700/900。
- `assets/render.mjs`：只截画布；C 逐帧生成 480 帧并编码 MP4。
- `assets/validate.py`：验证技能包或产出目录。

复制模板时只修改 `YZ_EDIT_*_BEGIN/END` 区域。不得重写字体、颜色、画布、品牌位、自检函数或时间轴。

## 2. 必须依次完成的工作

1. 阅读文章正文和全部图片，列出图片序号、标题、对象、值、单位、时间、来源及歧义。
2. 优先使用原始 CSV/表格/文档；其次使用可复制文字；再次 OCR 并人工核对；最后才可视觉估读，且必须标明“估读”，不能冒充精确值。
3. 建立 `source-data.csv`。每个视觉数字必须能回指一行数据。
4. 先做 A 的 HTML 和 PNG；确认数据、标题、比例、品牌与来源。
5. 从 A 拆 B。装不下就分为 part1、part2；不得缩字或拉成长图。
6. 从已批准的 B 复制 C。DOM、数据、标题、来源、Logo 位置保持不变，只增加元素级动效属性和引擎。
7. 运行 `assets/validate.py`，再用 `assets/render.mjs` 截图或录制。
8. 检查 A/B 静态图和 C 的 0、1.5、4.5、6、8、10、13、15.966 秒关键帧。
9. 确认文件真实存在后交付。motion HTML 不是 MP4。

## 3. 共同视觉规范

颜色固定：强调 `#fc8166`、深强调 `#e55b46`、正文 `#312e2e`、次级 `#6b6666`、灰字 `#9a9595`、分隔线 `#e7e3e1`、背景白色。

字体固定：

- Regular 400：正文与普通标签。
- Bold 700：重点、数值、表头。
- Black 900：主标题。
- 禁止 CDN 和系统字体静默替代。截图前等待 `document.fonts.ready`。

品牌固定：

- SVG 只保存两个原子部件：河豚图标和中英文字标。
- 横版 Logo 在 HTML 中用“图标在左、字标在右”组合。
- 竖版 Logo 在 HTML 中用“图标在上、字标在下”组合。
- 禁止保存或生成第三个组合 Logo SVG；禁止输入文字、emoji、色块或 CSS 图形冒充 Logo。
- 禁止阴影、无来源渐变、装饰点、英文翻译、slug、徽章和口号。

标题只出现一次，不带“图1：”等前缀。图例只保留一次；来源已经解释颜色时不重复图例。不得添加原文没有的结论。

## 4. A：静态信息图

- 画布宽 900px；按内容选择 900、1080 或 1350px 的合理高度，禁止宽高比超过约 1:1.5 的细长条。
- 标题 68px / Black；默认正文 28px；来源 26px。
- 内容区使用竖版组合 Logo 水印：容器宽约 420px、透明度 0.1、置于内容层之后但在白底之上。
- 页脚使用横版组合 Logo：整体高约 62px。
- `.chart-body` 填满可用空间；内容少时调整间距或降低到合规高度，不留大块无意义空白。
- 只截 `.chart-container`，不含页面边缘、滚动条、调试横幅或灰色背景。

## 5. B：1:1 分解图

- 画布固定 1080×1080。
- 头部标题约占 80%，右上河豚图标约占 20%；标题 48px / Black。
- 主体普通文字不得低于 40px；辅助文字不得低于 28px；来源不得低于 27px；分段号不得低于 24px。
- 默认无大水印、无底部横版 Logo。当前项目若明确要求底部 Logo，可以增加横版组合 Logo，并在交付说明中逐字记录该要求。
- 同一图拆页时保持同一标题，使用 `1/3`、`2/3`、`3/3`。
- 饼图主体至少占可用宽度约 50%；表格行过多、标签拥挤或头像超过合理数量时拆页，不缩字。

人物排行榜优先使用 3+2、2+2 或“主气泡＋卫星指标”布局。每人使用一个独立头像文件；CSS 使用 `object-fit:cover; object-position:center`。禁止 sprite、榜单截图裁脸和共享背景定位。

必须使用目标微博账号抓取时正在使用的头像，即使它是风景、插画或 Logo。用 UID、认证、简介、粉丝语境和主页共同核对同名账号。不得因为旧照片更像本人而替换当前头像。

## 6. C：由 B 生成动效

C 继承 B 的 1080×1080、字体、数据与品牌结构。固定 16.000 秒、30fps、480 帧：

```text
0–6s 入场 | 6–10s 保持 | 10–16s 按入场次序反向退出
0.0s logo | 1.5s title | 3.0s chrome | 4.5s body
```

使用 `data-yz-stage="logo|title|chrome|body"` 和以下元素级类型：

- `bubble`：头像或重点气泡弹出并轻微悬浮。
- `bar`：柱形从基线生长，原点在左侧。
- `row`：表格行或卡片逐条上移进入。
- `cell`：热力格逐格缩放点亮。
- `line`：SVG 路径按长度绘制。
- `text`：拆成词或字后逐项出现，不给整段正文一次淡入。

禁止仅对 `.chart-body` 或整个画布做淡入淡出。禁止用 `mask`、`clip-path`、覆盖层、伪中心裁切或 opacity 冲突模拟图表绘制。打开 HTML 必须自动播放，同时保留 `yzSetTime(ms)` 供逐帧录制。

## 7. 数据与头像记录示例

先复制下面表头为产出目录中的 `source-data.csv`，删除示例行后填写真实数据：

```csv
figure,part,rank,label,value,unit,source_reference,source_raw,verification_status,notes
img1,1,1,示例对象,100,次,原文图1,100,verified,删除本行
```

人物图另建 `avatar-sources.csv`：

```csv
display_name,platform,uid,profile_url,avatar_url,retrieved_at,local_file,sha256,verification_note
示例对象,微博,替换,替换,替换,替换,assets/avatars/示例对象.jpg,替换,核对认证简介和账号身份
```

账号 Cookie 只能临时用于访问，禁止写入 HTML、CSV、脚本、日志、README 或交付说明。

## 8. HTML 示例

B 的头像项使用独立图片：

```html
<article class="yz-avatar-item">
  <img class="yz-avatar" src="assets/avatars/人物名.jpg" alt="人物名">
  <strong class="yz-avatar-name">人物名</strong>
  <span class="yz-avatar-value">335 次</span>
</article>
```

C 不改上述内容，只增加逐元素属性：

```html
<article class="yz-avatar-item" data-yz-stage="body" data-yz-motion="bubble" data-yz-order="0">
  <img class="yz-avatar" src="assets/avatars/人物名.jpg" alt="人物名">
  <strong class="yz-avatar-name" data-yz-stage="body" data-yz-motion="text" data-yz-order="0">人物名</strong>
  <span class="yz-avatar-value" data-yz-stage="body" data-yz-motion="text" data-yz-order="0">335 次</span>
</article>
```

允许的显式例外用一行纯文本记录，不需要 JSON：

```text
OVERRIDE | b.footer-horizontal-logo | 用户原话：…… | 原因：当前项目明确要求
```

## 9. 文件命名和交付

- A：`img{n}-styled.html`、`img{n}-styled.png`。
- B：`img{n}-part{m}-styled.html`、`img{n}-part{m}-styled.png`。
- C：`img{n}-part{m}-motion.html`、`img{n}-part{m}.mp4`。
- 同时保留 `source-data.csv`；涉及头像时保留 `avatar-sources.csv`；有例外时保留纯文本交付说明。

PNG 和 MP4 必须只含画布。C 使用 H.264、`yuv420p`、恒定 30fps、480 帧。

## 10. 必须拒绝的情况

以下任一项出现即停止交付：

1. 字标被输入文字替代，或河豚/字标不是提供的 SVG。
2. 竖版水印用伪元素、旋转文字或组合 SVG 代替两个原子部件。
3. 字体从 CDN 加载或回退为微软雅黑、Noto Sans、Arial 等。
4. 标题含“图N：”、主体重复标题、图例重复、添加未请求装饰。
5. 为塞内容把 B 正文缩到 40px 以下，或把画布拉成长条。
6. 估算数据冒充原始值，单位、排序、时间段或来源不一致。
7. 从 sprite 裁头像，出现半脸、邻人头像、错位或错误同名账号。
8. 用旧明星照片替换当前账号的风景或插画头像。
9. C 只有整页淡入、短于 16 秒、不是 480 帧，或 HTML 被当成视频。
10. 截入画布外灰边、滚动条、调试信息或浏览器页面。
11. 缺失 HTML、PNG、MP4、来源数据或头像来源记录。
12. 任何 Cookie、令牌、授权头或会话信息进入产物。

## 11. 验证命令

验证技能包文件、资产和模板：

```powershell
python assets/validate.py
```

验证某个产出目录；报告可写到包外：

```powershell
python assets/validate.py --artifact-dir path\to\output --mode a --report validation.json
```

截图 A/B：

```powershell
node assets/render.mjs a chart.html chart.png --report browser-validation.json
```

录制 C：

```powershell
node assets/render.mjs c chart-motion.html chart.mp4 --report browser-validation.json
```

最终交付条件：验证器无失败、浏览器 `yzCheck()` 返回 `compliant`、A/B 无溢出、C 为 16秒/30fps/480帧、数据逐项匹配、品牌资产可解码、敏感信息扫描为零。
