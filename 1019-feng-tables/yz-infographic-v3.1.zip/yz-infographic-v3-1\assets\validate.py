#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,re,shutil,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXPECTED={
 'SKILL.md','README.md','style-a.html','style-b.html','style-c.html','agents/openai.yaml',
 'assets/logo-icon.svg','assets/logo-text.svg','assets/alipuhui-regular.ttf','assets/alipuhui-bold.ttf','assets/alipuhui-black.ttf','assets/render.mjs','assets/validate.py'}
SECRETS={
 'cookie-header':re.compile('Netscape HTTP'+' Cookie File',re.I),
 'weibo-cookie':re.compile(r'(?:^|[;\s])SUBP?\s*[=\t]',re.I|re.M),
 'authorization':re.compile(r'authorization\s*:\s*(?:bearer|basic)\s+\S+',re.I)}

def add(items,name,ok,detail=''):items.append({'check':name,'ok':bool(ok),'detail':detail})
def done(scope,items):
 bad=[x for x in items if not x['ok']]
 return {'contract':'YZ-INFOGRAPHIC-V3.1','scope':scope,'state':'compliant' if not bad else 'diagnosable_failure','summary':{'passed':len(items)-len(bad),'failed':len(bad)},'checks':items}
def package():
 q=[];actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
 add(q,'exact-file-set',actual==EXPECTED,'missing='+str(sorted(EXPECTED-actual))+' extra='+str(sorted(actual-EXPECTED)))
 for name in EXPECTED:add(q,'exists:'+name,(ROOT/name).is_file())
 for name,min_size in [('assets/logo-icon.svg',100000),('assets/logo-text.svg',10000)]:
  p=ROOT/name;s=p.read_text(encoding='utf-8',errors='ignore') if p.is_file() else ''
  add(q,'atomic-svg:'+name,p.is_file() and p.stat().st_size>min_size and s.count('<svg')==1 and '<image' not in s,f'bytes={p.stat().st_size if p.exists() else 0}')
 for name in ['assets/alipuhui-regular.ttf','assets/alipuhui-bold.ttf','assets/alipuhui-black.ttf']:
  p=ROOT/name;add(q,'font:'+name,p.is_file() and p.stat().st_size>1000000,f'bytes={p.stat().st_size if p.exists() else 0}')
 tokens={'style-a.html':['data-yz-mode="a"','width:900px','font-size:68px','brand--vertical','brand--horizontal','logo-icon.svg','logo-text.svg'],
 'style-b.html':['data-yz-mode="b"','width:1080px','height:1080px','font-size:48px','logo-icon.svg','data-yz-footer-logo="none"'],
 'style-c.html':['data-yz-mode="c"','duration:16000','fps:30','frames:480','yzSetTime','data-yz-motion']}
 for name,need in tokens.items():
  s=(ROOT/name).read_text(encoding='utf-8') if (ROOT/name).is_file() else ''
  for token in need:add(q,f'token:{name}:{token}',token in s)
  add(q,'offline:'+name,not re.search(r'(?:src|href)=["\']https?://',s,re.I))
 for p in ROOT.rglob('*'):
  if not p.is_file() or p.suffix.lower() in {'.ttf','.pyc'}:continue
  s=p.read_text(encoding='utf-8',errors='ignore')
  for label,pattern in SECRETS.items():add(q,f'secret:{p.relative_to(ROOT)}:{label}',not pattern.search(s))
 return done('package',q)
def probe(path,exe):
 cmd=[exe,'-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames,r_frame_rate,duration','-of','json',str(path)]
 return json.loads(subprocess.run(cmd,check=True,capture_output=True,text=True).stdout)['streams'][0]
def artifact(folder,mode,ffprobe):
 q=[];html=sorted(folder.glob('*.html'));png=sorted(folder.glob('*.png'));mp4=sorted(folder.glob('*.mp4'));data=folder/'source-data.csv'
 add(q,'source-data.csv',data.is_file());rows=[]
 if data.is_file():
  try:
   with data.open('r',encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
   add(q,'source-data-readable',bool(rows),f'rows={len(rows)}')
  except Exception as e:add(q,'source-data-readable',False,str(e))
 add(q,'html-output',bool(html),f'count={len(html)}');add(q,'png-output',bool(png),f'count={len(png)}')
 if mode=='c':add(q,'mp4-output',bool(mp4),f'count={len(mp4)}')
 avatars=False
 for p in html:
  s=p.read_text(encoding='utf-8',errors='ignore');avatars|='.yz-avatar' in s
  add(q,'contract:'+p.name,f'data-yz-mode="{mode}"' in s and 'data-yz-contract="3.1.0"' in s)
  add(q,'offline:'+p.name,not re.search(r'(?:src|href)=["\']https?://',s,re.I))
  add(q,'placeholders:'+p.name,not re.search(r'【(?:TITLE|CHART_BODY|SOURCE|PART)_HERE】',s))
  add(q,'title-prefix:'+p.name,not re.search(r'<h1[^>]*>\s*图\s*\d+\s*[：:]',s,re.I))
  add(q,'sprite:'+p.name,'data-sprite' not in s and 'sprite-position' not in s)
  add(q,'external-font:'+p.name,'cdn.jsdelivr.net' not in s and 'fonts.googleapis.com' not in s)
  if mode=='c':add(q,'timeline:'+p.name,all(x in s for x in ['duration:16000','fps:30','frames:480','yzSetTime']))
  for label,pattern in SECRETS.items():add(q,f'secret:{p.name}:{label}',not pattern.search(s))
 if avatars:add(q,'avatar-sources.csv',(folder/'avatar-sources.csv').is_file())
 if mode=='c' and mp4:
  exe=shutil.which(ffprobe) or (ffprobe if Path(ffprobe).is_file() else None);add(q,'ffprobe',bool(exe))
  if exe:
   for p in mp4:
    try:
     v=probe(p,exe);frames=int(v.get('nb_read_frames') or 0);rate=v.get('r_frame_rate');duration=float(v.get('duration') or 0)
     add(q,'video:'+p.name,frames==480 and rate=='30/1' and abs(duration-16)<.05,f'{frames} frames {rate} {duration}s')
    except Exception as e:add(q,'video:'+p.name,False,str(e))
 return done('artifact-'+mode,q)
def main():
 p=argparse.ArgumentParser();p.add_argument('--artifact-dir',type=Path);p.add_argument('--mode',choices='abc');p.add_argument('--report',type=Path);p.add_argument('--ffprobe',default='ffprobe');a=p.parse_args()
 if bool(a.artifact_dir)!=bool(a.mode):p.error('--artifact-dir 与 --mode 必须同时使用')
 r=artifact(a.artifact_dir.resolve(),a.mode,a.ffprobe) if a.artifact_dir else package()
 if a.report:a.report.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['state']=='compliant' else 1
if __name__=='__main__':sys.exit(main())
