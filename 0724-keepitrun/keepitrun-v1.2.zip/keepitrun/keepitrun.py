#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
keepitrun - 定时任务调度脚本 (Windows 11 / 跨平台常驻)
版本: 1.2 (2026-06-11)
基于: keepitrun-260424.py (v1.0)

每日定时任务:
  02:00  RSS 抓取 (第1次)
  14:00  RSS 抓取 (第2次)
  14:05  合并两次 RSS 抓取结果，去重翻译输出
  15:00  Photos 自动同步 (仅当脚本文件存在时启用)
  10:10  爬取最新 blog (微信公众号合集) (v1.2 重新启用)

已禁用任务 (v1.2):
  10:05  爬取最新 daily (微信公众号AIGC早报) — 脚本已移至 disabled/
  12:00  Unsplash 自动上传 — 外部脚本暂不可用，已禁用

v1.2 变更 (2026-06-11):
  - 重新启用微信公众号文章抓取 (10:10)
  - 使用合集API替代公众平台后台Cookie登录 (convert_blog.py v3.0)
  - 无需Cookie即可抓取文章列表

异常处理:
  - 若某次 RSS 抓取因脚本未启动而缺失，14:05 时自动补抓
  - 输出成功后，将之前的 RSS 抓取结果移至 /archived 子文件夹

日志与清理:
  - 所有操作记录到 logs/ 子文件夹
  - 临时文件存放于 tmp/ 子文件夹
  - 分级自动清理:
    · tmp/   中超过 1 天的文件 → 自动删除
    · logs/  中超过 7 天的日志 → 移入 logs/archive/
    · logs/archive/ 中超过 30 天的日志 → 自动删除
    · archived/ 中超过 30 天的文件 → 自动删除

用法:
  python keepitrun.py
  (常驻运行，通过 while True 循环每 30 秒检查一次时间)
"""

import time
import re
import subprocess
import os
import sys
import shutil
import glob
import logging
import threading
from datetime import date, datetime, timedelta

# ═══════════════════════════════════════════════════════════════
# 版本信息
# ═══════════════════════════════════════════════════════════════

VERSION = "1.2"
VERSION_DATE = "2026-06-11"

# ═══════════════════════════════════════════════════════════════
# 配置区域
# ═══════════════════════════════════════════════════════════════

# 脚本所在目录（所有子脚本也在此目录）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 子脚本文件名 (v1.1 已去除文件名中的时间戳)
RSS_SCRIPT = "getrss.py"
COMBINE_SCRIPT = "combine-gemini.py"

# 已重新启用的子脚本 (v1.2: 微信公众号合集抓取已恢复)
BLOG_SCRIPT = "convert_blog.py"  # v3.0: 使用合集API，无需Cookie

# 仍禁用的子脚本
# DAILY_SCRIPT = "convert_daily.py"  # 每日早报由 convert_daily 独立运行

# RSS 抓取结果文件匹配模式
RSS_FILE_PATTERN = "rss_*.md"

# 子目录
ARCHIVED_DIR = os.path.join(SCRIPT_DIR, "archived")
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
LOG_ARCHIVE_DIR = os.path.join(LOG_DIR, "archive")
TMP_DIR = os.path.join(SCRIPT_DIR, "tmp")

# 清理阈值 (天)
TMP_RETENTION_DAYS = 1       # tmp/ 中文件保留 1 天
LOG_ARCHIVE_DAYS = 7         # logs/ 中文件 7 天后移入 archive
LOG_DELETE_DAYS = 30         # logs/archive/ 中文件 30 天后删除
ARCHIVED_RETENTION_DAYS = 30 # archived/ 中文件保留 30 天

# 上次成功 blog 爬取日期记录文件 (v1.2 重新启用)
BLOG_LAST_CRAWL_FILE = os.path.join(SCRIPT_DIR, "last_blog_crawl.txt")

# Unsplash 上传脚本路径 (v1.1 已禁用)
# 重新启用时，将脚本路径填入下方并取消 unsplash 相关代码的注释
# UNSPLASH_SCRIPT = r"C:\Users\james\Downloads\unsplash\unsplash_update.py"
# UNSPLASH_LAST_RUN_FILE = os.path.join(SCRIPT_DIR, "last_unsplash_run.txt")
# UNSPLASH_INTERVAL_DAYS = 3

# Photos 同步脚本路径
# 搜索顺序: 1. 同目录下的 photos_update.py  2. 同级 photos_update/ 文件夹  3. 自定义绝对路径

def _resolve_photos_path():
    """解析 Photos 同步脚本路径，按优先级搜索多个可能位置"""
    # 1. 同目录下
    local = os.path.join(SCRIPT_DIR, "photos_update.py")
    if os.path.isfile(local):
        return local
    # 2. 同级 photos_update/ 文件夹
    sibling = os.path.join(SCRIPT_DIR, "..", "photos_update", "photos_update.py")
    if os.path.isfile(sibling):
        return os.path.abspath(sibling)
    # 3. 常见 Windows 路径 (可按需修改)
    win_path = os.path.join(os.path.expanduser("~"), "Dropbox", "WORKS", "SOFT", "AI-Python", "photos_update", "photos_update.py")
    if os.path.isfile(win_path):
        return win_path
    return ""

PHOTOS_UPDATE_SCRIPT = _resolve_photos_path()

# 每日首次启动标记文件
DAILY_BOOT_FLAG = os.path.join(LOG_DIR, ".boot_flag")

# 时间检查间隔（秒）
CHECK_INTERVAL = 30

# ═══════════════════════════════════════════════════════════════
# 日志系统
# ═══════════════════════════════════════════════════════════════

def setup_logging():
    """初始化日志系统：文件+控制台，统一存放于 logs/ 目录"""
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(LOG_ARCHIVE_DIR, exist_ok=True)

    log_name = datetime.now().strftime("%Y%m%d") + ".log"
    log_path = os.path.join(LOG_DIR, log_name)

    logger = logging.getLogger("keepitrun")
    # 防止重复添加 handler
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 文件 handler（追加模式，同一天同一文件）
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    # 控制台 handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


def cleanup_tmp(logger):
    """删除 tmp/ 中超过 TMP_RETENTION_DAYS 天的文件

    tmp/ 目录存放 RSS 抓取中间结果等临时文件，
    超过 1 天的文件可安全删除（已被合并或归档）。
    """
    if not os.path.isdir(TMP_DIR):
        return

    cutoff = datetime.now() - timedelta(days=TMP_RETENTION_DAYS)
    deleted = 0

    for f in os.listdir(TMP_DIR):
        filepath = os.path.join(TMP_DIR, f)
        if not os.path.isfile(filepath):
            continue
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            if mtime < cutoff:
                os.remove(filepath)
                deleted += 1
        except OSError:
            continue

    if deleted > 0:
        logger.info(f"tmp/ 清理: 删除了 {deleted} 个超过 {TMP_RETENTION_DAYS} 天的临时文件")


def cleanup_logs(logger):
    """分级清理日志:
    1. logs/ 中超过 LOG_ARCHIVE_DAYS 天的日志 → 移入 logs/archive/
    2. logs/archive/ 中超过 LOG_DELETE_DAYS 天的日志 → 删除
    """
    os.makedirs(LOG_ARCHIVE_DIR, exist_ok=True)

    # 阶段1: 移动旧日志到 archive
    if os.path.isdir(LOG_DIR):
        archive_cutoff = datetime.now() - timedelta(days=LOG_ARCHIVE_DAYS)
        moved = 0

        for log_file in glob.glob(os.path.join(LOG_DIR, "*.log")):
            # 跳过 archive 子目录中的文件
            if LOG_ARCHIVE_DIR in log_file:
                continue
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(log_file))
                if mtime < archive_cutoff:
                    dest = os.path.join(LOG_ARCHIVE_DIR, os.path.basename(log_file))
                    # 避免覆盖同名文件
                    if os.path.exists(dest):
                        base, ext = os.path.splitext(os.path.basename(log_file))
                        dest = os.path.join(LOG_ARCHIVE_DIR, f"{base}_{int(time.time())}{ext}")
                    shutil.move(log_file, dest)
                    moved += 1
            except OSError:
                continue

        if moved > 0:
            logger.info(f"日志归档: 移动了 {moved} 个超过 {LOG_ARCHIVE_DAYS} 天的日志到 logs/archive/")

    # 阶段2: 删除过旧的归档日志
    if os.path.isdir(LOG_ARCHIVE_DIR):
        delete_cutoff = datetime.now() - timedelta(days=LOG_DELETE_DAYS)
        deleted = 0

        for log_file in glob.glob(os.path.join(LOG_ARCHIVE_DIR, "*.log")):
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(log_file))
                if mtime < delete_cutoff:
                    os.remove(log_file)
                    deleted += 1
            except OSError:
                continue

        if deleted > 0:
            logger.info(f"日志清理: 删除了 {deleted} 个超过 {LOG_DELETE_DAYS} 天的归档日志")


def cleanup_archived(logger):
    """删除 archived/ 中超过 ARCHIVED_RETENTION_DAYS 天的文件"""
    if not os.path.isdir(ARCHIVED_DIR):
        return

    cutoff = datetime.now() - timedelta(days=ARCHIVED_RETENTION_DAYS)
    deleted = 0

    for f in os.listdir(ARCHIVED_DIR):
        filepath = os.path.join(ARCHIVED_DIR, f)
        if not os.path.isfile(filepath):
            continue
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            if mtime < cutoff:
                os.remove(filepath)
                deleted += 1
        except OSError:
            continue

    if deleted > 0:
        logger.info(f"archived/ 清理: 删除了 {deleted} 个超过 {ARCHIVED_RETENTION_DAYS} 天的归档文件")


def run_all_cleanup(logger):
    """执行全部清理任务"""
    cleanup_tmp(logger)
    cleanup_logs(logger)
    cleanup_archived(logger)


# ═══════════════════════════════════════════════════════════════
# 子脚本执行
# ═══════════════════════════════════════════════════════════════

def run_script(script_name, args=None, timeout=600, stdin_input=None):
    """执行子脚本，返回 (success: bool, returncode: int)

    参数:
      script_name: 脚本文件名（在 SCRIPT_DIR 中查找）
      args: 传给脚本的参数列表
      timeout: 超时秒数（默认10分钟）
      stdin_input: 传给子脚本 stdin 的字符串
    """
    script_path = os.path.join(SCRIPT_DIR, script_name)
    if not os.path.isfile(script_path):
        logger.error(f"脚本不存在: {script_path}")
        return False, -1

    cmd = [sys.executable, script_path]
    if args:
        cmd.extend(args)

    logger.info(f"执行: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            cwd=SCRIPT_DIR,
            input=stdin_input,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace"
        )

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                logger.debug(f"  [{script_name}] {line}")
        if result.stderr:
            for line in result.stderr.strip().split("\n"):
                logger.warning(f"  [{script_name}:stderr] {line}")

        if result.returncode != 0:
            logger.error(f"脚本 {script_name} 返回非零退出码: {result.returncode}")
            return False, result.returncode

        return True, result.returncode

    except subprocess.TimeoutExpired:
        logger.error(f"脚本 {script_name} 执行超时 ({timeout}秒)，已终止")
        return False, -1
    except Exception as e:
        logger.error(f"执行脚本 {script_name} 时发生异常: {e}")
        return False, -1


# ═══════════════════════════════════════════════════════════════
# RSS 抓取结果管理
# ═══════════════════════════════════════════════════════════════

def get_today_rss_files():
    """获取今天的 RSS 抓取结果文件列表 (从 tmp/ 目录查找)"""
    today = date.today().strftime("%Y-%m-%d")
    pattern = os.path.join(TMP_DIR, f"rss_{today}_*.md")
    return sorted(glob.glob(pattern))


def count_today_rss_files():
    """统计今天的 RSS 抓取结果文件数量"""
    return len(get_today_rss_files())


def archive_rss_files(logger):
    """将所有 RSS 抓取结果文件移动到 archived 子文件夹"""
    os.makedirs(ARCHIVED_DIR, exist_ok=True)

    # 同时检查 tmp/ 和根目录（兼容旧版文件）
    rss_files = glob.glob(os.path.join(TMP_DIR, RSS_FILE_PATTERN))
    rss_files += glob.glob(os.path.join(SCRIPT_DIR, RSS_FILE_PATTERN))
    # 去重
    rss_files = list(set(rss_files))
    moved = 0

    for f in rss_files:
        try:
            dest = os.path.join(ARCHIVED_DIR, os.path.basename(f))
            if os.path.exists(dest):
                # 避免覆盖：添加时间戳后缀
                base, ext = os.path.splitext(os.path.basename(f))
                dest = os.path.join(ARCHIVED_DIR, f"{base}_{int(time.time())}{ext}")
            shutil.move(f, dest)
            moved += 1
        except Exception as e:
            logger.error(f"归档文件失败 {f}: {e}")

    if moved > 0:
        logger.info(f"已将 {moved} 个 RSS 抓取结果文件移动到 {ARCHIVED_DIR}")


# ═══════════════════════════════════════════════════════════════
# Photos 自动同步
# ═══════════════════════════════════════════════════════════════

def is_photos_update_enabled():
    """检查 Photos 同步脚本是否存在"""
    exists = os.path.isfile(PHOTOS_UPDATE_SCRIPT)
    if not exists and PHOTOS_UPDATE_SCRIPT:
        logger.debug(f"Photos 同步脚本未找到: {PHOTOS_UPDATE_SCRIPT}")
    return exists


def run_photos_update():
    """运行 Photos 自动同步脚本

    仅当脚本文件存在时才会被调用。
    脚本工作目录设为脚本所在目录，
    以便它找到同目录下的 .env 文件。
    无参数运行 = 自动检测模式（检查图片库是否有新内容需要同步）。
    """
    logger.info("-- 开始运行 Photos 自动同步 --")
    logger.info(f"  脚本路径: {PHOTOS_UPDATE_SCRIPT}")

    photos_dir = os.path.dirname(os.path.abspath(PHOTOS_UPDATE_SCRIPT))

    try:
        result = subprocess.run(
            [sys.executable, os.path.abspath(PHOTOS_UPDATE_SCRIPT)],
            cwd=photos_dir,
            capture_output=True,
            text=True,
            timeout=300,
            encoding="utf-8",
            errors="replace"
        )

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                logger.info(f"  [photos_update] {line}")
        if result.stderr:
            for line in result.stderr.strip().split("\n"):
                logger.warning(f"  [photos_update:stderr] {line}")

        if result.returncode != 0:
            logger.error(f"Photos 同步脚本返回非零退出码: {result.returncode}")
            return False

        logger.info("Photos 自动同步完成")
        return True

    except subprocess.TimeoutExpired:
        logger.error("Photos 同步脚本执行超时 (300秒)")
        return False
    except Exception as e:
        logger.error(f"运行 Photos 同步脚本时发生异常: {e}")
        return False


# ═══════════════════════════════════════════════════════════════
# RSS 合并与去重翻译
# ═══════════════════════════════════════════════════════════════

def run_combine():
    """合并今天的 RSS 抓取结果，去重翻译输出

    逻辑:
    1. 检查今天有几份 RSS 抓取结果
    2. 如果不足2份，自动补抓直到有2份
    3. 合并所有结果并执行去重翻译
    4. 合并成功后，将 RSS 抓取结果移至 archived/
    """
    logger.info("-- 开始合并 RSS 结果 --")

    rss_files = get_today_rss_files()

    # 如果不足2份，自动补抓
    attempts = 0
    max_attempts = 3

    while len(rss_files) < 2 and attempts < max_attempts:
        logger.warning(
            f"今天的 RSS 抓取结果不足2份 (当前 {len(rss_files)} 份)，"
            f"自动补抓第 {attempts + 1} 次..."
        )
        success, _ = run_script(RSS_SCRIPT, timeout=300)
        if success:
            time.sleep(2)
            rss_files = get_today_rss_files()
        attempts += 1

    if len(rss_files) < 1:
        logger.error("无法获取任何 RSS 抓取结果，合并取消")
        return False

    if len(rss_files) < 2:
        logger.warning(
            f"仅获取到 {len(rss_files)} 份 RSS 抓取结果，"
            f"将使用现有结果进行合并"
        )

    # 执行合并 (传入文件名，脚本在 SCRIPT_DIR 下运行)
    file_args = [os.path.basename(f) for f in rss_files]
    success, _ = run_script(COMBINE_SCRIPT, args=file_args, timeout=300)

    if success:
        logger.info("RSS 合并去重翻译完成")
        archive_rss_files(logger)
        return True
    else:
        logger.error("RSS 合并去重翻译失败")
        return False


# ═══════════════════════════════════════════════════════════════
# 每日首次启动：立即执行全部任务
# ═══════════════════════════════════════════════════════════════

def is_first_boot_today():
    """判断今天是否是首次启动 keepitrun"""
    try:
        if os.path.isfile(DAILY_BOOT_FLAG):
            with open(DAILY_BOOT_FLAG, "r", encoding="utf-8") as f:
                flag_date = f.read().strip()
                today_str = date.today().strftime("%Y-%m-%d")
                return flag_date != today_str
    except OSError:
        pass
    return True


def mark_boot_today():
    """标记今天已经启动过 keepitrun"""
    os.makedirs(LOG_DIR, exist_ok=True)
    try:
        with open(DAILY_BOOT_FLAG, "w", encoding="utf-8") as f:
            f.write(date.today().strftime("%Y-%m-%d"))
    except OSError as e:
        logger.error(f"写入启动标记失败: {e}")


def run_first_boot_tasks():
    """每日首次启动时立即执行全部任务

    场景: Windows 更新重启、脚本意外退出后重新启动等。
    """
    logger.info("=" * 60)
    logger.info("检测到今日首次启动，立即执行全部任务")
    logger.info("=" * 60)

    # 1. RSS 抓取第1次
    logger.info("[首次启动] 步骤 1/3: RSS 抓取 (第1次)")
    success1, _ = run_script(RSS_SCRIPT, timeout=300)
    if success1:
        logger.info("[首次启动] RSS 第1次抓取完成")
    else:
        logger.warning("[首次启动] RSS 第1次抓取失败，继续尝试第2次")
    time.sleep(3)

    # 2. RSS 抓取第2次
    logger.info("[首次启动] 步骤 2/3: RSS 抓取 (第2次)")
    success2, _ = run_script(RSS_SCRIPT, timeout=300)
    if success2:
        logger.info("[首次启动] RSS 第2次抓取完成")
    else:
        logger.warning("[首次启动] RSS 第2次抓取失败")
    time.sleep(3)

    # 3. 合并去重翻译
    logger.info("[首次启动] 步骤 3/3: 合并去重翻译 RSS 结果")
    combine_ok = run_combine()
    if combine_ok:
        logger.info("[首次启动] RSS 合并去重翻译完成")
    else:
        logger.warning("[首次启动] RSS 合并去重翻译失败，跳过")

    # 4. Photos 同步
    if is_photos_update_enabled():
        logger.info("[首次启动] Photos 自动同步")
        run_photos_update()
    else:
        logger.info("[首次启动] Photos 同步脚本不存在，跳过")

    logger.info("=" * 60)
    logger.info("首次启动全部任务执行完毕，进入定时调度模式")
    logger.info("=" * 60)


# ═══════════════════════════════════════════════════════════════
# 已执行任务记录（防止同一分钟内重复执行）
# ═══════════════════════════════════════════════════════════════

_executed_tasks = {}


def should_run(task_name):
    """判断某个任务今天是否应该执行（每个任务每天只执行一次）"""
    today = date.today().strftime("%Y-%m-%d")
    key = f"{task_name}_{today}"
    if key in _executed_tasks:
        return False
    _executed_tasks[key] = True
    return True


# ═══════════════════════════════════════════════════════════════
# 主循环
# ═══════════════════════════════════════════════════════════════

def main_loop():
    """主循环：每 30 秒检查一次当前时间，触发对应任务"""

    logger.info("=" * 60)
    logger.info(f"keepitrun v{VERSION} 启动")
    logger.info(f"脚本目录: {SCRIPT_DIR}")
    logger.info(f"日志目录: {LOG_DIR}")
    logger.info(f"临时目录: {TMP_DIR}")
    logger.info(f"归档目录: {ARCHIVED_DIR}")
    logger.info("")
    logger.info("清理策略:")
    logger.info(f"  tmp/       > {TMP_RETENTION_DAYS} 天  → 删除")
    logger.info(f"  logs/      > {LOG_ARCHIVE_DAYS} 天  → 移入 logs/archive/")
    logger.info(f"  logs/archive/ > {LOG_DELETE_DAYS} 天 → 删除")
    logger.info(f"  archived/  > {ARCHIVED_RETENTION_DAYS} 天 → 删除")
    logger.info("")
    logger.info("每日任务计划:")
    logger.info("  02:00 - RSS 抓取 (第1次)")
    logger.info("  14:00 - RSS 抓取 (第2次)")
    logger.info("  14:05 - 合并去重翻译 RSS 结果")
    if is_photos_update_enabled():
        logger.info(f"  15:00 - Photos 自动同步 ({PHOTOS_UPDATE_SCRIPT})")
    else:
        logger.info("  15:00 - Photos 自动同步 [未启用: 脚本未找到]")
    logger.info("")
    logger.info("已启用任务 (v1.2):")
    blog_path = os.path.join(SCRIPT_DIR, BLOG_SCRIPT)
    if os.path.isfile(blog_path):
        logger.info(f"  10:10 - 爬取最新 blog  [{BLOG_SCRIPT}]")
    else:
        logger.info(f"  10:10 - 爬取最新 blog  [未找到: {BLOG_SCRIPT}]")
    logger.info("")
    logger.info("已禁用任务:")
    logger.info("  10:05 - 爬取最新 daily [已禁用: 由 convert_daily 独立运行]")
    logger.info("  12:00 - Unsplash 上传  [已禁用: 外部脚本暂不可用]")
    logger.info("=" * 60)

    # 启动时执行清理
    run_all_cleanup(logger)

    # 确保必要目录存在
    os.makedirs(TMP_DIR, exist_ok=True)
    os.makedirs(ARCHIVED_DIR, exist_ok=True)

    # ── 每日首次启动：立即执行全部任务 ──
    if is_first_boot_today():
        run_first_boot_tasks()
        mark_boot_today()
    else:
        logger.info("今日已启动过，跳过首次启动任务，进入定时调度模式")

    last_cleanup_date = date.today()

    while True:
        try:
            current_time = time.strftime("%H:%M")
            current_date = date.today()

            # 每天凌晨第一次循环时执行清理
            if current_date != last_cleanup_date:
                run_all_cleanup(logger)
                last_cleanup_date = current_date

            # ── 02:00 RSS 抓取 (第1次) ──
            if current_time == "02:00" and should_run("rss_1"):
                logger.info(">>> 触发 02:00 RSS 抓取 (第1次)")
                run_script(RSS_SCRIPT, timeout=300)
                time.sleep(60)

            # ── 14:00 RSS 抓取 (第2次) ──
            elif current_time == "14:00" and should_run("rss_2"):
                logger.info(">>> 触发 14:00 RSS 抓取 (第2次)")
                run_script(RSS_SCRIPT, timeout=300)
                time.sleep(60)

            # ── 14:05 合并去重翻译 ──
            elif current_time == "14:05" and should_run("combine"):
                logger.info(">>> 触发 14:05 合并去重翻译 RSS 结果")
                run_combine()
                time.sleep(60)

            # ── 15:00 Photos 自动同步 (每日) ──
            elif current_time == "15:00" and should_run("photos_update") and is_photos_update_enabled():
                logger.info(">>> 触发 15:00 Photos 自动同步")
                run_photos_update()
                time.sleep(60)

            # ── 10:10 爬取最新 blog (v1.2 重新启用) ──
            elif current_time == "10:10" and should_run("blog"):
                blog_path = os.path.join(SCRIPT_DIR, BLOG_SCRIPT)
                if os.path.isfile(blog_path):
                    logger.info(">>> 触发 10:10 爬取最新 blog")
                    # 读取上次成功爬取日期
                    last_date = ""
                    if os.path.isfile(BLOG_LAST_CRAWL_FILE):
                        try:
                            with open(BLOG_LAST_CRAWL_FILE, "r", encoding="utf-8") as f:
                                last_date = f.read().strip()
                        except OSError:
                            pass
                    # 构建参数
                    args = []
                    if last_date and re.match(r'\d{8}$', last_date):
                        args.append(f"album:{last_date}")
                    else:
                        args.append("album:diff")
                    success, _ = run_script(BLOG_SCRIPT, args=args, timeout=600)
                    if success:
                        # 更新上次爬取日期
                        try:
                            os.makedirs(os.path.dirname(BLOG_LAST_CRAWL_FILE), exist_ok=True)
                            with open(BLOG_LAST_CRAWL_FILE, "w", encoding="utf-8") as f:
                                f.write(date.today().strftime("%Y%m%d"))
                        except OSError:
                            pass
                else:
                    logger.warning(f"Blog脚本不存在: {blog_path}")
                time.sleep(60)

            # ── 仍禁用的任务占位 ──
            # elif current_time == "10:05" and should_run("daily"):
            #     logger.info(">>> 触发 10:05 爬取最新 daily")
            #     run_daily_crawl()
            #     time.sleep(60)
            # elif current_time == "12:00" and should_run("unsplash") and should_run_unsplash():
            #     logger.info(">>> 触发 12:00 Unsplash 自动上传")
            #     run_unsplash_upload()
            #     time.sleep(60)

            # 每 30 秒检查一次
            time.sleep(CHECK_INTERVAL)

        except KeyboardInterrupt:
            logger.info("用户中断 (Ctrl+C)，退出 keepitrun")
            break
        except Exception as e:
            logger.error(f"主循环异常: {e}", exc_info=True)
            time.sleep(60)


# ═══════════════════════════════════════════════════════════════
# 入口
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger = setup_logging()
    main_loop()
