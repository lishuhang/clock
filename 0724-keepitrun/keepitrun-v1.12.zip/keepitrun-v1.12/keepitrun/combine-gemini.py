#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import google.generativeai as genai
import time
import re
import locale
import argparse
import glob
import logging

# ================= 核心修复 =================
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
# ===========================================

# 脚本所在目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 临时文件目录 (v1.1: 从 tmp/ 读取中间结果)
TMP_DIR = os.path.join(SCRIPT_DIR, "tmp")

# 日志目录 (v1.1: 统一日志到 logs/)
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# --- 默认配置 ---
DEFAULT_API_KEY = "AIzaSyAR5Nuk6gqpk-Kh6olnXsFAkObDla2zjyY" 
MODEL_NAME = "gemini-3-flash-preview"

generation_config = {
    "temperature": 0.3,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 8192,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

# --- 分类关键词配置 ---
COMPANY_MAP = {
    'NVIDIA': ['NVIDIA', '英伟达', 'Jensen Huang', 'Huang Renxun', '黄仁勋', 'GeForce', 'RTX', 'Blackwell', 'H100', 'H200', 'B100', 'B200', 'GB200', 'Rubin', 'CUDA', '显卡', 'GPU', 'Omniverse', 'Vera', 'X800'],
    'OpenAI': ['OpenAI', 'ChatGPT', 'GPT', 'Sora', 'Sam Altman', 'Altman', '奥特曼', 'Murati', 'DALL-E', 'O1', 'Strawberry', 'Q*', 'DevDay', 'SearchGPT', 'Canvas', 'Greg Brockman', 'Ilya'],
    'Google': ['Google', '谷歌', 'DeepMind', 'Gemini', 'Sundar Pichai', 'Demis Hassabis', 'Waymo', 'AlphaFold', 'Android', 'Pixel', 'TPU', 'DeepResearch', 'Veo', 'Imagen', 'Jarvis', 'Project Astra', 'NotebookLM'],
    'Microsoft': ['Microsoft', '微软', 'Copilot', 'Azure', 'Satya Nadella', 'Nadella', 'Windows', 'Xbox', 'Phi-3', 'Phi-4', 'Recall', 'Surface'],
    'Anthropic': ['Anthropic', 'Claude', 'Dario Amodei', 'Amodei', 'Constitutional AI'],
    'Apple': ['Apple', '苹果', 'iPhone', 'iPad', 'Mac', 'Siri', 'Tim Cook', 'Cook', 'M4', 'M5', 'A18', 'A19', 'Apple Intelligence', 'Vision Pro', 'Ferret', 'MM1'],
    'Meta': ['Meta', 'Facebook', 'Zuckerberg', 'Llama', 'Yann LeCun', 'LeCun', 'PyTorch', 'Ray-Ban', 'Orion', 'Quest', 'Threads', 'Instagram'],
    'xAI/Tesla': ['xAI', 'Grok', 'Musk', 'Elon Musk', '马斯克', 'Tesla', '特斯拉', 'Optimus', 'SpaceX', 'Starlink', 'Robotaxi', 'FSD'],
    'Amazon': ['Amazon', '亚马逊', 'AWS', 'Bedrock', 'Olympus', 'Rufus', 'Bezos', 'Jassy', 'Q '],
    'ByteDance': ['ByteDance', '字节', 'Doubao', '豆包', 'TikTok', 'Liang Rubo', 'Zhang Yiming', '张一鸣', 'Jimeng', '即梦', 'Seed-TTS'],
    'Alibaba': ['Alibaba', '阿里', 'Qwen', '通义', 'Tongyi', '千问', 'Joe Tsai', 'Eddie Wu', '蔡崇信', '吴泳铭', 'Wan', 'Animate Anyone'],
    'Baidu': ['Baidu', '百度', 'Ernie', '文心', 'Robin Li', '李彦宏', 'Apollo'],
    'Tencent': ['Tencent', '腾讯', 'Hunyuan', '混元', 'Pony Ma', '马化腾', 'WeChat'],
    'DeepSeek': ['DeepSeek', '深度求索', '幻方', 'Liang Wenfeng', '梁文锋', 'Fire-Flyer'],
    'Moonshot': ['Moonshot', '月之暗面', 'Kimi', 'Yang Zhilin', '杨植麟'],
    'MiniMax': ['MiniMax', '海螺', 'Hailuo', 'Yan Junjie', '闫俊杰', 'Video-01'],
    '01.AI': ['01.AI', '零一万物', 'Yi-Large', 'Yi-Pro', 'Lee Kai-fu', '李开复'],
    'Huawei': ['Huawei', '华为', 'Ascend', '昇腾', 'Kunpeng', '鲲鹏', 'HarmonyOS', '鸿蒙', 'Pura', 'Mate', 'CANN'],
    'Xiaomi': ['Xiaomi', '小米', 'Lei Jun', '雷军', 'SU7', 'HyperOS', 'XiaoAI', '小爱'],
    'SenseTime': ['SenseTime', '商汤', 'Xu Li', '徐立', 'SenseNova', '日日新', 'Vais'],
    'Adobe': ['Adobe', 'Photoshop', 'Firefly', 'Premiere'],
    'Midjourney/Stability': ['Midjourney', 'Stability', 'Stable Diffusion', 'Runway', 'Gen-2', 'Gen-3', 'Pika', 'Suno', 'Udio']
}

PRIORITY_ORDER = [
    'NVIDIA', 'OpenAI', 'Google', 'Microsoft', 'Apple', 'Meta', 'Anthropic', 
    'xAI/Tesla', 'Huawei', 'DeepSeek', 'ByteDance', 'Alibaba', 'Tencent', 
    'Baidu', 'Amazon', 'Moonshot', 'MiniMax', '01.AI', 'Xiaomi', 
    'SenseTime', 'Midjourney/Stability', 'Adobe'
]

# --- 辅助函数 ---

def parse_money_value(text):
    text = text.lower()
    RATE_USD = 7.2
    value = 0.0
    found = False
    
    usd_match = re.search(r'\$\s*(\d+(?:\.\d+)?)\s*([mbk]?)', text)
    if usd_match:
        num = float(usd_match.group(1))
        unit = usd_match.group(2)
        multiplier = 1
        if unit == 'k': multiplier = 1000
        elif unit == 'm': multiplier = 1000000
        elif unit == 'b': multiplier = 1000000000
        value = num * multiplier * RATE_USD
        found = True
        return found, value

    cny_match = re.search(r'(\d+(?:\.\d+)?)\s*(亿|万)', text)
    if cny_match:
        num = float(cny_match.group(1))
        unit = cny_match.group(2)
        multiplier = 1
        if unit == '万': multiplier = 10000
        elif unit == '亿': multiplier = 100000000
        value = num * multiplier
        found = True
        return found, value

    en_text_match = re.search(r'(\d+(?:\.\d+)?)\s*(million|billion)', text)
    if en_text_match:
        num = float(en_text_match.group(1))
        unit = en_text_match.group(2)
        multiplier = 1000000 if 'million' in unit else 1000000000
        value = num * multiplier * RATE_USD
        found = True
        return found, value

    return found, 0.0

def parse_news_list_file(filepath):
    header_lines = []
    content_lines = []
    footer_lines = []
    in_content = False

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if not lines: return None

        for line in lines:
            s_line = line.strip()
            if not s_line:
                continue
                
            if s_line.startswith("- ") or s_line.startswith("• "):
                in_content = True
                content_lines.append(s_line)
            else:
                if not in_content:
                    header_lines.append(line)
                else:
                    footer_lines.append(line)

        return header_lines, content_lines, footer_lines
    except Exception as e:
        print(f"Error parsing {filepath}: {e}")
        return None

def is_primarily_english(text):
    if not text: return False
    clean = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)
    clean = re.sub(r'[-`*#_~]', '', clean).strip()
    if not clean: return False
    ascii_count = sum(1 for c in clean if ord(c) < 128)
    return ascii_count / len(clean) > 0.8

def parse_markdown_link(line):
    match = re.match(r'^([-•]\s*)\[(.*?)\]\((.*?)\)(.*)$', line)
    if match:
        return match.group(1), match.group(2), match.group(3), match.group(4)
    
    match_no_link = re.match(r'^([-•]\s*)(.*)$', line)
    if match_no_link:
        return match_no_link.group(1), match_no_link.group(2), "", ""
        
    return "- ", line.lstrip("- ").lstrip("• "), "", ""

def translate_batch(model, texts):
    if not texts: return []
    clean_texts = [t.lstrip("- ").lstrip("• ") for t in texts]
    
    prompt = (
        "Translate the following news headlines to Chinese. "
        "Maintain the original meaning but make it concise, professional, and suitable for a tech news briefing. "
        "Strictly output one translation per line, corresponding exactly to the input order. "
        "Do not include any numbering or bullet points in your output, just the translated text.\n\n"
    )
    for i, t in enumerate(clean_texts):
        prompt += f"{i+1}. {t}\n"
    
    try:
        response = model.generate_content(prompt, generation_config=generation_config, safety_settings=safety_settings)
        if not response.parts or not response.text:
            raise Exception("Empty response from Gemini")
            
        lines = response.text.strip().split('\n')
        results = []
        for line in lines:
            line = re.sub(r'^\d+\.\s*', '', line.strip())
            line = re.sub(r'\*\*', '', line)
            line = line.lstrip("- ").lstrip("• ")
            if line: results.append(line)
            
        if len(results) != len(texts): 
             raise Exception(f"Translation count mismatch: sent {len(texts)}, got {len(results)}")
        return results
    except Exception as e:
        raise e

def classify_and_sort_items(items):
    investment_items = []
    classified_buckets = {k: [] for k in PRIORITY_ORDER}
    unclassified = []
    
    invest_keywords_cn = ['融资', '获投', '筹资', '募资', '投资']
    invest_keywords_en = ['raised', 'funding', 'financing', 'series a', 'series b', 'seed round', 'invest']
    
    source_pattern = re.compile(r'\s*\([^)]*?\)$', re.IGNORECASE)

    for item in items:
        if not (item.startswith("- ") or item.startswith("• ")):
            item = "- " + item
            
        match = re.match(r'^[-•]\s*\[(.*?)\]\((.*?)\)(.*)$', item)
        if match:
            title_for_analysis = match.group(1)
        else:
            title_for_analysis = item[2:].strip()
            
        lower_content = title_for_analysis.lower()
        
        has_invest_kw = any(k in lower_content for k in invest_keywords_cn) or \
                        any(k in lower_content for k in invest_keywords_en)
        
        is_investment = False
        if has_invest_kw:
            has_money, money_val = parse_money_value(title_for_analysis)
            if has_money:
                investment_items.append({'text': item, 'value': money_val})
                is_investment = True
        
        if is_investment:
            continue
            
        clean_content = source_pattern.sub('', title_for_analysis).lower()
        assigned = False
        for company in PRIORITY_ORDER:
            keywords = COMPANY_MAP.get(company, [])
            if any(k.lower() in clean_content for k in keywords):
                classified_buckets[company].append(item)
                assigned = True
                break
        
        if not assigned:
            unclassified.append(item)

    final_output = []
    
    if investment_items:
        investment_items.sort(key=lambda x: x['value'], reverse=True)
        final_output.extend([x['text'] for x in investment_items])
        final_output.append("")

    for company in PRIORITY_ORDER:
        bucket = classified_buckets[company]
        if bucket:
            try: bucket.sort(key=locale.strxfrm)
            except: bucket.sort()
            final_output.extend(bucket)
            final_output.append("")
            
    if unclassified:
        try: unclassified.sort(key=locale.strxfrm)
        except: unclassified.sort()
        final_output.extend(unclassified)
    
    while final_output and final_output[-1] == "":
        final_output.pop()
        
    return final_output

def main():
    parser = argparse.ArgumentParser(description="Merge, Translate and Categorize RSS MD files.")
    parser.add_argument('files', nargs='+', help='Input markdown files')
    parser.add_argument('-api', help='API Key for Gemini', default=None)
    args = parser.parse_args()

    api_key = args.api if args.api else DEFAULT_API_KEY
    model = None
    if api_key:
        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(MODEL_NAME)
        except Exception as e:
            print(f"Warning: Failed to init model: {e}")

    all_content_lines = set()
    first_header = []
    first_footer = []
    
    for i, fpath in enumerate(args.files):
        # v1.1: 先尝试在 tmp/ 中查找，再在脚本目录查找
        full_path = os.path.join(TMP_DIR, fpath)
        if not os.path.isfile(full_path):
            full_path = os.path.join(SCRIPT_DIR, fpath)
        
        parsed = parse_news_list_file(full_path)
        if not parsed: continue
        h, c, f = parsed
        if i == 0:
            first_header = h
            first_footer = f
        
        for line in c:
            all_content_lines.add(line)

    print(f"Total unique lines loaded: {len(all_content_lines)}")

    cn_lines = []
    en_lines = []
    for line in all_content_lines:
        content_only = re.sub(r'^[-•]\s*', '', line)
        if is_primarily_english(content_only):
            en_lines.append(line)
        else:
            cn_lines.append(line)

    print(f"Chinese lines: {len(cn_lines)}, English lines: {len(en_lines)}")

    translated_lines = []
    translation_failed = False
    
    if en_lines and model:
        print(f"Starting translation using {MODEL_NAME}...")
        batch_size = 20
        for i in range(0, len(en_lines), batch_size):
            batch = en_lines[i:i+batch_size]
            
            batch_titles = []
            batch_meta = []
            for line in batch:
                prefix, title, url, suffix = parse_markdown_link(line)
                batch_titles.append(title)
                batch_meta.append((prefix, url, suffix))
                
            try:
                print(f"Translating batch {i//batch_size + 1} (Items: {len(batch)})...")
                results = translate_batch(model, batch_titles)
                
                for j, translated_title in enumerate(results):
                    prefix, url, suffix = batch_meta[j]
                    if url:
                        reconstructed = f"- [{translated_title}]({url}){suffix}"
                    else:
                        reconstructed = f"- {translated_title}{suffix}"
                    translated_lines.append(reconstructed)
                    
                time.sleep(1.5) 
            except Exception as e:
                print(f"× Translation failed (stopping translation): {e}")
                translation_failed = True
                break
    elif en_lines and not model:
        print("Skipping translation (No API Key or Model init failed)")
        translation_failed = True

    output_body = []
    
    if not translation_failed:
        combined = cn_lines + translated_lines
        output_body = classify_and_sort_items(combined)
    else:
        print("！ Entering fallback mode: separating Chinese and English.")
        cn_sorted = classify_and_sort_items(cn_lines)
        en_sorted = classify_and_sort_items(en_lines)
        output_body.extend(cn_sorted)
        if cn_sorted and en_sorted:
            output_body.append("")
            output_body.append("--- English Content (Translation Skipped) ---")
            output_body.append("")
        output_body.extend(en_sorted)

    # v1.1: 最终输出文件保存在脚本根目录 (非 tmp/)
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    output_filename = os.path.join(SCRIPT_DIR, f"{timestamp}.md")
    
    with open(output_filename, 'w', encoding='utf-8') as f:
        if first_header:
            f.writelines(first_header)
            if not first_header[-1].endswith('\n'): f.write('\n')
        for line in output_body:
            f.write(line + "\n")
        if first_footer:
            if output_body and output_body[-1].strip(): f.write('\n')
            f.writelines(first_footer)

    print(f"√ Process complete. Saved to: {output_filename}")

if __name__ == "__main__":
    main()
