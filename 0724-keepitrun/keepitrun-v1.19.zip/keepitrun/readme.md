# keepitrun — 全天候定时任务调度系统

**当前版本：1.19（2026-08-18）**

keepitrun 是一个以 Python 实现的常驻定时任务调度器。它按 **GMT+8** 执行 RSS 抓取、摘要合并翻译、微信公众号内容处理和 Photos 同步。所有用户使用、配置、排障和版本信息均以本文件为准。

> **v1.19 发布重点：** 已移除 Unsplash 与马良注册任务；所有保留的每日任务脚本按实际执行顺序编号。RSS 摘要会跨未取走的日期文件累积合并，以最终文章 URL 为准去重，并确保目录中只保留一个最新摘要文件。

## 阅读与求助

需要帮助时，请直接打开 `readme.md`。不要运行或恢复 `readme.py`；该旧文件已移除，以防可执行文档和说明文档发生分歧。

```bat
notepad readme.md
python keepitrun.py
```

## 活动任务与命名规则

活动脚本均使用 **两位顺序号、下划线、kebab-case 名称**，即 `NN_name-with-hyphens.py`。编号代表每日自动任务的逻辑顺序；同一脚本在一天内可按其调度时间多次运行。

| 编号 | 脚本 | 自动时间（GMT+8） | 作用 |
|---:|---|---|---|
| 01 | `01_getrss.py` | 02:00、14:00 | 抓取 RSS、过滤关键词、规范化文章 URL、按最终 URL 去重并保留最长描述。 |
| 02 | `02_combine-gemini.py` | 14:05 | 合并 RSS 与未取走摘要，按最终 URL 去重、翻译、分类，并留下唯一最新摘要。 |
| 03 | `03_convert-daily.py` | 10:05 | 抓取并发布微信公众号 AIGC 早报。 |
| 04 | `04_convert-blog.py` | 10:10 | 抓取并同步微信公众号博客文章。 |
| 05 | `05_photos-update.py` | 15:00 | 同步 Photos 图片库；仅当脚本存在时启用。 |
| 90 | `90_cleanup-daily-from-blog.py` | 首次启动时的维护步骤 | 检查并清理历史误入主博客的 daily 内容；先预览再执行。 |
| 91 | `91_compress-images.py` | 手动 | 图片压缩维护工具。 |
| 92 | `92_model-process.py` | 手动 | 可选的模型后处理工具。 |

**Unsplash 与马良注册已从自动任务、主调度器、环境变量模板和发行包中移除。** 相关历史版本说明仅保留在下方更新日志中，不再代表可用功能。

## RSS 增量摘要规则

`01_getrss.py` 在抓取阶段会优先把聚合链接还原为文章原址：Google News 的重定向 URL 会直接解码；Techmeme 会保留 Techmeme 的标题/摘要文字，但链接替换为对应原文报道。它会去掉 URL 片段和不用于定位文章的追踪参数。

`02_combine-gemini.py` 使用与抓取阶段一致的最终 URL 规则。相同 URL 的多个条目只保留**文字说明最长**的一条；这条规则同时应用于当天两次 RSS 抓取、跨日积压摘要和人工传入的 RSS Markdown 文件。

根目录中的 `YYYYMMDD-HHMMSS.md` 是**尚未被用户取走的 RSS 摘要**。如果运行合并器时发现两个或以上此类文件，或发现历史误后缀 `YYYYMMDD-HHMMSS.py`，它会将它们与新 RSS 文件一起去重、翻译并生成一个新的 `.md`。新文件以原子方式写入成功后，旧摘要才会删除。因此，不论积压多少天，目录最终只保留一个最新摘要；其内容覆盖用户上次取走摘要后至今的全部不重复条目。

用户取走摘要后，应将根目录中的该 `YYYYMMDD-HHMMSS.md` 移出或删除。若保留，下一次合并会把它视为待领取内容而继续累计。

## 翻译与保底策略

RSS 标题按以下顺序翻译：**Gemini → GLM HTTP API → Google Free Translate**。每个可用引擎都有重试；若整个批次的所有引擎均不可用，合并器仍会保留原始标题，确保当天摘要文件生成。

GLM 对个别内容返回拒绝性文本时，合并器会识别常见拒绝提示并直接保留该条的英语原文，而不是把拒绝提示写入摘要或丢弃条目。其他正常条目仍会使用其返回的中文翻译。

## 目录结构

```text
keepitrun/
├── keepitrun.py                    常驻主调度器
├── 01_getrss.py                    RSS 抓取、URL 规范化与最长说明去重
├── 02_combine-gemini.py            RSS/积压摘要合并、翻译与分类
├── 03_convert-daily.py             AIGC 早报处理
├── 04_convert-blog.py              博客文章处理
├── 05_photos-update.py             Photos 同步
├── 90_cleanup-daily-from-blog.py   手动维护清理工具
├── 91_compress-images.py           图片压缩工具
├── 92_model-process.py             可选模型后处理工具
├── readme.md                       唯一用户说明与更新日志
├── .env.example                    环境变量模板；不含实际凭据
├── keywords.json                   RSS 关键词配置
├── rss_feeds.json                  RSS 订阅源配置
├── tmp/                            RSS 中间文件
├── logs/                           日志与任务完成记录
└── archived/                       已处理内容归档
```

发行包和 GitHub 提交中不得包含 `.env`、账号记录、日志、临时文件、用户文章、图片、令牌、Cookie 或其他凭据。只可包含 `.env.example`。

## 安装、配置与启动

需要 Python 3.9+、pip 和网络连接。使用 `.env.example` 创建本地 `.env`，并自行填入必要的值；不得将 `.env` 上传到 GitHub、聊天记录或交接文档。

```bat
pip install feedparser beautifulsoup4 google-generativeai pypinyin requests python-dotenv Pillow
python keepitrun.py
```

典型配置仅包括内容同步与 RSS 翻译所需的值。GLM 回退使用标准 HTTP API，不依赖 `zhipuai` Python 包。若需要凭据，请向配置所有者索取；不要把实际值写入代码、说明或 `todo-*.md`。

## 常用手动命令

| 目的 | 命令 |
|---|---|
| 启动调度器 | `python keepitrun.py` |
| 预览 daily 清理 | `python 90_cleanup-daily-from-blog.py --dry-run` |
| 执行 daily 清理 | `python 90_cleanup-daily-from-blog.py` |
| 全量比对博客文章 | `python 04_convert-blog.py album:diff` |
| 合并一个 RSS 文件并强制免费翻译 | `python 02_combine-gemini.py tmp/rss_YYYY-MM-DD_HH-MM-SS.md -engine google_free` |
| 合并一个或多个 RSS 文件并自动回退 | `python 02_combine-gemini.py tmp/rss_YYYY-MM-DD_HH-MM-SS.md -engine auto` |
| 仅收敛根目录积压摘要 | `python 02_combine-gemini.py -engine auto` |

`90_cleanup-daily-from-blog.py` 可能删除远程仓库中的匹配文章。实际执行前必须先使用 `--dry-run` 确认结果。

## 文件清理策略

| 目录或文件 | 策略 | 注意事项 |
|---|---|---|
| `tmp/` | 超过 1 天自动删除 | RSS 中间文件。 |
| `logs/` | 超过 7 天移入 `logs/archive/` | 运行日志。 |
| `logs/archive/` | 超过 30 天自动删除 | 历史日志。 |
| `archived/` | 超过 30 天自动删除 | 已处理的本地副本。 |
| 根目录 `YYYYMMDD-HHMMSS.md` | 不自动删除 | 用户未取走的 RSS 摘要；会在下一次合并时继续累计。 |
| `last_blog_crawl.txt` | 不应手动删除 | 删除会扩大下一次博客抓取范围。 |
| `logs/task_completion.json` | 不应手动删除 | 保存版本感知任务状态。 |

## 故障排查

### RSS 摘要没有生成或积压未消失

检查 `tmp/` 中是否有 `rss_*.md`，以及根目录是否有 `YYYYMMDD-HHMMSS.md` 或历史 `.py` 后缀摘要。合并器会先读取所有积压摘要，再读取传入的 RSS 文件。若合并失败，旧摘要不会删除；可查看 `logs/` 后重试。

### GLM 返回拒绝提示或翻译失败

拒绝性返回会保留英语原文，不会丢失条目。网络、限流或结构化输出失败时，脚本会继续尝试下一翻译引擎；全部失败时仍以原始标题输出摘要。

### GitHub 认证失败

确认本地 `.env` 中的同步凭据有效且拥有目标仓库所需权限。不要把凭据打印到日志、聊天、README 或交接文件。

### 用户需要帮助

直接打开 `readme.md`。不要恢复或运行 `readme.py`。

## 版本感知任务完成追踪

主程序将任务名、日期和完成版本保存到 `logs/task_completion.json`。同日升级后，只有被 `VERSION_TASK_CHANGES` 标记为受影响的任务会重新运行。v1.19 的重命名和 RSS 合并逻辑影响 `rss`、`combine`、`daily`、`blog` 与 `photos_update`。

## 更新日志

### v1.19（2026-08-18）— 任务链整理与累计 RSS 摘要

- 移除 Unsplash 与马良注册的自动任务、脚本文件和环境变量模板内容。
- 将保留的每日任务依执行顺序重命名为 `01_getrss.py` 至 `05_photos-update.py`；维护工具使用 `90+` 编号。
- `02_combine-gemini.py` 现在会合并根目录中所有尚未取走的 `YYYYMMDD-HHMMSS.md`，并兼容历史 `.py` 后缀摘要；输出成功后删除被新摘要取代的旧文件。
- URL 去重与“相同 URL 保留最长描述”规则与 `01_getrss.py` 对齐，并覆盖积压摘要与新 RSS 输入。
- GLM 的单条拒绝性翻译结果会回显英语原文，避免遗漏或写入拒绝提示。
- 任务映射：`rss`、`combine`、`daily`、`blog`、`photos_update`。

### v1.18（2026-08-18）— RSS 恢复、可靠性与链接规范化

- 主调度器固定按 GMT+8 判断日期和任务时间；子脚本设置统一时限并重试。
- `combine-gemini.py` 支持一个或多个 RSS 中间文件，并按 Gemini、GLM HTTP API、Google Free Translate 降级。
- `getrss.py` 解码 Google 重定向、解析 Techmeme 原文链接、去除追踪参数，并按 URL 去重。

### v1.17（2026-08-18）— 版本与文档校正

- 以正式 v1.16 归档为基线校正版本元数据，删除 `readme.py`，并将说明统一至本文件。
- 历史“2.0”标识被确认为非正式版本，不构成后续程序发布。

### v1.16 及更早版本

完整历史版本信息以归档 ZIP 和 GitHub 提交记录为准。维护时应以当前 `VERSION`、`VERSION_DATE`、`VERSION_TASK_CHANGES` 和本更新日志为一致性基线。

## 维护注意事项

- 修改代码前先核对版本变量、任务映射、README 和发行包命名是否一致。
- 每次完成一轮工作，在提交前新建一个仅包含本轮增量的 `todo-MMDD-HHMM.md` 交接记录。
- 交接记录必须完整保留对应用户需求，并说明目的、偏好、完成项、偏差、未完成项、返工与踩坑；不得包含令牌、API Key、密码、Cookie、个人信息或任何明文凭据。如需要凭据，必须向配置所有者索取。
- 发布前确认包内不含 `.env`、日志、临时文件、账号记录、凭据或用户生成内容。

---

文档版本：**1.19**。本文是 keepitrun 的唯一用户说明与更新日志。
