# keepitrun — 全天候定时任务调度系统

**当前版本：1.18（2026-08-18）**

keepitrun 是一个以 Python 实现的常驻定时任务调度器，适用于 Windows 11 和其他可运行 Python 的环境。主脚本每 30 秒检查一次时间，到点后调用相应子脚本完成 RSS 抓取、内容合并翻译、微信公众号文章处理及图片相关任务。

> **本次发布说明：** v1.18 提升后台运行的可靠性。RSS 合并不再因凑足两份文件而重复抓取；首次启动会优先恢复当日已有中间文件。所有子脚本使用统一的可重试执行器与不超过主调度器上限的时限；翻译按 Gemini、GLM HTTP API、Google Free Translate 的顺序降级，任何引擎故障都不会阻止合并产物生成。

## 阅读与求助

**请直接打开本文件 `readme.md` 查看使用、配置、排障和更新记录。** 不再提供或运行 `python readme.py`；该文件已移除，避免 Markdown 文档与可执行文档长期不同步。

在 Windows 中可用资源管理器或编辑器打开 `readme.md`；命令行中可使用：

```bat
notepad readme.md
```

运行主程序仍使用：

```bat
python keepitrun.py
```

## 核心功能

| 功能 | 作用 | 主要脚本 |
|---|---|---|
| RSS 抓取与关键词过滤 | 抓取订阅源并按关键词过滤内容 | `getrss.py` |
| RSS 合并、去重与翻译 | 合并多次抓取结果并输出 Markdown | `combine-gemini.py` |
| AIGC 早报处理 | 抓取并发布微信公众号 AIGC 早报 | `convert_daily.py` |
| 博客文章处理 | 抓取微信公众号长文、短文并同步博客 | `convert_blog.py` |
| Photos 同步 | 同步 GitHub Photos 图片库 | `photos_update.py` |
| Unsplash 管理 | 按周期管理 Unsplash 照片 | `unsplash_update.py` |
| 马良生图注册 | 定时注册并记录账号信息 | `maliang_register.py` |
| 版本感知追踪 | 对受版本影响的当日任务决定是否重做 | `keepitrun.py` |

## 目录结构

```text
keepitrun/
├── keepitrun.py                 主调度脚本（常驻运行）
├── getrss.py                    RSS 抓取与关键词过滤
├── combine-gemini.py            RSS 合并、去重与翻译
├── convert_daily.py             微信公众号 AIGC 早报处理
├── convert_blog.py              微信公众号长文/短文处理
├── model-process.py             可选的 LLM 后处理工具
├── photos_update.py             Photos 图片库同步
├── unsplash_update.py           Unsplash 照片管理
├── maliang_register.py          马良生图账号注册
├── cleanup_daily_from_blog.py   一次性清理工具（保留备查）
├── compress_images.py           图片压缩命令行工具
├── readme.md                    唯一用户说明与更新日志
├── .env.example                 环境变量模板
├── keywords.json                RSS 关键词配置
├── rss_feeds.json               RSS 订阅源配置
├── last_blog_crawl.txt          博客上次爬取日期（自动维护）
├── maliang_accounts.json        马良账号记录（运行时维护）
├── logs/                        运行日志与任务完成记录
├── tmp/                         RSS 中间文件
├── archived/                    已处理内容归档
├── images/                      本地图片工作目录
└── _posts/                      本地文章工作目录
```

`readme.py` 已移除。请勿把 `.env`、账号记录、日志、临时文件或归档文件提交到公开仓库。

## 每日任务计划

| 时间 | 任务 | 脚本 | 备注 |
|---:|---|---|---|
| 02:00 | RSS 抓取（第 1 次） | `getrss.py` | 常规调度 |
| 03:00 | 马良生图账号注册 | `maliang_register.py` | 可由 `.env` 调整数量 |
| 10:05 | 抓取最新 daily | `convert_daily.py` | AIGC 早报 |
| 10:10 | 抓取最新 blog | `convert_blog.py` | 微信公众号合集文章 |
| 12:00 | Unsplash 照片管理 | `unsplash_update.py` | 每 3 天一次 |
| 14:00 | RSS 抓取（第 2 次） | `getrss.py` | 常规调度 |
| 14:05 | 合并、去重与翻译 RSS | `combine-gemini.py` | 常规调度；可使用一份或多份中间文件 |
| 15:00 | Photos 自动同步 | `photos_update.py` | 脚本存在时启用 |

## 安装、配置与启动

### 环境要求

需要 Python 3.9+、pip、网络连接；涉及 GitHub 同步的任务还需要具备对应仓库权限的 GitHub Token。请在目标目录中从 `.env.example` 创建 `.env`，再填写实际凭证。**不要将 `.env` 或任何密钥上传到 GitHub。**

安装依赖：

```bat
pip install feedparser beautifulsoup4 google-generativeai zhipuai pypinyin requests python-dotenv Pillow
```

典型配置项如下；值必须由使用者自行提供：

```dotenv
GITHUB_TOKEN=你的_token
UNSPLASH_ACCESS_KEY=你的_access_key
UNSPLASH_SECRET_KEY=你的_secret_key
UNSPLASH_BEARER_TOKEN=你的_bearer_token
UNSPLASH_REDIRECT_URI=urn:ietf:wg:oauth:2.0:oob

# 可选：马良生图注册任务
MALIANG_REGISTER_MIN=2
MALIANG_REGISTER_MAX=5
```

启动调度器：

```bat
python keepitrun.py
```

建议使用 Windows 任务计划程序创建“计算机启动时”触发的任务。主程序会持续运行；请使用日志确认其正常工作，而不是重复开启多个实例。

## 常用手动命令

| 目的 | 命令 |
|---|---|
| 启动调度器 | `python keepitrun.py` |
| 用授权码获取 Unsplash Token | `python unsplash_update.py auth <授权码>` |
| 预览 daily 清理操作 | `python cleanup_daily_from_blog.py --dry-run` |
| 执行 daily 清理操作 | `python cleanup_daily_from_blog.py` |
| 全量比对博客文章（耗时较长） | `python convert_blog.py album:diff` |
| 强制使用免费翻译 | `python combine-gemini.py tmp/rss_YYYY-MM-DD.md -engine google_free` |
| 按自动回退策略翻译 | `python combine-gemini.py tmp/rss_YYYY-MM-DD.md -engine auto` |

`cleanup_daily_from_blog.py` 会删除远程仓库中的匹配文章。执行实际删除前必须先使用 `--dry-run` 核对结果。

## 文件清理策略

| 目录或文件 | 保留策略 | 注意事项 |
|---|---|---|
| `tmp/` | 超过 1 天自动删除 | RSS 中间结果 |
| `logs/` | 超过 7 天移入 `logs/archive/` | 日志归档 |
| `logs/archive/` | 超过 30 天自动删除 | 历史日志 |
| `archived/` | 超过 30 天自动删除 | 已处理的本地副本 |
| `last_blog_crawl.txt` | 不应手动删除 | 删除会导致重新全量爬取 |
| `maliang_accounts.json` | 不应手动删除 | 账号累计记录 |
| `logs/task_completion.json` | 不应手动删除 | 版本感知任务记录 |

## 版本感知任务完成追踪

主程序会把任务名、日期和完成时的版本号保存至 `logs/task_completion.json`。任务到点时，程序先判断任务今天是否已执行；若由较旧版本完成，还会根据 `VERSION_TASK_CHANGES` 判断该任务是否受中间版本影响。受影响时重做，不受影响时跳过。

当前源代码中的映射包含下表所列正式键。v1.18 改变了 RSS 中间文件恢复、链接去重与合并可靠性，因此将 `rss` 与 `combine` 标记为受影响任务；同日从旧版升级时，相关任务可按现有追踪机制重做。

| 版本键 | 受影响任务 | 说明 |
|---|---|---|
| 1.1 | `rss`、`combine` | 日志与文件路径调整 |
| 1.2 | `blog` | 启用合集 API 博客抓取 |
| 1.3 | `blog`、`daily` | 启用 daily 与追踪机制 |
| 1.4 | `photos_update` | Windows UTF-8 输出修复 |
| 1.5 | `blog`、`photos_update` | 首次抓取与 401 处理修复 |
| 1.6 | `daily`、`blog` | 本地归档机制 |
| 1.7 | `unsplash` | Unsplash API 管理 |
| 1.8 | `maliang_register`、`blog` | 注册任务与 daily 误入博客修复 |
| 1.9 | `blog` | section 正文与分支探测修复 |
| 1.14 | `combine` | 翻译引擎修复 |
| 1.15 | `blog` | 排除 daily 文章的防御性检查 |
| 1.16 | `combine`、`blog` | 免费翻译兜底与抓取回退 |
| 1.18 | `rss`、`combine` | RSS 恢复、链接规范化与可降级翻译 |

> **历史说明：** 早期文档中曾把图片架构变更错误标作“2.0”，但正式归档顺序和源代码的正式版本变量表明其属于 **v1.11** 演进的一部分；“2.0”不是可用的正式发布版本，当前源代码中也不存在该键。

## 故障排查

### GitHub 认证失败（401 Unauthorized）

确认 `.env` 中的 `GITHUB_TOKEN` 正确、未过期且具备目标仓库的必要权限。注意系统环境变量中的同名 Token 可能覆盖 `.env` 中的值。请勿在日志、聊天或文档中暴露 Token。

### RSS 抓取结果为空或翻译失败

检查网络连接、`rss_feeds.json` 中的地址、`keywords.json` 的筛选范围，以及 `tmp/` 中是否存在 `rss_*.md`。首次启动时若发现当日中间文件，会优先复用；14:05 后发现已有文件会直接合并，不会重复抓取。翻译任务按 Gemini、GLM HTTP API、Google Free Translate 的顺序降级，并对每个引擎重试；如所有翻译引擎均失败，仍会以原始标题生成当天的 Markdown 产物。

### Blog 首次启动超时

默认流程在没有爬取记录时使用最近 30 天范围，以避免自动执行 `album:diff` 的全量遍历。若确有全量需求，请在确认网络、令牌和时间成本后手动运行 `python convert_blog.py album:diff`。

### AIGC 早报误入主博客

该问题已在 v1.8/v1.15 的防御措施中处理。先使用 `python cleanup_daily_from_blog.py --dry-run` 检查；只有确认待删除内容无误后，才执行不带参数的删除命令。

### 图片、临时文件或日志占用空间过多

检查 `tmp/`、`logs/` 与 `archived/` 的保留策略是否正常生效。不要手动删除 `last_blog_crawl.txt` 或 `logs/task_completion.json`，否则会影响爬取范围或版本感知判断。

## 更新日志

### v1.18（2026-08-18）— RSS 恢复、可靠性与链接规范化

- 主调度器固定按 **GMT+8** 判断日期和任务时间，并为 RSS、合并、daily、blog、Photos、Unsplash、马良和清理任务配置统一时限；每个子脚本的单次时限均不超过主调度器允许上限，失败或超时会重试。
- `combine-gemini.py` 支持一个或多个 RSS 中间文件；每批翻译先尝试 Gemini，失败后使用经实测可用的 GLM HTTP API，再降级到 Google Free Translate。所有引擎失败时仍以原始标题输出完整 Markdown，避免当天缺少产物。
- 首次启动会检查 GMT+8 当日 `tmp/rss_*.md`：14:05 后发现已有文件直接合并；02:00–14:05 间只有一份时仅补抓一次；没有文件时仅抓一次后合并。
- `getrss.py` 会将 Google 重定向链接解码为原始文章地址；对 Techmeme 条目保留其标题/摘要文字但改用页面中的原始报道链接；移除 URL 片段和无关追踪参数。
- 相同最终链接的多个条目只保留文字说明最长的一条，合并阶段再次按最终链接去重。
- 任务映射：`rss`、`combine`。

### v1.17（2026-08-18）— 版本与文档校正

- 以 `keepitrun-v1.16.zip` 的正式脚本为基线，将主脚本版本元数据更新为 `1.17`。
- **未改变**调度时间、任务映射、子脚本调用、配置读取、清理策略或其他业务逻辑。
- 删除可执行的 `readme.py`，将用户说明、排障说明与更新日志整合为唯一的 `readme.md`。
- 将“运行 `python readme.py` 求助”的旧提示改为“直接打开 `readme.md` 查看”。
- 更正历史“2.0”误标：其日期早于 v1.16 打包，且 v1.16 正式 `VERSION` 为 `1.16`；因此不构成 1.16 之后的程序改动。

### v1.16（2026-07-24）— 世界杯图片补齐与翻译回退

- 为缺失图片的世界杯文章补齐图片资源，并处理图片压缩流程。
- `convert_blog.py` 增加 z-ai `page_reader` 回退；常规抓取失败时可尝试回退，未安装该工具时自动跳过。
- `combine-gemini.py` 增加 Google Free Translate 兜底，形成 Gemini → GLM → Google Free Translate 的多层翻译回退策略。
- 任务映射：`combine`、`blog`。

### v1.15（2026-07-24）— 防止 daily 文章进入主博客

- 在博客文章收集和处理阶段增加 daily 标题与 slug 的防御性判断。
- 处理由历史恢复操作带回的冗余 daily 文章与图片目录。
- 任务映射：`blog`。

### v1.14（2026-07-24）— RSS 翻译引擎修复

- 修复 RSS 翻译引擎的运行问题。
- 任务映射：`combine`。

### v1.13（2026-07-05）— 内置图片压缩工具

- 内置 `piczip/oxipng.exe` 用于 PNG 无损压缩。
- JPEG 与 GIF 压缩改用 Pillow，减少对系统级工具的依赖。

### v1.12（2026-07-05）— 图片格式限制与清理

- 统一限制图片格式为 JPG、PNG、GIF；按透明度和动画状态转换 WebP、AVIF、PNG 与 GIF。
- 增加图片格式转换与压缩流程，并清理不再随包分发的旧文件。
- 任务映射：`blog`、`daily`。

### v1.11（2026-07-05）— 图片存储架构重构

- 图片引用改为相对路径，并支持按日期范围解析图片存储前缀。
- 新增图片压缩工具与上传前压缩流程。
- 这一版本在旧文档中曾被错误写成“2.0”；以归档文件名、正式版本序列和后续 v1.14–v1.16 发布记录为准，应记为 v1.11。

### v1.9（2026-07-03）— 微信正文与分支探测修复

- 修复部分微信公众号正文位于 `section` 标签时无法提取的问题。
- 清理脚本从固定 `master` 改为自动探测 `main`/`master`。
- 任务映射：`blog`。

### v1.8（2026-07-02）— 马良注册与 daily 修复

- 增加 `maliang_register.py` 定时注册任务和账号记录。
- 修复 AIGC 早报合集被 `convert_blog.py` 误纳入主博客的问题。
- 增加 `cleanup_daily_from_blog.py` 清理工具。
- 任务映射：`maliang_register`、`blog`。

### v1.7（2026-06-13）— Unsplash 管理恢复

- 重新启用基于官方 API 的 Unsplash 照片管理任务。
- 任务映射：`unsplash`。

### v1.6（2026-06-13）— 本地归档与安全打包

- blog/daily 同步成功后，将本地 Markdown 与图片移入 `archived/`。
- 发行包不再携带 `.env`，改用 `.env.example` 避免覆盖 Token。
- 任务映射：`daily`、`blog`。

### v1.5（2026-06-12）— 首次抓取与认证处理

- 修复 `photos_update.py` 的 401 认证失败提示。
- 避免博客首次自动任务默认进行耗时的 `album:diff` 全量遍历。
- 任务映射：`blog`、`photos_update`。

### v1.4（2026-06-12）— Windows UTF-8 输出

- 修复多个子脚本在 Windows 控制台输出中文或特殊字符时的编码问题。
- 将 `photos_update.py` 纳入发行包。
- 任务映射：`photos_update`。

### v1.3（2026-06-11）— 版本感知追踪与 daily

- 引入 `task_completion.json` 任务完成追踪。
- 重新启用 AIGC 早报处理任务。
- 任务映射：`blog`、`daily`。

### v1.2（2026-06-11）— 博客合集 API

- 重新启用微信公众号文章抓取。
- 改用合集 API，减少对后台 Cookie 登录的依赖。
- 任务映射：`blog`。

### v1.1（2026-06-10）— 分级清理与路径规范化

- 引入 `tmp/`、`logs/`、`archived/` 的分级清理策略。
- 统一子脚本日志与中间文件路径。
- 任务映射：`rss`、`combine`。

### v1.0（2026-04-20）— 初始正式版本

- 建立 24 小时常驻调度、RSS 抓取与合并、微信内容处理和 Photos 同步的基础能力。

## 维护注意事项

- 修改脚本前先核对 `VERSION`、`VERSION_DATE`、`VERSION_TASK_CHANGES` 与本更新日志是否一致。
- 若新版本改变了某个定时任务的结果，应审慎增加相应任务映射；这会影响当天已经完成任务是否重跑。
- 发行前确认包内不含 `.env`、日志、临时文件、账号记录、Token、Cookie 或用户生成的文章和图片。
- 用户需要帮助时，一律引导其打开 `readme.md`；不要恢复 `readme.py` 的重复文档机制。

---

文档版本：**1.18**。本文是 keepitrun 的唯一用户说明与更新日志。
