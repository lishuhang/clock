#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
keepitrun - 定时任务调度脚本 (Windows 11 / 跨平台常驻)
版本: 1.7 (2026-06-13)
基于: keepitrun-260424.py (v1.0)

每日定时任务:
  02:00  RSS 抓取 (第1次)
  14:00  RSS 抓取 (第2次)
  14:05  合并两次 RSS 抓取结果，去重翻译输出
  15:00  Photos 自动同步 (仅当脚本文件存在时启用)
  10:05  爬取最新 daily (微信公众号AIGC早报) (v1.3 重新启用)
  10:10  爬取最新 blog (微信公众号合集) (v1.2 重新启用)

v1.7 重新启用:
  12:00  Unsplash 照片管理 (使用官方 API + Access Key / Bearer Token，无需 Cookie)

v1.7 变更 (2026-06-13):
  - 重新启用 Unsplash 照片管理任务 (12:00, 每 3 天)
    · 新增 unsplash_update.py 脚本，使用官方 API 认证 (无需 Cookie)
    · 支持 Client-ID (Access Key) 公开读取 + Bearer Token 用户操作
    · 内置 Demo 等级速率限制 (50 请求/小时，脚本预留 40 次/小时)
    · 支持照片上传、收藏集管理、状态查询
    · 新增 .env.example 中 Unsplash 相关字段
  - 注意: Unsplash 官方 API 未公开上传端点，上传功能可能受限
    · 如果 API 不支持上传，需通过网页 https://unsplash.com/submit 手动上传

v1.6 变更 (2026-06-13):
  - 新增 blog/daily 文章归档机制：GitHub 同步成功后自动将本地 .md 和 images/ 移入 archived/
    · blog 生成的 YYYY-MM-DD-*.md 文件从脚本主目录移入 archived/
    · daily 生成的 _posts/*.md 文件移入 archived/_posts/
    · images/ 整个目录树移入 archived/images/
    · 与 RSS 归档一致，archived/ 中超过 30 天自动清理
  - 修复打包包含 .env 导致用户解压覆盖后 GitHub Token 丢失的问题
    · 发行包不再包含 .env，改为 .env.example 模板

v1.5 变更 (2026-06-12):
  - 修复 photos_update.py 401 认证失败时原始 traceback 崩溃，改为友好提示
  - 修复 blog 首次启动默认 album:diff 导致 8 合集全量遍历超时 600s
    · 无爬取记录时默认抓取最近 30 天 (album:YYYYMMDD)，不再用 album:diff
  - album:diff 仍可手动使用，但不作为自动调度默认值

v1.4 变更 (2026-06-12):
  - 修复所有子脚本 Windows 控制台 UnicodeEncodeError (cp1252 无法输出 emoji/中文)
  - 为 photos_update.py, convert_blog.py, convert_daily.py, getrss.py 添加 UTF-8 编码修复
  - photos_update.py 现已包含在 keepitrun 发行包中

v1.3 变更 (2026-06-11):
  - 重新启用微信公众号AIGC早报抓取 (10:05)
  - 新增版本感知任务完成追踪系统
    · 版本升级后，已完成的任务若受变更影响则自动重做
    · 任务完成记录持久化至 logs/task_completion.json
  - convert_daily.py 从 disabled/ 移回主目录

v1.2 变更 (2026-06-11):
  - 重新启用微信公众号文章抓取 (10:10)
  - 使用合集API替代公众平台后台Cookie登录 (convert_blog.py v3.0)
  - 无需Cookie即可抓取文章列表

异常处理:
  - 若某次 RSS 抓取因脚本未启动而缺失，14:05 时自动补抓
  - 输出成功后，将之前的 RSS 抓取结果移至 /archived 子文件夹
  - blog/daily 文章同步 GitHub 后，将本地文件移至 /archived 子文件夹

日志与清理:
  - 所有操作记录到 logs/ 子文件夹
  - 临时文件存放于 tmp/ 子文件夹
  - 分级自动清理:
    · tmp/   中超过 1 天的文件 → 自动删除
    · logs/  中超过 7 天的日志 → 移入 logs/archive/
    · logs/archive/ 中超过 30 天的日志 → 自动删除
    · archived/ 中超过 30 天的文件 → 自动删除

用法:
  python keepitrun.py
  (常驻运行，通过 while True 循环每 30 秒检查一次时间)
"""

import time
import re
import subprocess
import os
import sys
import shutil
import glob
import json
import logging
import threading
from datetime import date, datetime, timedelta

# ================= Windows 编码修复 =================
# Windows 默认控制台编码为 cp1252，无法输出中文等超出 Latin-1 范围的字符
# 在所有 print()/logging 输出之前，强制将 stdout/stderr 切换为 UTF-8
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
# ====================================================

# ═══════════════════════════════════════════════════════════════
# 版本信息
# ═══════════════════════════════════════════════════════════════

VERSION = "1.7"
VERSION_DATE = "2026-06-13"

# ═══════════════════════════════════════════════════════════════
# 配置区域
# ═══════════════════════════════════════════════════════════════

# 脚本所在目录（所有子脚本也在此目录）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 子脚本文件名 (v1.1 已去除文件名中的时间戳)
RSS_SCRIPT = "getrss.py"
COMBINE_SCRIPT = "combine-gemini.py"

# 已重新启用的子脚本 (v1.2: 微信公众号合集抓取已恢复)
BLOG_SCRIPT = "convert_blog.py"  # v3.0: 使用合集API，无需Cookie

# 已重新启用的子脚本 (v1.3: 微信公众号AIGC早报已恢复)
DAILY_SCRIPT = "convert_daily.py"  # 微信公众号AIGC早报 (v1.3 重新启用)

# RSS 抓取结果文件匹配模式
RSS_FILE_PATTERN = "rss_*.md"

# 子目录
ARCHIVED_DIR = os.path.join(SCRIPT_DIR, "archived")
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
LOG_ARCHIVE_DIR = os.path.join(LOG_DIR, "archive")
TMP_DIR = os.path.join(SCRIPT_DIR, "tmp")

# 清理阈值 (天)
TMP_RETENTION_DAYS = 1       # tmp/ 中文件保留 1 天
LOG_ARCHIVE_DAYS = 7         # logs/ 中文件 7 天后移入 archive
LOG_DELETE_DAYS = 30         # logs/archive/ 中文件 30 天后删除
ARCHIVED_RETENTION_DAYS = 30 # archived/ 中文件保留 30 天

# 上次成功 blog 爬取日期记录文件 (v1.2 重新启用)
BLOG_LAST_CRAWL_FILE = os.path.join(SCRIPT_DIR, "last_blog_crawl.txt")

# Unsplash 照片管理脚本 (v1.7 重新启用)
UNSPLASH_SCRIPT = "unsplash_update.py"  # 同目录下的脚本
UNSPLASH_LAST_RUN_FILE = os.path.join(SCRIPT_DIR, "last_unsplash_run.txt")
UNSPLASH_INTERVAL_DAYS = 3  # 每 3 天运行一次

# Photos 同步脚本路径
# 搜索顺序: 1. 同目录下的 photos_update.py  2. 同级 photos_update/ 文件夹  3. 自定义绝对路径

def _resolve_photos_path():
    """解析 Photos 同步脚本路径，按优先级搜索多个可能位置"""
    # 1. 同目录下
    local = os.path.join(SCRIPT_DIR, "photos_update.py")
    if os.path.isfile(local):
        return local
    # 2. 同级 photos_update/ 文件夹
    sibling = os.path.join(SCRIPT_DIR, "..", "photos_update", "photos_update.py")
    if os.path.isfile(sibling):
        return os.path.abspath(sibling)
    # 3. 常见 Windows 路径 (可按需修改)
    win_path = os.path.join(os.path.expanduser("~"), "Dropbox", "WORKS", "SOFT", "AI-Python", "photos_update", "photos_update.py")
    if os.path.isfile(win_path):
        return win_path
    return ""

PHOTOS_UPDATE_SCRIPT = _resolve_photos_path()

# 每日首次启动标记文件
DAILY_BOOT_FLAG = os.path.join(LOG_DIR, ".boot_flag")

# 时间检查间隔（秒）
CHECK_INTERVAL = 30

# ═══════════════════════════════════════════════════════════════
# 版本感知任务完成追踪
# ═══════════════════════════════════════════════════════════════

# 版本变更影响映射: 哪些版本更新影响了哪些任务
# 当版本升级时，如果今天已完成的任务在此列表中，需要重做
VERSION_TASK_CHANGES = {
    "1.1": {"rss", "combine"},           # v1.1 改了日志和文件路径
    "1.2": {"blog"},                     # v1.2 重新启用blog，改用合集API
    "1.3": {"blog", "daily"},            # v1.3 重新启用daily，blog日志前缀变更
    "1.4": {"photos_update"},        # v1.4 修复所有子脚本 Windows UTF-8 编码问题
    "1.5": {"blog", "photos_update"},  # v1.5 修复 blog 首次启动超时 + photos_update 401 处理
    "1.6": {"daily", "blog"},          # v1.6 新增 blog/daily 文章归档机制
    "1.7": {"unsplash"},              # v1.7 重新启用 Unsplash (改用 API 认证)
}

TASK_COMPLETION_FILE = os.path.join(LOG_DIR, "task_completion.json")

# 全局日志对象 (由 setup_logging() 初始化)
logger = None


def load_task_completion():
    """从JSON文件加载任务完成记录"""
    if os.path.isfile(TASK_COMPLETION_FILE):
        try:
            with open(TASK_COMPLETION_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_task_completion(records):
    """保存任务完成记录到JSON文件"""
    os.makedirs(os.path.dirname(TASK_COMPLETION_FILE), exist_ok=True)
    try:
        with open(TASK_COMPLETION_FILE, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
    except OSError as e:
        if logger:
            logger.error(f"保存任务完成记录失败: {e}")


def record_task_done(task_name):
    """记录任务今日已完成（附带当前版本号）"""
    records = load_task_completion()
    today_str = date.today().strftime("%Y-%m-%d")
    if task_name not in records:
        records[task_name] = {}
    records[task_name][today_str] = VERSION
    save_task_completion(records)
    if logger:
        logger.debug(f"记录任务完成: {task_name} @ {today_str} (v{VERSION})")


def should_task_redo(task_name):
    """检查任务是否需要因版本变更而重做

    返回: (should_run, reason)
    - should_run=True, reason="not_done_today" -- 任务今日未完成
    - should_run=True, reason="version_changed" -- 任务由受影响旧版本完成，需重做
    - should_run=False, reason="already_done" -- 任务已由当前版本或未受影响版本完成
    """
    records = load_task_completion()
    today_str = date.today().strftime("%Y-%m-%d")

    # 检查任务今天是否已完成
    task_records = records.get(task_name, {})
    done_version = task_records.get(today_str)

    if not done_version:
        return True, "not_done_today"

    if done_version == VERSION:
        return False, "already_done"

    # 检查已完成版本与当前版本之间是否有变更影响了该任务
    changed = get_tasks_changed_between(done_version, VERSION)
    if task_name in changed:
        return True, f"version_changed({done_version}->{VERSION})"

    return False, "already_done_unchanged"


def get_tasks_changed_between(old_version, new_version):
    """获取两个版本之间变更的任务名称集合"""
    changed = set()
    # 按版本号排序遍历
    all_versions = sorted(VERSION_TASK_CHANGES.keys(), key=lambda v: tuple(int(x) for x in v.split(".")))
    for v in all_versions:
        v_tuple = tuple(int(x) for x in v.split("."))
        old_tuple = tuple(int(x) for x in old_version.split("."))
        new_tuple = tuple(int(x) for x in new_version.split("."))
        if old_tuple < v_tuple <= new_tuple:
            changed.update(VERSION_TASK_CHANGES.get(v, set()))
    return changed


# ═══════════════════════════════════════════════════════════════
# 日志系统
# ═══════════════════════════════════════════════════════════════

def setup_logging():
    """初始化日志系统：文件+控制台，统一存放于 logs/ 目录"""
    global logger
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(LOG_ARCHIVE_DIR, exist_ok=True)

    log_name = datetime.now().strftime("%Y%m%d") + ".log"
    log_path = os.path.join(LOG_DIR, log_name)

    logger = logging.getLogger("keepitrun")
    # 防止重复添加 handler
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 文件 handler（追加模式，同一天同一文件）
    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)

    # 控制台 handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


def cleanup_tmp(logger):
    """删除 tmp/ 中超过 TMP_RETENTION_DAYS 天的文件

    tmp/ 目录存放 RSS 抓取中间结果等临时文件，
    超过 1 天的文件可安全删除（已被合并或归档）。
    """
    if not os.path.isdir(TMP_DIR):
        return

    cutoff = datetime.now() - timedelta(days=TMP_RETENTION_DAYS)
    deleted = 0

    for f in os.listdir(TMP_DIR):
        filepath = os.path.join(TMP_DIR, f)
        if not os.path.isfile(filepath):
            continue
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(filepath))
            if mtime < cutoff:
                os.remove(filepath)
                deleted += 1
        except OSError:
            continue

    if deleted > 0:
        logger.info(f"tmp/ 清理: 删除了 {deleted} 个超过 {TMP_RETENTION_DAYS} 天的临时文件")


def cleanup_logs(logger):
    """分级清理日志:
    1. logs/ 中超过 LOG_ARCHIVE_DAYS 天的日志 → 移入 logs/archive/
    2. logs/archive/ 中超过 LOG_DELETE_DAYS 天的日志 → 删除
    """
    os.makedirs(LOG_ARCHIVE_DIR, exist_ok=True)

    # 阶段1: 移动旧日志到 archive
    if os.path.isdir(LOG_DIR):
        archive_cutoff = datetime.now() - timedelta(days=LOG_ARCHIVE_DAYS)
        moved = 0

        for log_file in glob.glob(os.path.join(LOG_DIR, "*.log")):
            # 跳过 archive 子目录中的文件
            if LOG_ARCHIVE_DIR in log_file:
                continue
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(log_file))
                if mtime < archive_cutoff:
                    dest = os.path.join(LOG_ARCHIVE_DIR, os.path.basename(log_file))
                    # 避免覆盖同名文件
                    if os.path.exists(dest):
                        base, ext = os.path.splitext(os.path.basename(log_file))
                        dest = os.path.join(LOG_ARCHIVE_DIR, f"{base}_{int(time.time())}{ext}")
                    shutil.move(log_file, dest)
                    moved += 1
            except OSError:
                continue

        if moved > 0:
            logger.info(f"日志归档: 移动了 {moved} 个超过 {LOG_ARCHIVE_DAYS} 天的日志到 logs/archive/")

    # 阶段2: 删除过旧的归档日志
    if os.path.isdir(LOG_ARCHIVE_DIR):
        delete_cutoff = datetime.now() - timedelta(days=LOG_DELETE_DAYS)
        deleted = 0

        for log_file in glob.glob(os.path.join(LOG_ARCHIVE_DIR, "*.log")):
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(log_file))
                if mtime < delete_cutoff:
                    os.remove(log_file)
                    deleted += 1
            except OSError:
                continue

        if deleted > 0:
            logger.info(f"日志清理: 删除了 {deleted} 个超过 {LOG_DELETE_DAYS} 天的归档日志")


def cleanup_archived(logger):
    """删除 archived/ 中超过 ARCHIVED_RETENTION_DAYS 天的文件

    v1.6: 支持递归清理子目录（images/、_posts/ 等），
    删除过期文件后自动清理空目录。
    """
    if not os.path.isdir(ARCHIVED_DIR):
        return

    cutoff = datetime.now() - timedelta(days=ARCHIVED_RETENTION_DAYS)
    deleted = 0

    # 递归清理所有子目录中的过期文件
    deleted += cleanup_archived_tree(logger, ARCHIVED_DIR, cutoff)

    if deleted > 0:
        logger.info(f"archived/ 清理: 删除了 {deleted} 个超过 {ARCHIVED_RETENTION_DAYS} 天的归档文件")


def run_all_cleanup(logger):
    """执行全部清理任务"""
    cleanup_tmp(logger)
    cleanup_logs(logger)
    cleanup_archived(logger)


def cleanup_archived_tree(logger, dir_path, cutoff):
    """递归删除目录树中超过 cutoff 的文件，并清理空目录"""
    if not os.path.isdir(dir_path):
        return 0
    deleted = 0
    for root, dirs, files in os.walk(dir_path, topdown=False):
        for fname in files:
            fpath = os.path.join(root, fname)
            try:
                mtime = datetime.fromtimestamp(os.path.getmtime(fpath))
                if mtime < cutoff:
                    os.remove(fpath)
                    deleted += 1
            except OSError:
                continue
        # 清理空目录（不删除根目录本身）
        if root != dir_path:
            try:
                if not os.listdir(root):
                    os.rmdir(root)
            except OSError:
                pass
    return deleted


def archive_blog_daily_files(logger):
    """将 blog/daily 脚本生成的本地文件移动到 archived/ 目录

    这些文件已同步到 GitHub，本地副本移至 archived/ 以备后续自动清理。
    与 archive_rss_files() 机制一致，确保脚本主目录不被散放的文章文件污染。

    移动范围:
    1. blog 生成的 YYYY-MM-DD-*.md 文件（排除 RSS 合并输出 YYYYMMDD-HHMMSS.md）
    2. daily 生成的 _posts/ 目录内容
    3. images/ 目录（blog 和 daily 共享的图片本地副本）
    """
    os.makedirs(ARCHIVED_DIR, exist_ok=True)
    moved = 0

    # 1. 移动 blog 生成的 .md 文件（YYYY-MM-DD-*.md，排除 RSS 合并结果）
    for f in glob.glob(os.path.join(SCRIPT_DIR, "????-??-??-*.md")):
        basename = os.path.basename(f)
        # 排除 RSS 合并输出 (格式: YYYYMMDD-HHMMSS.md)
        if re.match(r'\d{8}-\d{6}\.md$', basename):
            continue
        try:
            dest = os.path.join(ARCHIVED_DIR, basename)
            if os.path.exists(dest):
                base, ext = os.path.splitext(basename)
                dest = os.path.join(ARCHIVED_DIR, f"{base}_{int(time.time())}{ext}")
            shutil.move(f, dest)
            moved += 1
        except Exception as e:
            logger.error(f"归档 blog 文件失败 {f}: {e}")

    # 2. 移动 _posts/ 目录内容到 archived/_posts/
    posts_dir = os.path.join(SCRIPT_DIR, "_posts")
    if os.path.isdir(posts_dir):
        archived_posts = os.path.join(ARCHIVED_DIR, "_posts")
        os.makedirs(archived_posts, exist_ok=True)
        for f in glob.glob(os.path.join(posts_dir, "*.md")):
            basename = os.path.basename(f)
            try:
                dest = os.path.join(archived_posts, basename)
                if os.path.exists(dest):
                    base, ext = os.path.splitext(basename)
                    dest = os.path.join(archived_posts, f"{base}_{int(time.time())}{ext}")
                shutil.move(f, dest)
                moved += 1
            except Exception as e:
                logger.error(f"归档 daily 文件失败 {f}: {e}")
        # 如果 _posts/ 目录为空，删除它
        try:
            if not os.listdir(posts_dir):
                os.rmdir(posts_dir)
        except OSError:
            pass

    # 3. 移动 images/ 目录到 archived/images/
    images_dir = os.path.join(SCRIPT_DIR, "images")
    if os.path.isdir(images_dir):
        archived_images = os.path.join(ARCHIVED_DIR, "images")
        if os.path.exists(archived_images):
            # 目标已存在：合并目录（将 images/ 子树合并到 archived/images/）
            try:
                shutil.copytree(images_dir, archived_images, dirs_exist_ok=True)
                shutil.rmtree(images_dir)
                moved += 1
            except Exception as e:
                logger.error(f"合并 images 目录失败: {e}")
        else:
            try:
                shutil.move(images_dir, archived_images)
                moved += 1
            except Exception as e:
                logger.error(f"归档 images 目录失败: {e}")

    if moved > 0:
        logger.info(f"已将 {moved} 个 blog/daily 文件/目录归档到 {ARCHIVED_DIR}")


# ═══════════════════════════════════════════════════════════════
# 子脚本执行
# ═══════════════════════════════════════════════════════════════

def run_script(script_name, args=None, timeout=600, stdin_input=None):
    """执行子脚本，返回 (success: bool, returncode: int)

    参数:
      script_name: 脚本文件名（在 SCRIPT_DIR 中查找）
      args: 传给脚本的参数列表
      timeout: 超时秒数（默认10分钟）
      stdin_input: 传给子脚本 stdin 的字符串
    """
    script_path = os.path.join(SCRIPT_DIR, script_name)
    if not os.path.isfile(script_path):
        logger.error(f"脚本不存在: {script_path}")
        return False, -1

    cmd = [sys.executable, script_path]
    if args:
        cmd.extend(args)

    logger.info(f"执行: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            cwd=SCRIPT_DIR,
            input=stdin_input,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace"
        )

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                logger.debug(f"  [{script_name}] {line}")
        if result.stderr:
            for line in result.stderr.strip().split("\n"):
                logger.warning(f"  [{script_name}:stderr] {line}")

        if result.returncode != 0:
            logger.error(f"脚本 {script_name} 返回非零退出码: {result.returncode}")
            return False, result.returncode

        return True, result.returncode

    except subprocess.TimeoutExpired:
        logger.error(f"脚本 {script_name} 执行超时 ({timeout}秒)，已终止")
        return False, -1
    except Exception as e:
        logger.error(f"执行脚本 {script_name} 时发生异常: {e}")
        return False, -1


# ═══════════════════════════════════════════════════════════════
# RSS 抓取结果管理
# ═══════════════════════════════════════════════════════════════

def get_today_rss_files():
    """获取今天的 RSS 抓取结果文件列表 (从 tmp/ 目录查找)"""
    today = date.today().strftime("%Y-%m-%d")
    pattern = os.path.join(TMP_DIR, f"rss_{today}_*.md")
    return sorted(glob.glob(pattern))


def count_today_rss_files():
    """统计今天的 RSS 抓取结果文件数量"""
    return len(get_today_rss_files())


def archive_rss_files(logger):
    """将所有 RSS 抓取结果文件移动到 archived 子文件夹"""
    os.makedirs(ARCHIVED_DIR, exist_ok=True)

    # 同时检查 tmp/ 和根目录（兼容旧版文件）
    rss_files = glob.glob(os.path.join(TMP_DIR, RSS_FILE_PATTERN))
    rss_files += glob.glob(os.path.join(SCRIPT_DIR, RSS_FILE_PATTERN))
    # 去重
    rss_files = list(set(rss_files))
    moved = 0

    for f in rss_files:
        try:
            dest = os.path.join(ARCHIVED_DIR, os.path.basename(f))
            if os.path.exists(dest):
                # 避免覆盖：添加时间戳后缀
                base, ext = os.path.splitext(os.path.basename(f))
                dest = os.path.join(ARCHIVED_DIR, f"{base}_{int(time.time())}{ext}")
            shutil.move(f, dest)
            moved += 1
        except Exception as e:
            logger.error(f"归档文件失败 {f}: {e}")

    if moved > 0:
        logger.info(f"已将 {moved} 个 RSS 抓取结果文件移动到 {ARCHIVED_DIR}")


# ═══════════════════════════════════════════════════════════════
# Photos 自动同步
# ═══════════════════════════════════════════════════════════════

def is_photos_update_enabled():
    """检查 Photos 同步脚本是否存在"""
    exists = os.path.isfile(PHOTOS_UPDATE_SCRIPT)
    if not exists and PHOTOS_UPDATE_SCRIPT:
        logger.debug(f"Photos 同步脚本未找到: {PHOTOS_UPDATE_SCRIPT}")
    return exists


def run_photos_update():
    """运行 Photos 自动同步脚本

    仅当脚本文件存在时才会被调用。
    脚本工作目录设为脚本所在目录，
    以便它找到同目录下的 .env 文件。
    无参数运行 = 自动检测模式（检查图片库是否有新内容需要同步）。
    """
    logger.info("-- 开始运行 Photos 自动同步 --")
    logger.info(f"  脚本路径: {PHOTOS_UPDATE_SCRIPT}")

    photos_dir = os.path.dirname(os.path.abspath(PHOTOS_UPDATE_SCRIPT))

    try:
        result = subprocess.run(
            [sys.executable, os.path.abspath(PHOTOS_UPDATE_SCRIPT)],
            cwd=photos_dir,
            capture_output=True,
            text=True,
            timeout=300,
            encoding="utf-8",
            errors="replace"
        )

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                logger.info(f"  [photos_update] {line}")
        if result.stderr:
            for line in result.stderr.strip().split("\n"):
                logger.warning(f"  [photos_update:stderr] {line}")

        if result.returncode != 0:
            logger.error(f"Photos 同步脚本返回非零退出码: {result.returncode}")
            return False

        logger.info("Photos 自动同步完成")
        return True

    except subprocess.TimeoutExpired:
        logger.error("Photos 同步脚本执行超时 (300秒)")
        return False
    except Exception as e:
        logger.error(f"运行 Photos 同步脚本时发生异常: {e}")
        return False


# ═══════════════════════════════════════════════════════════════
# Unsplash 照片管理 (v1.7 重新启用)
# ═══════════════════════════════════════════════════════════════

def is_unsplash_enabled():
    """检查 Unsplash 脚本是否存在且配置了 Access Key"""
    script_path = os.path.join(SCRIPT_DIR, UNSPLASH_SCRIPT)
    if not os.path.isfile(script_path):
        return False
    # 检查 .env 中是否有 UNSPLASH_ACCESS_KEY
    env_path = os.path.join(SCRIPT_DIR, ".env")
    if os.path.isfile(env_path):
        try:
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("UNSPLASH_ACCESS_KEY="):
                        val = line.split("=", 1)[1].strip()
                        if val and not val.startswith("your_"):
                            return True
        except OSError:
            pass
    return False


def should_run_unsplash():
    """检查 Unsplash 是否应该运行 (间隔天数检查)"""
    if not is_unsplash_enabled():
        return False

    if not os.path.isfile(UNSPLASH_LAST_RUN_FILE):
        return True

    try:
        with open(UNSPLASH_LAST_RUN_FILE, "r", encoding="utf-8") as f:
            last_run_str = f.read().strip()
        if not last_run_str:
            return True
        last_run = datetime.strptime(last_run_str, "%Y-%m-%d").date()
        days_since = (date.today() - last_run).days
        return days_since >= UNSPLASH_INTERVAL_DAYS
    except (ValueError, OSError):
        return True


def run_unsplash_update():
    """运行 Unsplash 照片管理脚本

    仅当脚本文件存在且配置了 Access Key 时才会被调用。
    每 3 天运行一次 (可配置 UNSPLASH_INTERVAL_DAYS)。
    脚本工作目录设为脚本所在目录，以便找到 .env 文件。
    """
    script_path = os.path.join(SCRIPT_DIR, UNSPLASH_SCRIPT)
    logger.info("-- 开始运行 Unsplash 照片管理 --")
    logger.info(f"  脚本路径: {script_path}")
    logger.info(f"  运行间隔: 每 {UNSPLASH_INTERVAL_DAYS} 天")

    try:
        result = subprocess.run(
            [sys.executable, script_path],
            cwd=SCRIPT_DIR,
            capture_output=True,
            text=True,
            timeout=600,  # Unsplash 可能有速率限制等待，给 10 分钟
            encoding="utf-8",
            errors="replace"
        )

        if result.stdout:
            for line in result.stdout.strip().split("\n"):
                logger.info(f"  [unsplash] {line}")
        if result.stderr:
            for line in result.stderr.strip().split("\n"):
                logger.warning(f"  [unsplash:stderr] {line}")

        if result.returncode != 0:
            logger.error(f"Unsplash 脚本返回非零退出码: {result.returncode}")
            return False

        # 记录运行日期
        try:
            with open(UNSPLASH_LAST_RUN_FILE, "w", encoding="utf-8") as f:
                f.write(date.today().strftime("%Y-%m-%d"))
        except OSError:
            pass

        logger.info("Unsplash 照片管理完成")
        return True

    except subprocess.TimeoutExpired:
        logger.error("Unsplash 脚本执行超时 (600秒)")
        return False
    except Exception as e:
        logger.error(f"运行 Unsplash 脚本时发生异常: {e}")
        return False


# ═══════════════════════════════════════════════════════════════
# RSS 合并与去重翻译
# ═══════════════════════════════════════════════════════════════

def run_combine():
    """合并今天的 RSS 抓取结果，去重翻译输出

    逻辑:
    1. 检查今天有几份 RSS 抓取结果
    2. 如果不足2份，自动补抓直到有2份
    3. 合并所有结果并执行去重翻译
    4. 合并成功后，将 RSS 抓取结果移至 archived/
    """
    logger.info("-- 开始合并 RSS 结果 --")

    rss_files = get_today_rss_files()

    # 如果不足2份，自动补抓
    attempts = 0
    max_attempts = 3

    while len(rss_files) < 2 and attempts < max_attempts:
        logger.warning(
            f"今天的 RSS 抓取结果不足2份 (当前 {len(rss_files)} 份)，"
            f"自动补抓第 {attempts + 1} 次..."
        )
        success, _ = run_script(RSS_SCRIPT, timeout=300)
        if success:
            time.sleep(2)
            rss_files = get_today_rss_files()
        attempts += 1

    if len(rss_files) < 1:
        logger.error("无法获取任何 RSS 抓取结果，合并取消")
        return False

    if len(rss_files) < 2:
        logger.warning(
            f"仅获取到 {len(rss_files)} 份 RSS 抓取结果，"
            f"将使用现有结果进行合并"
        )

    # 执行合并 (传入文件名，脚本在 SCRIPT_DIR 下运行)
    file_args = [os.path.basename(f) for f in rss_files]
    success, _ = run_script(COMBINE_SCRIPT, args=file_args, timeout=300)

    if success:
        logger.info("RSS 合并去重翻译完成")
        archive_rss_files(logger)
        return True
    else:
        logger.error("RSS 合并去重翻译失败")
        return False


# ═══════════════════════════════════════════════════════════════
# 每日首次启动：立即执行全部任务
# ═══════════════════════════════════════════════════════════════

def is_first_boot_today():
    """判断今天是否是首次启动 keepitrun"""
    try:
        if os.path.isfile(DAILY_BOOT_FLAG):
            with open(DAILY_BOOT_FLAG, "r", encoding="utf-8") as f:
                flag_date = f.read().strip()
                today_str = date.today().strftime("%Y-%m-%d")
                return flag_date != today_str
    except OSError:
        pass
    return True


def mark_boot_today():
    """标记今天已经启动过 keepitrun"""
    os.makedirs(LOG_DIR, exist_ok=True)
    try:
        with open(DAILY_BOOT_FLAG, "w", encoding="utf-8") as f:
            f.write(date.today().strftime("%Y-%m-%d"))
    except OSError as e:
        logger.error(f"写入启动标记失败: {e}")


def run_first_boot_tasks():
    """每日首次启动时立即执行全部任务

    场景: Windows 更新重启、脚本意外退出后重新启动等。
    """
    logger.info("=" * 60)
    logger.info("检测到今日首次启动，立即执行全部任务")
    logger.info("=" * 60)

    # 1. RSS 抓取第1次
    logger.info("[首次启动] 步骤 1/6: RSS 抓取 (第1次)")
    success1, _ = run_script(RSS_SCRIPT, timeout=300)
    if success1:
        record_task_done("rss_1")
        logger.info("[首次启动] RSS 第1次抓取完成")
    else:
        logger.warning("[首次启动] RSS 第1次抓取失败，继续尝试第2次")
    time.sleep(3)

    # 2. RSS 抓取第2次
    logger.info("[首次启动] 步骤 2/6: RSS 抓取 (第2次)")
    success2, _ = run_script(RSS_SCRIPT, timeout=300)
    if success2:
        record_task_done("rss_2")
        logger.info("[首次启动] RSS 第2次抓取完成")
    else:
        logger.warning("[首次启动] RSS 第2次抓取失败")
    time.sleep(3)

    # 3. 合并去重翻译
    logger.info("[首次启动] 步骤 3/6: 合并去重翻译 RSS 结果")
    combine_ok = run_combine()
    if combine_ok:
        record_task_done("combine")
        logger.info("[首次启动] RSS 合并去重翻译完成")
    else:
        logger.warning("[首次启动] RSS 合并去重翻译失败，跳过")

    # 4. 爬取最新 daily + blog
    logger.info("[首次启动] 步骤 4/6: 爬取最新 daily + blog")
    daily_path = os.path.join(SCRIPT_DIR, DAILY_SCRIPT)
    if os.path.isfile(daily_path):
        success_daily, _ = run_script(DAILY_SCRIPT, timeout=300)
        if success_daily:
            record_task_done("daily")
    else:
        logger.info("[首次启动] Daily脚本不存在，跳过")
    time.sleep(2)

    blog_path = os.path.join(SCRIPT_DIR, BLOG_SCRIPT)
    if os.path.isfile(blog_path):
        # 读取上次成功爬取日期
        last_date = ""
        if os.path.isfile(BLOG_LAST_CRAWL_FILE):
            try:
                with open(BLOG_LAST_CRAWL_FILE, "r", encoding="utf-8") as f:
                    last_date = f.read().strip()
            except OSError:
                pass
        # 构建参数
        # 如果没有上次爬取日期记录，默认抓取最近30天（而非 album:diff，避免8合集全量遍历超时）
        args = []
        if last_date and re.match(r'\d{8}$', last_date):
            args.append(f"album:{last_date}")
        else:
            fallback_date = (date.today() - timedelta(days=30)).strftime("%Y%m%d")
            args.append(f"album:{fallback_date}")
            logger.info(f"[首次启动] 无上次爬取记录，默认抓取最近30天 (album:{fallback_date})")
        success_blog, _ = run_script(BLOG_SCRIPT, args=args, timeout=600)
        if success_blog:
            record_task_done("blog")
            # 更新上次爬取日期
            try:
                os.makedirs(os.path.dirname(BLOG_LAST_CRAWL_FILE), exist_ok=True)
                with open(BLOG_LAST_CRAWL_FILE, "w", encoding="utf-8") as f:
                    f.write(date.today().strftime("%Y%m%d"))
            except OSError:
                pass
    else:
        logger.info("[首次启动] Blog脚本不存在，跳过")

    # 4.5 归档 blog/daily 本地文件（两者都执行完后统一归档）
    archive_blog_daily_files(logger)

    # 5. Photos 同步
    logger.info("[首次启动] 步骤 5/6: Photos 自动同步")
    if is_photos_update_enabled():
        run_photos_update()
        record_task_done("photos_update")
    else:
        logger.info("[首次启动] Photos 同步脚本不存在，跳过")

    # 6. Unsplash 照片管理 (v1.7)
    logger.info("[首次启动] 步骤 6/6: Unsplash 照片管理")
    if should_run_unsplash():
        success = run_unsplash_update()
        if success:
            record_task_done("unsplash")
    else:
        logger.info("[首次启动] Unsplash 未启用或间隔未到，跳过")

    logger.info("=" * 60)
    logger.info("首次启动全部任务执行完毕，进入定时调度模式")
    logger.info("=" * 60)


# ═══════════════════════════════════════════════════════════════
# 已执行任务记录（防止同一分钟内重复执行）
# ═══════════════════════════════════════════════════════════════

_executed_tasks = {}


def should_run(task_name):
    """判断某个任务今天是否应该执行

    综合两个判断:
    1. 同一分钟内不重复执行 (内存去重)
    2. 版本升级后，如果任务已被旧版本完成且版本变更影响了该任务，需要重做
    """
    today = date.today().strftime("%Y-%m-%d")
    key = f"{task_name}_{today}"

    # 内存去重: 同一天内同一任务只执行一次 (除非版本变更需要重做)
    if key in _executed_tasks:
        # 已执行过，检查版本是否需要重做
        should_redo, reason = should_task_redo(task_name)
        if should_redo:
            logger.info(f"任务 {task_name} 需要重做: {reason}")
            return True
        return False

    # 检查是否今天已被旧版本完成
    should_redo, reason = should_task_redo(task_name)
    if not should_redo:
        logger.info(f"任务 {task_name} 今天已完成 (v{load_task_completion().get(task_name, {}).get(today, '?')}), {reason}")
        return False

    _executed_tasks[key] = True
    return True


# ═══════════════════════════════════════════════════════════════
# 主循环
# ═══════════════════════════════════════════════════════════════

def main_loop():
    """主循环：每 30 秒检查一次当前时间，触发对应任务"""

    logger.info("=" * 60)
    logger.info(f"keepitrun v{VERSION} 启动")
    logger.info(f"脚本目录: {SCRIPT_DIR}")
    logger.info(f"日志目录: {LOG_DIR}")
    logger.info(f"临时目录: {TMP_DIR}")
    logger.info(f"归档目录: {ARCHIVED_DIR}")
    logger.info("")
    logger.info("清理策略:")
    logger.info(f"  tmp/       > {TMP_RETENTION_DAYS} 天  -> 删除")
    logger.info(f"  logs/      > {LOG_ARCHIVE_DAYS} 天  -> 移入 logs/archive/")
    logger.info(f"  logs/archive/ > {LOG_DELETE_DAYS} 天 -> 删除")
    logger.info(f"  archived/  > {ARCHIVED_RETENTION_DAYS} 天 -> 删除")
    logger.info("")
    logger.info("每日任务计划:")
    logger.info("  02:00 - RSS 抓取 (第1次)")
    logger.info("  14:00 - RSS 抓取 (第2次)")
    logger.info("  14:05 - 合并去重翻译 RSS 结果")
    if is_photos_update_enabled():
        logger.info(f"  15:00 - Photos 自动同步 ({PHOTOS_UPDATE_SCRIPT})")
    else:
        logger.info("  15:00 - Photos 自动同步 [未启用: 脚本未找到]")
    logger.info("")
    logger.info("已启用任务 (v1.3):")
    daily_path = os.path.join(SCRIPT_DIR, DAILY_SCRIPT)
    if os.path.isfile(daily_path):
        logger.info(f"  10:05 - 爬取最新 daily  [{DAILY_SCRIPT}]")
    else:
        logger.info(f"  10:05 - 爬取最新 daily  [未找到: {DAILY_SCRIPT}]")
    blog_path = os.path.join(SCRIPT_DIR, BLOG_SCRIPT)
    if os.path.isfile(blog_path):
        logger.info(f"  10:10 - 爬取最新 blog   [{BLOG_SCRIPT}]")
    else:
        logger.info(f"  10:10 - 爬取最新 blog   [未找到: {BLOG_SCRIPT}]")
    logger.info("")
    # Unsplash 照片管理 (v1.7 重新启用)
    if is_unsplash_enabled():
        logger.info(f"  12:00 - Unsplash 照片管理  [{UNSPLASH_SCRIPT}] (每 {UNSPLASH_INTERVAL_DAYS} 天)")
    else:
        logger.info("  12:00 - Unsplash 照片管理  [未启用: 脚本未找到或未配置 Access Key]")
    logger.info("")
    logger.info("版本感知追踪: 已启用 (task_completion.json)")
    logger.info("=" * 60)

    # 启动时执行清理
    run_all_cleanup(logger)

    # 确保必要目录存在
    os.makedirs(TMP_DIR, exist_ok=True)
    os.makedirs(ARCHIVED_DIR, exist_ok=True)

    # -- 每日首次启动：立即执行全部任务 --
    if is_first_boot_today():
        run_first_boot_tasks()
        mark_boot_today()
    else:
        logger.info("今日已启动过，跳过首次启动任务，进入定时调度模式")

    last_cleanup_date = date.today()

    while True:
        try:
            current_time = time.strftime("%H:%M")
            current_date = date.today()

            # 每天凌晨第一次循环时执行清理
            if current_date != last_cleanup_date:
                run_all_cleanup(logger)
                last_cleanup_date = current_date

            # -- 02:00 RSS 抓取 (第1次) --
            if current_time == "02:00" and should_run("rss_1"):
                logger.info(">>> 触发 02:00 RSS 抓取 (第1次)")
                success, _ = run_script(RSS_SCRIPT, timeout=300)
                if success:
                    record_task_done("rss_1")
                time.sleep(60)

            # -- 14:00 RSS 抓取 (第2次) --
            elif current_time == "14:00" and should_run("rss_2"):
                logger.info(">>> 触发 14:00 RSS 抓取 (第2次)")
                success, _ = run_script(RSS_SCRIPT, timeout=300)
                if success:
                    record_task_done("rss_2")
                time.sleep(60)

            # -- 14:05 合并去重翻译 --
            elif current_time == "14:05" and should_run("combine"):
                logger.info(">>> 触发 14:05 合并去重翻译 RSS 结果")
                combine_ok = run_combine()
                if combine_ok:
                    record_task_done("combine")
                time.sleep(60)

            # -- 10:05 爬取最新 daily (v1.3 重新启用) --
            elif current_time == "10:05" and should_run("daily"):
                daily_path = os.path.join(SCRIPT_DIR, DAILY_SCRIPT)
                if os.path.isfile(daily_path):
                    logger.info(">>> 触发 10:05 爬取最新 daily")
                    success, _ = run_script(DAILY_SCRIPT, timeout=300)
                    if success:
                        record_task_done("daily")
                        # daily 成功后归档本地文件
                        archive_blog_daily_files(logger)
                else:
                    logger.warning(f"Daily脚本不存在: {daily_path}")
                time.sleep(60)

            # -- 10:10 爬取最新 blog (v1.2 重新启用) --
            elif current_time == "10:10" and should_run("blog"):
                blog_path = os.path.join(SCRIPT_DIR, BLOG_SCRIPT)
                if os.path.isfile(blog_path):
                    logger.info(">>> 触发 10:10 爬取最新 blog")
                    # 读取上次成功爬取日期
                    last_date = ""
                    if os.path.isfile(BLOG_LAST_CRAWL_FILE):
                        try:
                            with open(BLOG_LAST_CRAWL_FILE, "r", encoding="utf-8") as f:
                                last_date = f.read().strip()
                        except OSError:
                            pass
                    # 构建参数
                    # 如果没有上次爬取日期记录，默认抓取最近30天
                    args = []
                    if last_date and re.match(r'\d{8}$', last_date):
                        args.append(f"album:{last_date}")
                    else:
                        fallback_date = (date.today() - timedelta(days=30)).strftime("%Y%m%d")
                        args.append(f"album:{fallback_date}")
                        logger.info(f">>> 无上次爬取记录，默认抓取最近30天 (album:{fallback_date})")
                    success, _ = run_script(BLOG_SCRIPT, args=args, timeout=600)
                    if success:
                        record_task_done("blog")
                        # 更新上次爬取日期
                        try:
                            os.makedirs(os.path.dirname(BLOG_LAST_CRAWL_FILE), exist_ok=True)
                            with open(BLOG_LAST_CRAWL_FILE, "w", encoding="utf-8") as f:
                                f.write(date.today().strftime("%Y%m%d"))
                        except OSError:
                            pass
                        # blog 成功后归档本地文件
                        archive_blog_daily_files(logger)
                else:
                    logger.warning(f"Blog脚本不存在: {blog_path}")
                time.sleep(60)

            # -- 15:00 Photos 自动同步 (每日) --
            elif current_time == "15:00" and should_run("photos_update") and is_photos_update_enabled():
                logger.info(">>> 触发 15:00 Photos 自动同步")
                run_photos_update()
                record_task_done("photos_update")
                time.sleep(60)

            # -- 12:00 Unsplash 照片管理 (v1.7, 每 3 天) --
            elif current_time == "12:00" and should_run("unsplash") and should_run_unsplash():
                logger.info(">>> 触发 12:00 Unsplash 照片管理")
                success = run_unsplash_update()
                if success:
                    record_task_done("unsplash")
                time.sleep(60)

            # 每 30 秒检查一次
            time.sleep(CHECK_INTERVAL)

        except KeyboardInterrupt:
            logger.info("用户中断 (Ctrl+C)，退出 keepitrun")
            break
        except Exception as e:
            logger.error(f"主循环异常: {e}", exc_info=True)
            time.sleep(60)


# ═══════════════════════════════════════════════════════════════
# 入口
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    logger = setup_logging()
    main_loop()
