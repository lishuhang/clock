# keepitrun - 全天候定时任务调度系统

**版本 1.4 | 2026-06-12**

keepitrun 是一个基于 Python 的 24 小时常驻定时任务调度系统，运行于 Windows 11（或跨平台）环境。它通过 `while True` 循环每 30 秒检查一次当前时间，到点自动触发对应的子脚本执行周期性任务。

## 核心功能

- RSS 订阅源抓取与关键词过滤（AI/科技领域）
- 多次抓取结果合并、去重、翻译（中英双语）
- 微信公众号 AIGC 早报自动爬取与发布
- 微信公众号长文/短篇自动爬取与发布
- GitHub Pages 照片库自动同步
- 版本感知任务完成追踪
- **[v1.4 修复]** 所有子脚本 Windows 控制台 UnicodeEncodeError

## 目录结构

```
keepitrun/
├── keepitrun.py              主调度脚本（常驻运行）
├── getrss.py                 RSS 抓取与关键词过滤
├── combine-gemini.py         RSS 合并、去重、翻译
├── convert_daily.py          微信公众号 AIGC 早报爬取
├── convert_blog.py           微信公众号长文/短篇爬取
├── model-process.py          LLM 后处理（分类/去重/过滤，可选）
├── photos_update.py          GitHub Photos 图片库自动同步
├── readme.py                 产品文档（可执行脚本）
├── readme.md                 本文档
│
├── .env                      GITHUB_TOKEN 配置
├── keywords.json             RSS 关键词配置
├── rss_feeds.json            RSS 订阅源列表
├── last_blog_crawl.txt       上次 blog 爬取日期记录
│
├── logs/                     运行日志（分级清理）
│   ├── YYYYMMDD.log          keepitrun 主日志
│   ├── getrss_*.log          RSS 抓取日志
│   ├── daily_*.log           AIGC 早报日志
│   ├── blog_*.log            微信文章日志
│   ├── task_completion.json  版本感知任务完成记录
│   └── archive/              7 天以上日志归档
│
├── tmp/                      临时文件（1 天后自动清理）
└── archived/                 已处理的 RSS 结果（30 天后清理）
```

## 每日任务计划

| 时间 | 任务 | 脚本 |
|------|------|------|
| 02:00 | RSS 抓取 (第1次) | getrss.py |
| 10:05 | 爬取最新 daily | convert_daily.py |
| 10:10 | 爬取最新 blog | convert_blog.py |
| 14:00 | RSS 抓取 (第2次) | getrss.py |
| 14:05 | 合并去重翻译 RSS 结果 | combine-gemini.py |
| 15:00 | Photos 自动同步 | photos_update.py |

**已禁用任务:** Unsplash 自动上传（外部脚本暂不可用）

## 快速开始

### 环境要求

- Python 3.9+
- pip (Python 包管理器)
- 网络连接

### 安装步骤

1. 解压 `keepitrun-v1.4.zip` 到目标位置

2. 安装 Python 依赖:
   ```bash
   pip install feedparser beautifulsoup4 google-generativeai zhipuai pypinyin requests
   ```

3. 配置 `.env` 文件:
   ```
   GITHUB_TOKEN=ghp_你的token
   ```

4. 启动主脚本:
   ```bash
   python keepitrun.py
   ```

5. (推荐) 设置为开机自启:
   - Windows: 任务计划程序 → 创建基本任务 → 触发器: 计算机启动时

## 文件清理策略

| 目录 | 保留时间 | 处理方式 |
|------|----------|----------|
| tmp/ | 1 天 | 超过 1 天 → 自动删除 |
| logs/ | 7 天 | 超过 7 天 → 移入 logs/archive/ |
| logs/archive/ | 30 天 | 超过 30 天 → 自动删除 |
| archived/ | 30 天 | 超过 30 天 → 自动删除 |

## v1.4 修复说明 — Windows 控制台 UnicodeEncodeError

### 问题

Windows 默认控制台编码为 `cp1252`（西欧 Latin-1），当 Python 脚本中使用 `print()` 输出 emoji 字符（如 📸 ⏳ 📅）或某些中文字符时，会触发:

```
UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f4f8' in position 0: character maps to <undefined>
```

### 根因

`photos_update.py` 中的 emoji 输出（📸 等）在 Windows cp1252 环境下无法编码。当 `keepitrun.py` 通过 `subprocess.run()` 调用子脚本时，子脚本自身的 stdout 编码由系统决定，即使 `subprocess.run()` 指定了 `encoding="utf-8"`，也无法阻止子脚本在写入 stdout 时就崩溃。

### 修复方案

在所有可能输出非 cp1252 字符的脚本开头，添加 UTF-8 编码重配置:

```python
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
```

### 受影响脚本

| 脚本 | 修复状态 | 问题字符 |
|------|----------|----------|
| photos_update.py | **v1.4 已修复** | 📸⏳📅🔍⚠📷✅📝🆕⬆❌🕐📁🔄✨🎯 |
| convert_blog.py | **v1.4 已修复** | 🔈(正文中), 中文日志 |
| convert_daily.py | **v1.4 已修复** | ╔═╗║╚╝ (框线), ⚠, 中文日志 |
| getrss.py | **v1.4 已修复** | 中文日志 |
| keepitrun.py | **v1.4 已修复** | 中文日志 |
| combine-gemini.py | v1.1 已有修复 | × ！ (在 cp1252 范围内) |
| model-process.py | 已有修复 | 📌🔍🗂️🗑️ (仅写入文件) |

## 版本感知任务完成追踪

当 keepitrun 版本升级后重启时，版本感知系统会自动判断哪些已完成的任务需要重做:

```python
VERSION_TASK_CHANGES = {
    "1.1": {"rss", "combine"},       # v1.1 改了日志和文件路径
    "1.2": {"blog"},                  # v1.2 重新启用blog，改用合集API
    "1.3": {"blog", "daily"},         # v1.3 重新启用daily，blog日志前缀变更
    "1.4": {"photos_update"},         # v1.4 修复所有子脚本 UTF-8 编码问题
}
```

判断逻辑:
- 任务今日未完成 → 执行
- 任务由受影响旧版本完成 → 重做
- 任务已由当前版本或未受影响版本完成 → 跳过

## Changelog

### v1.4 (2026-06-12)

**修复:**
- 所有子脚本添加 Windows 控制台 UTF-8 编码修复
  - 解决 emoji 输出导致的 `UnicodeEncodeError: 'charmap' codec can't encode character`
  - 受影响脚本: photos_update.py, convert_blog.py, convert_daily.py, getrss.py, keepitrun.py
  - 已有修复的脚本: combine-gemini.py, model-process.py (确认无问题)
- photos_update.py 纳入 keepitrun 发行包 (之前为外部脚本)

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.4": {"photos_update"}`
- 版本号升级至 1.4

### v1.3 (2026-06-11)

- 版本感知任务完成追踪系统
- convert_daily.py 重新启用

### v1.2 (2026-06-11)

- 重新启用微信公众号文章抓取
- 使用合集API替代Cookie登录

### v1.1 (2026-06-10)

- 分级文件清理策略
- 子脚本日志统一到 logs/
- 去除文件名时间戳

### v1.0 (2026-04-20)

- 初始正式版本

## Agent Debug 指南

### 日志位置

- 主日志: `logs/YYYYMMDD.log`
- RSS 抓取日志: `logs/getrss_YYYYMMDD_HHMMSS.log`
- AIGC早报日志: `logs/daily_YYYYMMDD_HHMMSS.log`
- 微信文章日志: `logs/blog_YYYYMMDD_HHMMSS.log`
- 任务完成记录: `logs/task_completion.json`

### 常见问题

**Photos 同步失败 (UnicodeEncodeError)**
- v1.4 已修复：所有子脚本已添加 UTF-8 编码重配置
- 如果仍然出现，确认运行的是 v1.4 版本的脚本

**RSS 抓取结果为空**
- 检查网络连接和 RSS 源 URL
- 确认 keywords.json 中的关键词是否过于狭窄

**合并翻译失败**
- 检查 Gemini API Key 是否有效
- 确认 tmp/ 中有 rss_*.md 文件

**版本升级后任务没有重做**
- 检查 logs/task_completion.json 中的版本记录
- 确认 VERSION_TASK_CHANGES 中是否包含对应的版本和任务

### 文件引用关系

```
keepitrun.py → getrss.py → keywords.json, rss_feeds.json
             → combine-gemini.py → tmp/rss_*.md
             → convert_daily.py → .env, 微信专辑 API
             → convert_blog.py → .env, 微信合集 API
             → photos_update.py → .env (同目录或上级)
```
