#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
maliang_register.py - 马良生图账号自动注册脚本 (v1.0)

功能：
  1. 每天定时注册 N 个马良生图（GPT-Image-2 / Grok）账号
  2. 交替访问两个 Cloudflare Worker URL，提高日注册上限：
       - https://gpt2.lishuhang.com
       - https://ai-image.lishuhang.workers.dev
  3. 链式邀请：每个新账号使用上一个账号的邀请码注册，最大化累计邀请奖励
  4. 账号信息（用户名、密码、session token、credits、注册时间、来源 URL）
     滚动累积保存到脚本同目录的 maliang_accounts.json
  5. 日期变更时，旧 JSON 被新版本替换（实际是同一文件，每日追加并整体回写）
  6. 注册成功后调用 /account/quota 刷新 credits，记录邀请人奖励到账情况
  7. 遇到 IP 限制（"已注册"）自动停止当日注册，等待次日

JSON 文件结构:
  {
    "last_updated": "2026-07-02",
    "last_updated_iso": "2026-07-02T15:30:00",
    "total_accounts": 12,
    "accounts": [
      {
        "username": "emily_chen",
        "password": "Ml@2026Proxy260702",
        "session_token": "abc123...",
        "credits": 3,
        "user_id": "...",
        "registered_at": "2026-07-02T15:30:00",
        "registered_date": "2026-07-02",
        "source_url": "https://gpt2.lishuhang.com",
        "invite_code_used": "XYZ123",
        "invited_by": "previous_username",
        "invite_reward_credits": 0,
        "status": "active"
      },
      ...
    ],
    "daily_stats": {
      "2026-07-02": {"attempted": 5, "success": 3, "failed": 2, "ip_limited": false}
    }
  }

用法:
  python maliang_register.py                  # 默认注册 5 个 (or 直到 IP 限制)
  python maliang_register.py --count 10       # 尝试注册 10 个
  python maliang_register.py --min 2 --max 10 # 至少 2 个，最多 10 个
  python maliang_register.py --dry-run        # 仅打印将要执行的操作

环境变量 (.env):
  MALIANG_DEFAULT_PASSWORD  - 默认密码前缀 (默认: Ml@2026Proxy)
  MALIANG_REGISTER_MAX      - 每次注册上限 (默认: 5)
  MALIANG_REGISTER_MIN      - 每次注册下限 (默认: 2)
  MALIANG_REQUEST_TIMEOUT   - HTTP 请求超时秒数 (默认: 30)

依赖:
  pip install requests python-dotenv
"""

import os
import sys
import json
import time
import random
import argparse
import requests
from datetime import datetime, date

# ================= Windows 编码修复 =================
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

# ================= 配置 =================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(SCRIPT_DIR, "maliang_accounts.json")

# 两个 Cloudflare Worker URL，交替使用
WORKER_URLS = [
    "https://gpt2.lishuhang.com",
    "https://ai-image.lishuhang.workers.dev",
]

# 默认配置
DEFAULT_PASSWORD_BASE = "Ml@2026Proxy"
DEFAULT_REGISTER_MAX = 5
DEFAULT_REGISTER_MIN = 2
REQUEST_TIMEOUT = 30
RETRY_DELAY_BASE = 1.5  # 重试基础延迟（秒）
RETRY_DELAY_JITTER = 1.0  # 重试随机抖动（秒）
INVITE_REWARD_WAIT = 1.2  # 等待邀请奖励到账（秒）

# 加载 .env
def load_env():
    env_path = os.path.join(SCRIPT_DIR, ".env")
    if not os.path.isfile(env_path):
        return
    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = val
    except OSError:
        pass

load_env()

# ================= 用户名生成（移植自 worker JS） =================

FIRST_NAMES = [
    'emily', 'sarah', 'michael', 'david', 'jessica', 'james', 'ashley', 'chris',
    'amanda', 'daniel', 'stephanie', 'joshua', 'nicole', 'andrew', 'samantha',
    'ryan', 'lauren', 'justin', 'rachel', 'brandon', 'megan', 'tyler',
    'katherine', 'kevin', 'elizabeth', 'brian', 'jennifer', 'jason', 'michelle',
    'patrick', 'kimberly', 'travis', 'heather', 'nathan', 'courtney', 'maria',
    'alex', 'lisa', 'robert', 'john'
]
LAST_NAMES = [
    'chen', 'wang', 'li', 'zhang', 'smith', 'johnson', 'lee', 'brown',
    'garcia', 'martinez', 'wilson', 'taylor', 'thomas', 'moore', 'jackson',
    'white', 'harris', 'clark', 'lewis', 'robinson', 'walker', 'young',
    'allen', 'king', 'wright', 'scott', 'hill', 'green', 'adams', 'baker'
]
ADJECTIVES = ['happy', 'lucky', 'cool', 'sunny', 'swift', 'calm', 'bold', 'bright',
              'dreamy', 'fresh', 'kind', 'wild', 'pure', 'warm', 'zen', 'chill',
              'neon', 'cosmic', 'pixel', 'sage']
NOUNS = ['cat', 'fox', 'moon', 'star', 'sky', 'bear', 'wolf', 'deer', 'fish', 'hawk',
         'tree', 'lake', 'rain', 'wave', 'wind', 'seed', 'leaf', 'snow', 'dawn', 'ray']


def _cap(s):
    return s[0].upper() + s[1:]


def _maybe_cap(s):
    return _cap(s) if random.random() > 0.5 else s


def generate_username():
    """生成真人风格的用户名（5 种模式随机选）"""
    fn = random.choice(FIRST_NAMES)
    ln = random.choice(LAST_NAMES)
    adj = random.choice(ADJECTIVES)
    noun = random.choice(NOUNS)
    pattern = random.randint(0, 4)
    r2 = random.randint(10, 99)
    r3 = random.randint(100, 999)
    if pattern == 0:
        return _maybe_cap(fn) + '_' + _maybe_cap(ln)
    elif pattern == 1:
        return _maybe_cap(fn) + _maybe_cap(ln) + str(r2)
    elif pattern == 2:
        return _maybe_cap(fn) + str(r3)
    elif pattern == 3:
        return adj + '_' + noun + str(r2)
    else:
        return _maybe_cap(fn) + '.' + _maybe_cap(ln) + str(r2)


def generate_password():
    """生成密码：默认前缀 + yymmdd 日期后缀"""
    base = os.environ.get("MALIANG_DEFAULT_PASSWORD", DEFAULT_PASSWORD_BASE)
    d = date.today()
    yy = str(d.year)[-2:]
    mm = f"{d.month:02d}"
    dd = f"{d.day:02d}"
    return f"{base}{yy}{mm}{dd}"


# ================= JSON 文件读写 =================

def load_accounts():
    """加载现有账号数据，返回 dict"""
    if not os.path.isfile(ACCOUNTS_FILE):
        return {
            "last_updated": "",
            "last_updated_iso": "",
            "total_accounts": 0,
            "accounts": [],
            "daily_stats": {}
        }
    try:
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # 字段完整性检查
        data.setdefault("accounts", [])
        data.setdefault("daily_stats", {})
        data.setdefault("total_accounts", len(data["accounts"]))
        return data
    except (json.JSONDecodeError, OSError) as e:
        print(f"[WARN] 读取 {ACCOUNTS_FILE} 失败: {e}，将创建新文件")
        return {
            "last_updated": "",
            "last_updated_iso": "",
            "total_accounts": 0,
            "accounts": [],
            "daily_stats": {}
        }


def save_accounts(data):
    """保存账号数据到 JSON（覆盖式回写）"""
    data["last_updated"] = date.today().strftime("%Y-%m-%d")
    data["last_updated_iso"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    data["total_accounts"] = len(data["accounts"])
    try:
        with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[OK] 已保存 {data['total_accounts']} 个账号到 {ACCOUNTS_FILE}")
    except OSError as e:
        print(f"[ERROR] 保存 {ACCOUNTS_FILE} 失败: {e}")


# ================= HTTP 请求 =================

def make_request(method, base_url, path, json_body=None, headers=None, timeout=None):
    """发送 HTTP 请求到 Worker

    返回: (response, error_message)
    """
    url = base_url.rstrip("/") + path
    h = {"Content-Type": "application/json"}
    if headers:
        h.update(headers)
    try:
        resp = requests.request(
            method, url,
            json=json_body,
            headers=h,
            timeout=timeout or REQUEST_TIMEOUT,
        )
        return resp, None
    except requests.RequestException as e:
        return None, str(e)


def register_one_account(base_url, username, password, invite_code=None):
    """在指定 Worker 上注册一个账号

    返回: (success, account_dict, error_message)
    """
    body = {"username": username, "password": password}
    if invite_code:
        body["inviteCode"] = invite_code

    resp, err = make_request("POST", base_url, "/api/auth/register", json_body=body)
    if err:
        return False, None, f"网络错误: {err}"
    if resp.status_code == 0:
        return False, None, "无响应"

    try:
        data = resp.json()
    except ValueError:
        return False, None, f"非 JSON 响应 (HTTP {resp.status_code}): {resp.text[:200]}"

    if resp.status_code != 200:
        err_msg = data.get("error") or data.get("message") or f"HTTP {resp.status_code}"
        return False, None, err_msg

    user = data.get("user", {})
    session_token = resp.headers.get("X-Session-Token", "")
    credits = user.get("imageCredits", 3)
    user_id = user.get("id", "")

    account = {
        "username": username,
        "password": password,
        "session_token": session_token,
        "credits": credits,
        "user_id": user_id,
        "registered_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "registered_date": date.today().strftime("%Y-%m-%d"),
        "source_url": base_url,
        "invite_code_used": invite_code or "",
        "invited_by": "",
        "invite_reward_credits": 0,
        "status": "active"
    }
    return True, account, ""


def refresh_quota(base_url, session_token):
    """查询账号当前额度

    返回: (credits, error_message)
    """
    resp, err = make_request(
        "GET", base_url, "/api/account/quota",
        headers={"X-Session-Token": session_token}
    )
    if err:
        return None, f"网络错误: {err}"
    try:
        data = resp.json()
        if resp.status_code != 200:
            return None, data.get("error", f"HTTP {resp.status_code}")
        user = data.get("user", {})
        return user.get("imageCredits"), ""
    except ValueError:
        return None, f"非 JSON 响应: {resp.text[:200]}"


def get_invite_code(base_url, session_token):
    """获取账号的邀请码

    返回: (invite_code, invite_link, error_message)
    """
    resp, err = make_request(
        "GET", base_url, "/api/account/invite",
        headers={"X-Session-Token": session_token}
    )
    if err:
        return None, None, f"网络错误: {err}"
    try:
        data = resp.json()
        if resp.status_code != 200:
            return None, None, data.get("error", f"HTTP {resp.status_code}")
        return data.get("inviteCode", ""), data.get("inviteLink", ""), ""
    except ValueError:
        return None, None, f"非 JSON 响应: {resp.text[:200]}"


# ================= 主流程 =================

def is_ip_limited(error_msg):
    """判断错误是否为 IP 限制"""
    if not error_msg:
        return False
    return ("已注册" in error_msg) or ("IP" in error_msg and "限制" in error_msg) or \
           ("already" in error_msg.lower() and "registered" in error_msg.lower())


def is_ip_limited_for_worker(worker_url, data):
    """检查某个 Worker URL 今日是否已被 IP 限制

    判断依据：今日该 URL 的注册尝试中最近一次连续出现 IP 限制
    """
    today = date.today().strftime("%Y-%m-%d")
    stats = data.get("daily_stats", {}).get(today, {})
    return stats.get(f"ip_limited_{worker_url}", False)


def register_accounts(target_count, dry_run=False):
    """注册多个账号

    target_count: 期望注册数量
    dry_run: 仅打印不实际执行
    """
    data = load_accounts()
    today = date.today().strftime("%Y-%m-%d")

    # 初始化今日统计
    if today not in data.get("daily_stats", {}):
        data.setdefault("daily_stats", {})[today] = {
            "attempted": 0, "success": 0, "failed": 0
        }
    today_stats = data["daily_stats"][today]

    print(f"\n{'=' * 60}")
    print(f"马良生图账号注册 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"目标: 注册 {target_count} 个账号")
    print(f"现有账号总数: {data['total_accounts']}")
    print(f"今日已尝试: {today_stats.get('attempted', 0)}, "
          f"成功: {today_stats.get('success', 0)}, 失败: {today_stats.get('failed', 0)}")
    print(f"账号文件: {ACCOUNTS_FILE}")
    print(f"{'=' * 60}\n")

    # 找最近一个有 session_token 的账号作为邀请人
    inviter = None
    for acc in reversed(data["accounts"]):
        if acc.get("session_token") and acc.get("status") == "active":
            inviter = acc
            break

    success_count = 0
    fail_count = 0
    ip_limited_count = 0

    for i in range(target_count):
        # 交替选择 Worker URL
        worker_url = WORKER_URLS[i % len(WORKER_URLS)]

        # 跳过已被 IP 限制的 Worker
        if is_ip_limited_for_worker(worker_url, data):
            print(f"[{i+1}/{target_count}] 跳过 {worker_url}（今日已 IP 限制）")
            # 检查是否所有 Worker 都被限制
            if all(is_ip_limited_for_worker(u, data) for u in WORKER_URLS):
                print("\n[STOP] 所有 Worker URL 今日均被 IP 限制，停止注册")
                break
            continue

        username = generate_username()
        password = generate_password()

        # 获取邀请码（如果有邀请人）
        invite_code = None
        invited_by = ""
        if inviter:
            invite_code, _, inv_err = get_invite_code(
                inviter["source_url"], inviter["session_token"]
            )
            if invite_code:
                invited_by = inviter["username"]
                print(f"[{i+1}/{target_count}] 链式邀请: 使用 {invited_by} 的邀请码")
            else:
                print(f"[{i+1}/{target_count}] 获取邀请码失败 ({inv_err})，继续无邀请码注册")
        else:
            print(f"[{i+1}/{target_count}] 无可用邀请人，直接注册")

        today_stats["attempted"] = today_stats.get("attempted", 0) + 1

        if dry_run:
            print(f"  [DRY-RUN] 将在 {worker_url} 注册: {username} / {password}"
                  f" (invite={invite_code or 'none'})")
            success_count += 1
            continue

        # 实际注册
        print(f"  → 注册中: {worker_url} ...")
        ok, account, err = register_one_account(
            worker_url, username, password, invite_code
        )

        if ok:
            account["invited_by"] = invited_by
            data["accounts"].append(account)
            success_count += 1
            today_stats["success"] = today_stats.get("success", 0) + 1
            print(f"  [OK] 注册成功: {username} (credits={account['credits']})")

            # 邀请奖励回收：等待后刷新邀请人额度
            if inviter and invite_code:
                print(f"  → 等待 {INVITE_REWARD_WAIT}s 后检查邀请奖励...")
                time.sleep(INVITE_REWARD_WAIT)
                old_credits = inviter.get("credits", 0)
                new_credits, q_err = refresh_quota(
                    inviter["source_url"], inviter["session_token"]
                )
                if new_credits is not None:
                    delta = new_credits - old_credits
                    if delta > 0:
                        inviter["credits"] = new_credits
                        account["invite_reward_credits"] = delta
                        print(f"  [BONUS] 邀请奖励到账: {invited_by} +{delta} credits")
                    else:
                        print(f"  [INFO] 邀请人 credits 未变化 ({old_credits}→{new_credits})")
                else:
                    print(f"  [WARN] 刷新邀请人额度失败: {q_err}")

            # 新注册的账号成为下一个邀请人
            inviter = account

            # 每次成功后立即保存（防止中途崩溃丢失数据）
            save_accounts(data)

            # 短暂延迟避免触发频率限制
            time.sleep(0.8 + random.random() * 0.4)

        else:
            fail_count += 1
            today_stats["failed"] = today_stats.get("failed", 0) + 1
            print(f"  [FAIL] 注册失败: {err}")

            if is_ip_limited(err):
                ip_limited_count += 1
                today_stats[f"ip_limited_{worker_url}"] = True
                print(f"  [STOP] {worker_url} 触发 IP 限制，标记后跳过该 URL")
                # 检查是否所有 Worker 都被限制
                if all(is_ip_limited_for_worker(u, data) for u in WORKER_URLS):
                    print("\n[STOP] 所有 Worker URL 今日均被 IP 限制，停止注册")
                    save_accounts(data)
                    break
            else:
                # 其他错误：短暂延迟后重试
                delay = RETRY_DELAY_BASE + random.random() * RETRY_DELAY_JITTER
                print(f"  等待 {delay:.1f}s 后继续...")
                time.sleep(delay)

            # 失败也保存（记录 daily_stats）
            save_accounts(data)

    # 最终保存
    save_accounts(data)

    # 汇总
    print(f"\n{'=' * 60}")
    print(f"注册完成 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"成功: {success_count} / 失败: {fail_count} / IP限制: {ip_limited_count}")
    print(f"账号总数: {data['total_accounts']}")
    print(f"{'=' * 60}\n")

    return success_count, fail_count, ip_limited_count


# ================= 入口 =================

def main():
    parser = argparse.ArgumentParser(
        description="马良生图账号自动注册脚本"
    )
    parser.add_argument(
        "--count", type=int, default=None,
        help=f"尝试注册的账号数量 (默认: {DEFAULT_REGISTER_MAX})"
    )
    parser.add_argument(
        "--min", type=int, default=None,
        help=f"最少注册数量 (默认: {DEFAULT_REGISTER_MIN})"
    )
    parser.add_argument(
        "--max", type=int, default=None,
        help=f"最多注册数量 (默认: {DEFAULT_REGISTER_MAX})"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="仅打印将要执行的操作，不实际注册"
    )
    args = parser.parse_args()

    # 优先级: --count > --max > 环境变量 > 默认值
    max_count = args.count or args.max or \
                int(os.environ.get("MALIANG_REGISTER_MAX", DEFAULT_REGISTER_MAX))
    min_count = args.min or \
                int(os.environ.get("MALIANG_REGISTER_MIN", DEFAULT_REGISTER_MIN))

    if max_count < 1:
        print(f"[ERROR] 注册数量必须 ≥ 1，当前: {max_count}")
        sys.exit(1)

    if max_count < min_count:
        print(f"[WARN] max({max_count}) < min({min_count})，调整 min = max")
        min_count = max_count

    print(f"[INFO] 本次目标: 注册 {max_count} 个账号 (最少 {min_count})")

    success, fail, ip_limited = register_accounts(max_count, dry_run=args.dry_run)

    # 如果成功数少于 min_count 且没有 IP 限制，警告
    if success < min_count and ip_limited == 0:
        print(f"\n[WARN] 成功注册 {success} 个，少于最低要求 {min_count} 个")
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
