# keepitrun — 全天候定时任务调度系统

**当前版本：1.22（2026-08-21）**

keepitrun 是一个以 Python 实现的常驻定时任务调度器。它按 **GMT+8** 执行 RSS 抓取、摘要合并翻译、微信公众号内容处理和 Photos 同步。所有用户使用、配置、排障和版本信息均以本文件为准。

> **v1.22 发布重点：** blog 图片在压缩或格式转换后，会将新的文件扩展名同时回写至正文 Markdown 与题图 front matter，保证公开图片 URL 与实际上传文件一致。该版本仅将 `blog` 标记为受影响任务，不会使 RSS、daily 或 Photos 因版本升级重跑。

## 阅读与求助

需要帮助时，请直接打开 `readme.md`。不要运行或恢复 `readme.py`；该旧文件已移除，以防可执行文档和说明文档发生分歧。

```bat
notepad readme.md
python keepitrun.py
```

## 活动任务与命名规则

活动脚本均使用 **两位顺序号、下划线、kebab-case 名称**，即 `NN_name-with-hyphens.py`。编号代表每日自动任务的逻辑顺序；同一脚本在一天内可按其调度时间多次运行。

| 编号 | 脚本 | 自动时间（GMT+8） | 作用 |
|---:|---|---|---|
| 01 | `01_getrss.py` | 02:00、14:00 | 抓取 RSS、过滤关键词、规范化文章 URL、按最终 URL 去重并保留最长描述。 |
| 02 | `02_combine-gemini.py` | 14:05 | 合并 RSS 与未取走摘要，按最终 URL 去重、翻译、分类，并留下唯一最新摘要。 |
| 03 | `03_convert-daily.py` | 10:05 | 以远程 daily 仓库日期差集抓取并发布 AIGC 早报；上传图片前读取 daily 的 `_config.yml`，自动选择图床。 |
| 04 | `04_convert-blog.py` | 10:10 | 抓取并同步微信公众号博客文章；上传图片前读取主站 `_config.yml`，自动选择图床。 |
| 05 | `05_photos-update.py` | 15:00 | 同步 Photos 图片库；每个待同步月份读取 photos 的 `_config.yml`，自动扫描对应图床并写入展示 URL。 |
| 90 | `90_cleanup-daily-from-blog.py` | 首次启动时的维护步骤 | 检查并清理历史误入主博客的 daily 内容；先预览再执行。 |
| 91 | `91_compress-images.py` | 手动 | 图片压缩维护工具。 |
| 92 | `92_model-process.py` | 手动 | 可选的模型后处理工具。 |

**Unsplash 与马良注册已从自动任务、主调度器、环境变量模板和发行包中移除。** 相关历史版本说明仅保留在下方更新日志中，不再代表可用功能。

## RSS 增量摘要规则

`01_getrss.py` 在抓取阶段会优先把聚合链接还原为文章原址：Google News 的重定向 URL 会直接解码；Techmeme 会保留 Techmeme 的标题/摘要文字，但链接替换为对应原文报道。它会去掉 URL 片段和不用于定位文章的追踪参数。

`02_combine-gemini.py` 使用与抓取阶段一致的最终 URL 规则。相同 URL 的多个条目只保留**文字说明最长**的一条；这条规则同时应用于当天两次 RSS 抓取、跨日积压摘要和人工传入的 RSS Markdown 文件。

根目录中的 `YYYYMMDD-HHMMSS.md` 是**尚未被用户取走的 RSS 摘要**。如果运行合并器时发现两个或以上此类文件，或发现历史误后缀 `YYYYMMDD-HHMMSS.py`，它会将它们与新 RSS 文件一起去重、翻译并生成一个新的 `.md`。新文件以原子方式写入成功后，旧摘要才会删除。因此，不论积压多少天，目录最终只保留一个最新摘要；其内容覆盖用户上次取走摘要后至今的全部不重复条目。

用户取走摘要后，应将根目录中的该 `YYYYMMDD-HHMMSS.md` 移出或删除。若保留，下一次合并会把它视为待领取内容而继续累计。

## 翻译与保底策略

RSS 标题按以下顺序翻译：**Gemini → GLM HTTP API → Google Free Translate**。每个可用引擎都有重试；若整个批次的所有引擎均不可用，合并器仍会保留原始标题，确保当天摘要文件生成。

GLM 对个别内容返回拒绝性文本时，合并器会识别常见拒绝提示并直接保留该条的英语原文，而不是把拒绝提示写入摘要或丢弃条目。若 GLM HTTP API 对整批请求返回“输入或生成内容可能包含不安全或敏感内容”一类安全拦截，合并器会输出明确警告、继续尝试下一引擎；若无可用引擎，仍保留该批所有英语标题与摘要。其他正常条目仍会使用其返回的中文翻译。

## 目录结构

```text
keepitrun/
├── keepitrun.py                    常驻主调度器
├── 01_getrss.py                    RSS 抓取、URL 规范化与最长说明去重
├── 02_combine-gemini.py            RSS/积压摘要合并、翻译与分类
├── 03_convert-daily.py             AIGC 早报处理
├── 04_convert-blog.py              博客文章处理
├── 05_photos-update.py             Photos 同步
├── image_routing.py                 image_prefixes 配置解析与上传路由
├── 90_cleanup-daily-from-blog.py   手动维护清理工具
├── 91_compress-images.py           图片压缩工具
├── 92_model-process.py             可选模型后处理工具
├── readme.md                       唯一用户说明与更新日志
├── .env.example                    环境变量模板；不含实际凭据
├── keywords.json                   RSS 关键词配置
├── rss_feeds.json                  RSS 订阅源配置
├── tmp/                            RSS 中间文件
├── logs/                           日志与任务完成记录
└── archived/                       已处理内容归档
```

发行包和 GitHub 提交中不得包含 `.env`、账号记录、日志、临时文件、用户文章、图片、令牌、Cookie 或其他凭据。只可包含 `.env.example`。

## 安装、配置与启动

需要 Python 3.9+、pip 和网络连接。使用 `.env.example` 创建本地 `.env`，并自行填入必要的值；不得将 `.env` 上传到 GitHub、聊天记录或交接文档。

```bat
pip install feedparser beautifulsoup4 google-generativeai pypinyin requests python-dotenv Pillow
python keepitrun.py
```

典型配置仅包括内容同步与 RSS 翻译所需的值。GLM 回退使用标准 HTTP API，不依赖 `zhipuai` Python 包。若需要凭据，请向配置所有者索取；不要把实际值写入代码、说明或 `todo-*.md`。

## 图床路由配置

`03_convert-daily.py`、`04_convert-blog.py` 和 `05_photos-update.py` 不再将图片仓库硬编码为唯一目标。每次需要传图或扫描图片时，它们都会使用 GitHub Contents API 读取**目标站点** `_config.yml` 的 `image_prefixes`，并按图片所属月份选择唯一规则。配置使用半开区间 `[起始月份, 截止月份)`；例如截止值 `"2026-08"` 表示该规则覆盖至 **2026-07-31**。

```yaml
image_prefixes:
  - range: [null, "2026-08"]
    prefix: "https://raw.githubusercontent.com/owner/img/main/"
    upload:
      repository: "owner/img"
      branch: "main"
      path_prefix: ""
  - range: ["2026-08", null]
    prefix: "https://raw.githubusercontent.com/owner/img2/main/"
    upload:
      repository: "owner/img2"
      branch: "main"
      path_prefix: ""
```

`prefix` 是站点引用的公开 URL 前缀；`upload.repository`、`upload.branch` 和可选的 `upload.path_prefix` 是写入/扫描目标。范围不得重叠或留空档；无法匹配、配置缺失或目标仓库信息不完整时，脚本会**停止该次带图发布**，而不会静默写入旧仓库。图片相对路径保持既有命名规则：blog 为 `YYYY/MM/DD/slug/NN.ext`，daily 为 `YYYY/MM/MMDD-d.ext`，Photos 为 `YYYY/MM/DD/文件名`。

Photos 当前配置为：2026-07-31 及此前读取 `modem-56k/img@main`，2026-08-01 起读取 `modem-56k/img2@main`。`05_photos-update.py` 生成的 `data/YYYYMM.json` 会记录相应月份的公开 raw URL，因此 `index.html` 无需包含凭据也能正确展示图片。变更图床前，应先发布目标站点的 `_config.yml`，再运行 keepitrun。

## 常用手动命令

| 目的 | 命令 |
|---|---|
| 启动调度器 | `python keepitrun.py` |
| 预览 daily 清理 | `python 90_cleanup-daily-from-blog.py --dry-run` |
| 执行 daily 清理 | `python 90_cleanup-daily-from-blog.py` |
| 全量比对博客文章 | `python 04_convert-blog.py album:diff` |
| 合并一个 RSS 文件并强制免费翻译 | `python 02_combine-gemini.py tmp/rss_YYYY-MM-DD_HH-MM-SS.md -engine google_free` |
| 合并一个或多个 RSS 文件并自动回退 | `python 02_combine-gemini.py tmp/rss_YYYY-MM-DD_HH-MM-SS.md -engine auto` |
| 仅收敛根目录积压摘要 | `python 02_combine-gemini.py -engine auto` |

`90_cleanup-daily-from-blog.py` 可能删除远程仓库中的匹配文章。实际执行前必须先使用 `--dry-run` 确认结果。

## 文件清理策略

| 目录或文件 | 策略 | 注意事项 |
|---|---|---|
| `tmp/` | 超过 1 天自动删除 | RSS 中间文件。 |
| `logs/` | 超过 7 天移入 `logs/archive/` | 运行日志。 |
| `logs/archive/` | 超过 30 天自动删除 | 历史日志。 |
| `archived/` | 超过 30 天自动删除 | 已处理的本地副本。 |
| 根目录 `YYYYMMDD-HHMMSS.md` | 不自动删除 | 用户未取走的 RSS 摘要；会在下一次合并时继续累计。 |
| `last_blog_crawl.txt` | 不应手动删除 | 删除会扩大下一次博客抓取范围。 |
| `logs/task_completion.json` | 不应手动删除 | 保存版本感知任务状态。 |

## 故障排查

### RSS 摘要没有生成或积压未消失

检查 `tmp/` 中是否有 `rss_*.md`，以及根目录是否有 `YYYYMMDD-HHMMSS.md` 或历史 `.py` 后缀摘要。合并器会先读取所有积压摘要，再读取传入的 RSS 文件。若合并失败，旧摘要不会删除；可查看 `logs/` 后重试。

### GLM 返回拒绝提示或翻译失败

拒绝性返回与 GLM HTTP 安全拦截都会保留英语原文，不会丢失条目。网络、限流或结构化输出失败时，脚本会继续尝试下一翻译引擎；全部失败时仍以原始标题及摘要输出摘要。

### daily 或 blog 似乎反复运行

先查看 `logs/daily_*.log`、`logs/blog_*.log` 和主日志。v1.20 的自动任务使用 `--non-interactive`：远程文件已存在时会跳过，不会显示覆盖提示或等待输入。daily 自动模式还会将专辑候选日期与远程 daily 仓库的完整发布日期集合取差集；同日已发布内容不会再抓取或提交。手动运行时不带 `--non-interactive`，仍可保留覆盖确认行为。

### 图片没有上传到预期仓库或 Photos 未显示新图

先检查对应站点的 `_config.yml`：每个 `image_prefixes` 范围必须连续且无重叠，且每条规则都应有 `prefix` 与完整的 `upload.repository`、`upload.branch`。再查看子脚本日志中的“图床路由”或“扫描 owner/repo@branch”行。Photos 的图片仓库必须允许匿名读取其 `prefix` 指向的 URL；私有仓库的 raw URL 无法直接被公开网页或缩略图服务读取。

### GitHub 认证失败

确认本地 `.env` 中的同步凭据有效且拥有目标仓库所需权限。不要把凭据打印到日志、聊天、README 或交接文件。

### 用户需要帮助

直接打开 `readme.md`。不要恢复或运行 `readme.py`。

## 版本感知任务完成追踪

主程序将任务名、日期和完成版本保存到 `logs/task_completion.json`。同日升级后，只有被 `VERSION_TASK_CHANGES` 标记为受影响的任务会重新运行。v1.22 的图片 URL 回写修复仅影响 `blog`；自动模式仍会在远程文章已存在时安全跳过，避免重复覆盖或提交。

## 更新日志

### v1.22（2026-08-21）— 博客图片扩展名一致性修复

- 修复 `04_convert-blog.py` 在不透明 PNG、WebP/AVIF 或静态 GIF 转换为 JPG/PNG 后，只上传新扩展名文件、却未更新已生成文章 Markdown 的缺陷。
- 转换后的公开 URL 现会同步回写正文全部图片引用和 front matter `image` 题图字段；透明 PNG 与未转换图片保持原 URL。
- 版本感知任务映射仅标记 `blog`，避免升级时重跑不受影响的 RSS、daily 或 Photos 任务。

### v1.21（2026-08-19）— 目标站配置驱动的图床路由

- 新增 `image_routing.py`：以无额外依赖的受限 YAML 解析器读取 `image_prefixes`，校验范围、仓库、分支与路径前缀，并拒绝重叠、空档或不完整的上传规则。
- `03_convert-daily.py` 与 `04_convert-blog.py` 会在图片上传前读取各自目标博客的 `_config.yml`；图片写入由匹配月份的 `upload.repository`、`upload.branch`、`upload.path_prefix` 决定，文章仍写入原博客仓库。
- `05_photos-update.py` 会对每个月读取 photos 的 `_config.yml`，按路由扫描图片仓库，并在 `data/YYYYMM.json` 写入对应公开 `base_url`；已有 JSON 内容一致时不产生提交。
- daily 的既有展示前缀保持不变，并补充显式上传目标；其 2026-07 的原有范围空档已修正为截止 `2026-08`，不改变任何月份的展示前缀。
- Photos 配置为 2026-07-31 及以前走 `modem-56k/img@main`，2026-08-01 及以后走 `modem-56k/img2@main`。图床路径命名规则保持不变。
- `02_combine-gemini.py` 现可识别 GLM HTTP API 的内容安全拦截响应；整批拒答时记录明确警告并继续回退，所有引擎不可用时仍保留英语标题与摘要，不写入拒答文本。
- 任务映射：`daily`、`blog`、`photos_update`。

### v1.20（2026-08-18）— 后台无交互与重复发布防护

- 主调度器以关闭的空标准输入运行未显式传入输入的子脚本，避免后台任务停在人工确认提示而被误判为超时并重试。
- 自动 daily 任务传入 `--non-interactive`，以远程 daily 仓库的完整发布日期集合做差集；同日内容已发布时直接完成，不再重复抓取、备份、覆盖或提交。
- 自动 blog 任务也传入 `--non-interactive`；遇到远程已存在文章时安全跳过，不等待覆盖提示。手动命令保留原有交互覆盖行为。
- 任务映射：`daily`、`blog`。

### v1.19（2026-08-18）— 任务链整理与累计 RSS 摘要

- 移除 Unsplash 与马良注册的自动任务、脚本文件和环境变量模板内容。
- 将保留的每日任务依执行顺序重命名为 `01_getrss.py` 至 `05_photos-update.py`；维护工具使用 `90+` 编号。
- `02_combine-gemini.py` 现在会合并根目录中所有尚未取走的 `YYYYMMDD-HHMMSS.md`，并兼容历史 `.py` 后缀摘要；输出成功后删除被新摘要取代的旧文件。
- URL 去重与“相同 URL 保留最长描述”规则与 `01_getrss.py` 对齐，并覆盖积压摘要与新 RSS 输入。
- GLM 的单条拒绝性翻译结果会回显英语原文，避免遗漏或写入拒绝提示。
- 任务映射：`rss`、`combine`、`daily`、`blog`、`photos_update`。

### v1.18（2026-08-18）— RSS 恢复、可靠性与链接规范化

- 主调度器固定按 GMT+8 判断日期和任务时间；子脚本设置统一时限并重试。
- `combine-gemini.py` 支持一个或多个 RSS 中间文件，并按 Gemini、GLM HTTP API、Google Free Translate 降级。
- `getrss.py` 解码 Google 重定向、解析 Techmeme 原文链接、去除追踪参数，并按 URL 去重。

### v1.17（2026-08-18）— 版本与文档校正

- 以正式 v1.16 归档为基线校正版本元数据，删除 `readme.py`，并将说明统一至本文件。
- 历史“2.0”标识被确认为非正式版本，不构成后续程序发布。

### v1.16 及更早版本

完整历史版本信息以归档 ZIP 和 GitHub 提交记录为准。维护时应以当前 `VERSION`、`VERSION_DATE`、`VERSION_TASK_CHANGES` 和本更新日志为一致性基线。

## 维护注意事项

- 修改代码前先核对版本变量、任务映射、README 和发行包命名是否一致。
- 每次完成一轮工作，在提交前新建一个仅包含本轮增量的 `todo-MMDD-HHMM.md` 交接记录。
- 交接记录必须完整保留对应用户需求，并说明目的、偏好、完成项、偏差、未完成项、返工与踩坑；不得包含令牌、API Key、密码、Cookie、个人信息或任何明文凭据。如需要凭据，必须向配置所有者索取。
- 发布前确认包内不含 `.env`、日志、临时文件、账号记录、凭据或用户生成内容。

---

文档版本：**1.22**。本文是 keepitrun 的唯一用户说明与更新日志。
