# keepitrun - 全天候定时任务调度系统

**版本 1.13 | 2026-07-05**

keepitrun 是一个基于 Python 的 24 小时常驻定时任务调度系统，运行于 Windows 11（或跨平台）环境。它通过 `while True` 循环每 30 秒检查一次当前时间，到点自动触发对应的子脚本执行周期性任务。

## 核心功能

- RSS 订阅源抓取与关键词过滤（AI/科技领域）
- 多次抓取结果合并、去重、翻译（中英双语）
- 微信公众号 AIGC 早报自动爬取与发布（仅 lishuhang.me/daily/）
- 微信公众号长文/短篇自动爬取与发布
- GitHub Pages 照片库自动同步
- 版本感知任务完成追踪
- **[v1.4 修复]** 所有子脚本 Windows 控制台 UnicodeEncodeError
- **[v1.5 修复]** blog 首次启动超时 + photos_update 401 友好处理
- **[v1.7 新增]** Unsplash 照片管理 (API 认证，无需 Cookie)
- **[v1.8 新增]** 马良生图账号自动注册（每日定时，链式邀请+滚动 JSON）
- **[v1.8 修复]** convert_blog.py 误纳 AIGC 早报合集，导致早报被同步到主博客
- **[v1.9 修复]** convert_blog.py section 标签内容提取（文章正文缺失 bug）
- **[v1.9 修复]** cleanup_daily_from_blog.py 分支探测（master→自动探测 main/master）
- **[v1.11 重构]** 图片存储架构：相对路径 + 日期范围前缀 + 无损压缩
- **[v1.12 重构]** 图片格式严格限制为 jpg/png/gif（IE6 兼容）+ 格式转换 + 本地文件清理

## v1.12 关键变更

### 1. 图片格式严格限制（IE6 兼容）+ 内置压缩工具

blog 和 daily 抓取的图片现在严格只允许以下格式：
- **JPG** — 不透明图片的首选格式（体积最小）
- **PNG** — 仅限透明图片（oxipng 无损压缩）
- **GIF** — 仅限动图（Pillow 压缩）

**v1.13 内置压缩工具**（无需安装系统级工具）：
- `piczip/oxipng.exe` — PNG 无损压缩（开源，Rust 编写，最佳压缩比）
- JPEG/GIF 压缩使用 Pillow（Python 库，随 pip 安装）

**格式转换规则**（`compress_and_convert_image` / `compress_image_file`）：
| 原始格式 | 透明? | 动图? | 转换为 | 压缩工具 |
|---------|-------|-------|--------|---------|
| PNG | 是 | — | 保留 PNG | oxipng -o 4 |
| PNG | 否 | — | **JPG** | Pillow (q=88) |
| GIF | — | 是 | 保留 GIF | Pillow optimize |
| GIF | — | 否 | **PNG→JPG** | — |
| JPEG | — | — | 保留 JPG | Pillow (q=88) |
| WebP | 是 | — | **PNG** | oxipng |
| WebP | 否 | — | **JPG** | Pillow |
| AVIF | 是 | — | **PNG** | oxipng |
| AVIF | 否 | — | **JPG** | Pillow |

格式转换后，markdown 内的图片引用路径会自动更新为新扩展名。

依赖：`Pillow`（`pip install Pillow`），oxipng 已内置在 `piczip/` 目录。

### 2. 本地文件清理

blog/daily 抓取后生成的本地文件（.md、images/）在上传 GitHub 后会自动移到 `archived/` 目录（保留 30 天后自动删除）。

**可手动清除的临时文件/目录**（不影响运行）：
- `archived/` — 已处理的 RSS 结果、blog/daily 文章本地副本、图片（30 天后自动删除）
- `logs/` — 运行日志（7 天后移入 `logs/archive/`，30 天后删除）
- `logs/archive/` — 归档日志
- `tmp/` — RSS 抓取中间结果（1 天后自动删除）
- `last_blog_crawl.txt` — 上次 blog 爬取日期记录（**勿删**，删除会导致重新全量爬取）
- `last_unsplash_run.txt` — Unsplash 上次运行日期（**勿删**）
- `maliang_accounts.json` — 马良生图账号累积记录（**勿删**）
- `logs/task_completion.json` — 版本感知任务完成记录（**勿删**）
- `logs/.boot_flag` — 每日首次启动标记（自动管理）

**根目录散落的 .md 文件**：如果根目录出现 `YYYY-MM-DD-*.md` 文件，说明是 blog 抓取后未及时归档。可以手动删除或移到 `archived/`。

### 3. 移除的文件（v1.12 清理）

以下文件已从 v1.12 中移除（已部署到对应仓库，无需在 keepitrun 中保留）：
- `disabled/convert_daily.py` — 旧版 daily 脚本，已被主目录 `convert_daily.py` 取代
- `img_repo_workflow_aggressive_compress.yml` — 一次性压缩 workflow，已部署到 `lishuhang/img`
- `img_repo_workflow_compress_images.yml` — 常规压缩 workflow，已部署到 `lishuhang/img`

## 目录结构

```
keepitrun/
├── keepitrun.py              主调度脚本（常驻运行）
├── getrss.py                 RSS 抓取与关键词过滤
├── combine-gemini.py         RSS 合并、去重、翻译
├── convert_daily.py          微信公众号 AIGC 早报爬取（→ lishuhang/daily）
├── convert_blog.py           微信公众号长文/短篇爬取（→ lishuhang.github.io）
├── model-process.py          LLM 后处理（分类/去重/过滤，可选）
├── photos_update.py          GitHub Photos 图片库自动同步
├── unsplash_update.py        Unsplash 照片管理 (v1.7)
├── maliang_register.py       马良生图账号自动注册 (v1.8)
├── compress_images.py        图片压缩 CLI（用于 img 仓库手动压缩）
├── cleanup_daily_from_blog.py 一次性清理脚本（v1.8，已完成使命，保留备查）
├── readme.py                 产品文档（可执行脚本）
├── readme.md                 本文档
│
├── .env.example              环境变量模板（GitHub Token + Unsplash 凭证）
├── keywords.json             RSS 关键词配置
├── rss_feeds.json            RSS 订阅源列表
├── last_blog_crawl.txt       上次 blog 爬取日期记录（自动管理）
├── maliang_accounts.json     马良生图账号累积记录（运行时自动创建）
│
├── logs/                     运行日志（分级清理）
│   ├── YYYYMMDD.log          keepitrun 主日志
│   ├── getrss_*.log          RSS 抓取日志
│   ├── daily_*.log           AIGC 早报日志
│   ├── blog_*.log            微信文章日志
│   ├── task_completion.json  版本感知任务完成记录
│   └── archive/              7 天以上日志归档
│
├── tmp/                      临时文件（1 天后自动清理）
└── archived/                 已处理的 RSS 结果、blog/daily 文章（30 天后清理）
```

## 每日任务计划

| 时间 | 任务 | 脚本 |
|------|------|------|
| 02:00 | RSS 抓取 (第1次) | getrss.py |
| 03:00 | 马良生图账号注册 (v1.8 新增) | maliang_register.py |
| 10:05 | 爬取最新 daily | convert_daily.py |
| 10:10 | 爬取最新 blog | convert_blog.py |
| 14:00 | RSS 抓取 (第2次) | getrss.py |
| 14:05 | 合并去重翻译 RSS 结果 | combine-gemini.py |
| 15:00 | Photos 自动同步 | photos_update.py |
| 12:00 | Unsplash 照片管理 (每3天) | unsplash_update.py |

**Unsplash 需配置:** 在 `.env` 中设置 `UNSPLASH_ACCESS_KEY`，首次使用需获取 Bearer Token:
```bash
python unsplash_update.py auth <授权码>
```

**马良生图注册可调:** 在 `.env` 中设置 `MALIANG_REGISTER_MIN` / `MALIANG_REGISTER_MAX`（默认 2 / 5）。

## 快速开始

### 环境要求

- Python 3.9+
- pip (Python 包管理器)
- 网络连接

### 安装步骤

1. 解压 `keepitrun-v1.13.zip` 到目标位置

2. 安装 Python 依赖:
   ```bash
   pip install feedparser beautifulsoup4 google-generativeai zhipuai pypinyin requests python-dotenv Pillow
   ```

3. 配置 `.env` 文件 (复制 `.env.example` 并填入实际值):
   ```
   GITHUB_TOKEN=ghp_你的token
   UNSPLASH_ACCESS_KEY=你的access_key
   UNSPLASH_SECRET_KEY=你的secret_key
   UNSPLASH_BEARER_TOKEN=你的bearer_token   # 首次使用需通过 auth 命令获取
   UNSPLASH_REDIRECT_URI=urn:ietf:wg:oauth:2.0:oob
   
   # 马良生图注册 (v1.8 新增，可选)
   MALIANG_DEFAULT_PASSWORD=Ml@2026Proxy
   MALIANG_REGISTER_MIN=2
   MALIANG_REGISTER_MAX=5
   ```

4. 启动主脚本:
   ```bash
   python keepitrun.py
   ```
   
   v1.9 首次启动时会自动执行 AIGC 早报清理（如主博客有误同步的早报内容）。

5. (推荐) 设置为开机自启:
   - Windows: 任务计划程序 → 创建基本任务 → 触发器: 计算机启动时

6. (可选) 手动运行清理脚本:
   ```bash
   python cleanup_daily_from_blog.py --dry-run    # 先预览
   python cleanup_daily_from_blog.py              # 实际删除
   ```

## 文件清理策略

| 目录 | 保留时间 | 处理方式 |
|------|----------|----------|
| tmp/ | 1 天 | 超过 1 天 → 自动删除 |
| logs/ | 7 天 | 超过 7 天 → 移入 logs/archive/ |
| logs/archive/ | 30 天 | 超过 30 天 → 自动删除 |
| archived/ | 30 天 | 超过 30 天 → 自动删除 |

## v1.8 新增 — 马良生图账号自动注册 + AIGC 早报合集修复

### 1. 新增 `maliang_register.py` — 每日定时注册马良生图账号

每天 03:00 自动注册若干个马良生生图（GPT-Image-2 / Grok）账号，账号信息滚动累积保存到脚本同目录的 `maliang_accounts.json`。

**功能特点：**
- 交替访问两个 Cloudflare Worker URL（`gpt2.lishuhang.com` 和 `ai-image.lishuhang.workers.dev`），提高日注册上限
- 链式邀请：每个新账号使用上一个账号的邀请码注册，最大化累计邀请奖励
- 邀请奖励自动回收：注册成功后等待 1.2 秒，刷新邀请人额度，捕获异步到账的 credits
- 每次成功立即保存 JSON，防止中途崩溃丢失数据
- 遇到 IP 限制（"已注册"）自动停止当日注册，标记该 Worker URL，等待次日
- 同一日内同一 Worker URL 不会重复尝试（避免无谓请求）

**JSON 文件结构（`maliang_accounts.json`）：**
```json
{
  "last_updated": "2026-07-02",
  "last_updated_iso": "2026-07-02T03:00:15",
  "total_accounts": 12,
  "accounts": [
    {
      "username": "emily_chen",
      "password": "Ml@2026Proxy260702",
      "session_token": "abc123...",
      "credits": 3,
      "user_id": "...",
      "registered_at": "2026-07-02T03:00:15",
      "registered_date": "2026-07-02",
      "source_url": "https://gpt2.lishuhang.com",
      "invite_code_used": "XYZ123",
      "invited_by": "previous_username",
      "invite_reward_credits": 0,
      "status": "active"
    }
  ],
  "daily_stats": {
    "2026-07-02": {
      "attempted": 5, "success": 3, "failed": 2,
      "ip_limited_https://gpt2.lishuhang.com": false,
      "ip_limited_https://ai-image.lishuhang.workers.dev": true
    }
  }
}
```

**配置（在 `.env` 中）：**
```
MALIANG_DEFAULT_PASSWORD=Ml@2026Proxy   # 密码前缀（自动追加 yymmdd 后缀）
MALIANG_REGISTER_MIN=2                   # 每日最少注册数量
MALIANG_REGISTER_MAX=5                   # 每日最多注册数量
```

**手动运行：**
```bash
python maliang_register.py                  # 默认 5 个
python maliang_register.py --count 10       # 尝试 10 个
python maliang_register.py --dry-run        # 仅打印不实际注册
```

### 2. 修复 convert_blog.py 误纳 AIGC 早报合集的 bug

**问题表现：** AIGC 早报（应仅在 lishuhang.me/daily/ 显示）被同步发布到主博客 lishuhang.me。

**根因：** `convert_blog.py` 的 `ALBUMS` 列表中 `album_id=3793362825901522949` 的条目（原标 "贴图"）实际是 AIGC 早报专辑 —— 该 album_id 与 `convert_daily.py` 的 `DEFAULT_ALBUM_ID` 完全相同。导致 `convert_blog.py` 把 AIGC 早报也当作普通文章抓取并发布到主博客。

**修复：**
- 从 `convert_blog.py` 的 `ALBUMS` 列表移除该条目（现支持 7 个合集，原 8 个）
- 更新文件头部 docstring 和合集说明
- 升级 `convert_blog.py` 版本至 v3.1

**注意：** 如果用户有真实的"贴图"合集（与 AIGC 早报不同），需要找到正确的 album_id 后重新添加到 `ALBUMS` 列表。

### 3. 新增 `cleanup_daily_from_blog.py` — 一次性清理脚本

用于清理之前因上述 bug 误同步到 `lishuhang/lishuhang.github.io` 仓库 `_posts/` 目录的 AIGC 早报内容。

**工作流程：**
1. 通过 GitHub API 列出 `_posts/` 下所有 .md 文件
2. 逐个读取文件内容，检查 front matter：
   - categories 包含 "AIGC日报" / "AIGC早报"
   - 或 tags 包含 "AIGC"
   - 或文件名包含 "aigc" / "早报"
   - 或标题包含 "AIGC早报" / "每日AIGC"
3. 匹配的文件通过 GitHub API 删除（commit message 标注清理原因）

**使用方法：**
```bash
python cleanup_daily_from_blog.py --dry-run      # 先预览待删除文件
python cleanup_daily_from_blog.py                # 实际删除
python cleanup_daily_from_blog.py --verbose      # 详细日志
```

**注意：** 此脚本为一次性工具，运行完成后即可删除。删除操作不可恢复，务必先 `--dry-run` 确认。

## v1.7 新增 — Unsplash 照片管理

**重新启用 Unsplash 任务**，使用官方 API 认证（无需 Cookie）:

- 新增 `unsplash_update.py` 脚本
- 支持 `Client-ID` (Access Key) 公开读取 + `Bearer Token` 用户操作
- 内置 Demo 等级速率限制 (50 请求/小时，脚本预留 40 次/小时)
- 每 3 天自动运行 (12:00)
- 支持命令: `auth` (获取Token), `status`, `list`, `collections`, `upload`

**注意:** Unsplash 官方 API 未公开上传端点，如果 `POST /photos` 不被支持，需通过网页手动上传。

首次使用需获取 Bearer Token:
```bash
# 1. 在浏览器中访问授权 URL (见 .env.example 中的说明)
# 2. 获取授权码后运行:
python unsplash_update.py auth <授权码>
```

## v1.6 变更 — 归档 + .env 修复

- 新增 blog/daily 文章归档机制（GitHub 同步后移入 archived/）
- 修复打包含 .env 导致 Token 被覆盖（改用 .env.example）

## v1.5 修复说明

### 问题 1: blog 首次启动超时

**现象:** `convert_blog.py album:diff` 在首次启动时执行超过 600 秒被强制终止。

**根因:** 当 `last_blog_crawl.txt` 不存在或为空时，keepitrun 默认传递 `album:diff` 参数。此模式需要遍历全部 8 个微信合集的所有页面（每个合集数百篇文章），加上 GitHub API 查询，总计耗时远超 10 分钟。

**修复:** 无爬取记录时，默认使用 `album:YYYYMMDD`（最近 30 天），而非 `album:diff`。`album:diff` 仍可通过手动命令使用，不再作为自动调度默认值。

### 问题 2: photos_update.py 401 认证崩溃

**现象:** `photos_update.py` 在 GitHub Token 无效时，输出原始 Python traceback 后崩溃：
```
requests.exceptions.HTTPError: 401 Client Error: Unauthorized for url: ...
```

**根因:** `api_get()` 函数只处理了 403（速率限制），未处理 401（认证失败），直接调用 `resp.raise_for_status()` 导致异常。

**修复:** 在 `api_get()` 中增加 401 检测，遇到认证失败时输出友好提示信息（Token 检查步骤、.env 配置确认等），然后优雅退出。

## v1.4 修复说明 — Windows 控制台 UnicodeEncodeError

### 问题

Windows 默认控制台编码为 `cp1252`（西欧 Latin-1），当 Python 脚本中使用 `print()` 输出 emoji 字符（如 📸 ⏳ 📅）或某些中文字符时，会触发:

```
UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f4f8' in position 0: character maps to <undefined>
```

### 根因

`photos_update.py` 中的 emoji 输出（📸 等）在 Windows cp1252 环境下无法编码。当 `keepitrun.py` 通过 `subprocess.run()` 调用子脚本时，子脚本自身的 stdout 编码由系统决定，即使 `subprocess.run()` 指定了 `encoding="utf-8"`，也无法阻止子脚本在写入 stdout 时就崩溃。

### 修复方案

在所有可能输出非 cp1252 字符的脚本开头，添加 UTF-8 编码重配置:

```python
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
```

### 受影响脚本

| 脚本 | 修复状态 | 问题字符 |
|------|----------|----------|
| photos_update.py | **v1.4 已修复** | 📸⏳📅🔍⚠📷✅📝🆕⬆❌🕐📁🔄✨🎯 |
| convert_blog.py | **v1.4 已修复** | 🔈(正文中), 中文日志 |
| convert_daily.py | **v1.4 已修复** | ╔═╗║╚╝ (框线), ⚠, 中文日志 |
| getrss.py | **v1.4 已修复** | 中文日志 |
| keepitrun.py | **v1.4 已修复** | 中文日志 |
| combine-gemini.py | v1.1 已有修复 | × ！ (在 cp1252 范围内) |
| model-process.py | 已有修复 | 📌🔍🗂️🗑️ (仅写入文件) |

## 版本感知任务完成追踪

当 keepitrun 版本升级后重启时，版本感知系统会自动判断哪些已完成的任务需要重做:

```python
VERSION_TASK_CHANGES = {
    "1.1": {"rss", "combine"},       # v1.1 改了日志和文件路径
    "1.2": {"blog"},                  # v1.2 重新启用blog，改用合集API
    "1.3": {"blog", "daily"},         # v1.3 重新启用daily，blog日志前缀变更
    "1.4": {"photos_update"},         # v1.4 修复所有子脚本 UTF-8 编码问题
    "1.5": {"blog", "photos_update"}, # v1.5 修复 blog 超时 + photos_update 401 处理
    "1.6": {"daily", "blog"},         # v1.6 新增 blog/daily 文章归档机制
    "1.7": {"unsplash"},              # v1.7 重新启用 Unsplash (改用 API 认证)
    "1.8": {"maliang_register", "blog"},  # v1.8 新增马良生图注册 + 修复 blog 误纳 AIGC 早报
    "1.9": {"blog"},                  # v1.9 修复 blog section 标签内容提取 + cleanup 分支探测
    "2.0": {"blog", "daily"},          # v1.11 图片路径改为相对 + 压缩图片 + _config 日期范围前缀
}
```

判断逻辑:
- 任务今日未完成 → 执行
- 任务由受影响旧版本完成 → 重做
- 任务已由当前版本或未受影响版本完成 → 跳过

## Changelog

### v1.13 (2026-07-05) — 内置压缩工具 + Pillow JPEG/GIF 压缩

**变更:**
- 内置 `piczip/oxipng.exe`（v9.1.5，Windows x86_64，开源 Rust）
  - PNG 无损压缩，无需安装系统级工具
  - 脚本自动从 `piczip/` 目录查找，也兼容系统 PATH
- JPEG/GIF 压缩改用 Pillow（纯 Python，无需外部工具）
  - `_compress_jpeg_with_pillow()`: quality=88, optimize, progressive
  - `_compress_gif_with_pillow()`: optimize=True, 保留动画
- 不再依赖 jpegoptim 和 gifsicle（Windows 上难以安装）

**移除:**
- 对 jpegoptim 的依赖（改用 Pillow）
- 对 gifsicle 的依赖（改用 Pillow）

### v1.12 (2026-07-05) — 图片格式严格限制 + 清理

**重构:**
- 图片格式严格限制为 jpg/png/gif（IE6 兼容）
  - 不透明 PNG → 转为 JPG（体积更小）
  - 透明 PNG → 保留 PNG，oxipng 压缩
  - 动图 GIF → 保留 GIF，gifsicle 压缩
  - 静态 GIF → 转为 PNG（再按 PNG 规则处理）
  - WebP/AVIF → 按透明度转为 JPG 或 PNG
  - 格式转换后 markdown 引用路径自动更新

**新增:**
- `compress_and_convert_image()` (convert_blog.py): 统一的格式转换+压缩函数
- `compress_image_file()` (convert_daily.py): 同上，返回 (new_path, saved)
- 透明度检测 (`_detect_transparency`): 使用 Pillow 检测 alpha 通道
- 动图检测 (`_is_animated_gif`): 使用 Pillow 检测 n_frames

**移除:**
- `disabled/convert_daily.py` — 旧版脚本
- `img_repo_workflow_aggressive_compress.yml` — 已部署到 img 仓库
- `img_repo_workflow_compress_images.yml` — 已部署到 img 仓库

**依赖新增:**
- `Pillow` — 用于透明度检测和格式转换（`pip install Pillow`）

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.12": {"blog", "daily"}`
- 版本号升级至 1.12

### v1.11 (2026-07-05) — 图片存储架构重构

**重构:**
- 图片 URL 从绝对路径改为相对路径
  - 921 篇现有 `_posts/*.md` 中的 3427 处 `https://lishuhang.me/img/` 替换为 `/img/`
  - 其他 URL（微信、外部图床）保持不变
- `convert_blog.py` / `convert_daily.py` 输出相对路径 `/img/...`
  - `GITHUB_IMAGE_BASE` 从 `https://lishuhang.me/img` 改为 `/img`
  - `GITHUB_IMAGE_BASE_URL` 从 raw.githubusercontent URL 改为 `/img`

**新增:**
- `lishuhang.github.io/_plugins/image_prefix.rb` (Jekyll Generator)
  - 构建时根据 `post.date` 和 `_config.yml` 的 `image_prefixes` 配置
    将 `/img/...` 重写为完整 URL
  - 支持按日期范围使用不同存储前缀（A/B/C 三段）
  - 当前所有前缀指向 `https://lishuhang.me`（无变化，可日后迁移）
- `_config.yml` 新增 `image_prefixes` 配置：
  ```yaml
  image_prefixes:
    - range: [null, "2024-01"]        # before 2024-01 → prefix A
      prefix: "https://lishuhang.me"
    - range: ["2024-01", "2026-07"]   # 2024-01 to 2026-07 → prefix B
      prefix: "https://lishuhang.me"
    - range: ["2026-07", null]        # 2026-07 onwards → prefix C
      prefix: "https://lishuhang.me"
  ```
- `compress_images.py` CLI 脚本：无损图片压缩
  - PNG: `oxipng -o 4`（无损）
  - JPEG: `jpegoptim --max=90`（近无损）
  - GIF: `gifsicle -O3`（无损）
  - 支持 `--dry-run`、`--min-size`、`--webp`、`--year`、`--commit` 参数
- `lishuhang/img` 仓库: `.github/workflows/compress-images.yml`
  - push 触发：自动压缩新增图片
  - 手动触发：可指定 `min_size_kb` 和 `year_filter`
  - 自动 commit + push 压缩结果
- `convert_blog.py` / `convert_daily.py`: 上传前自动压缩图片
  - 新增 `compress_image_local()` / `compress_image_file()`
  - 工具不可用时静默跳过

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"2.0": {"blog", "daily"}`
- 版本号升级至 2.0
- 备份位置: `lishuhang/photos/0704_blog_backup/0704_blog_backup.zip`

**手动操作（一次性）:**
- 在 `lishuhang/img` 仓库手动触发 `Compress Images` workflow 压缩所有现有图片
  - 预计节省 15-40%（200-400MB），将仓库从 1.15GB 降到 ~700-900MB
  - 解决 GitHub Pages artifact 超 1GB 限制问题

### v1.9 (2026-07-03)

**修复:**
- `convert_blog.py` 部分微信文章正文无法提取的 bug (升级至 v3.2)
  - 原因：部分微信文章正文在 `<section>` 标签内而非 `<p>` 标签，且标题用 `<section>` 而非 `<h2>`/`<h3>`，导致 `detect_article_type` 因 `heading_count=0` 误判为短文，`convert_short_article` 的 `<p>` 遍历也找不到内容
  - 表现：发布到主博客的文章只有 front matter 和图片，正文缺失（如 `2026-06-25-zhong-guo-ban-mythos-bi-de.md` 仅 14 行，正文 4686 字全部丢失）
  - 修复：`convert_short_article` 在 `<p>` 提取结果过少（<100 字符）时回退从叶 `<section>` 提取文本；`convert_long_article` 新增 `section` 标签到 `find_all` 列表，处理叶 section 的文本
  - 跳过含"想跟作者进一步讨论本文"的 section（尾部推广）
- `cleanup_daily_from_blog.py` 分支探测 bug
  - 原因：v1.8 硬编码 `BLOG_REPO_BRANCH = "master"`，但 `lishuhang.github.io` 仓库默认分支是 `main`，导致清理脚本 404 失败
  - 修复：v1.9 改为自动探测分支（先查 `default_branch`，再试 main/master）
  - 改进匹配逻辑：增加文件名 pinyin 模式（`mei-ri-aigc`/`aigc-zao-bao`）+ "贴图" category/tags 匹配（v1.7 bug 将 AIGC 早报误标为 "贴图"）

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.9": {"blog"}`
- `keepitrun.py` v1.9 首次启动时自动调用 `cleanup_daily_from_blog.py` 清理之前误同步到主博客的 AIGC 早报内容（步骤 8/8）
- `convert_blog.py` 升级至 v3.2
- `cleanup_daily_from_blog.py` 支持自动探测分支 + 改进匹配
- 版本号升级至 1.9

### v1.8 (2026-07-02)

**新增:**
- `maliang_register.py` 子脚本：每天 03:00 自动注册马良生图账号
  - 交替访问 `gpt2.lishuhang.com` 和 `ai-image.lishuhang.workers.dev`
  - 链式邀请：每个新账号用上一个的邀请码注册
  - 邀请奖励自动回收（注册成功后等待 1.2s 刷新邀请人额度）
  - 账号信息滚动累积保存到同目录 `maliang_accounts.json`
  - 遇 IP 限制自动停止当日注册，标记该 Worker URL，等待次日
  - 默认每天 5 个（min=2, max=5），可通过 .env 中 `MALIANG_REGISTER_MIN`/`MAX` 调整
- `cleanup_daily_from_blog.py` 一次性清理脚本：
  - 扫描 `lishuhang/lishuhang.github.io` `_posts/` 目录
  - 删除 categories/tags/title 匹配 AIGC 早报的文件
  - 支持 `--dry-run` 预览和 `--verbose` 详细日志

**修复:**
- `convert_blog.py` 误纳 AIGC 早报合集的 bug
  - 原因：`ALBUMS` 列表中 `album_id=3793362825901522949`（原标 "贴图"）
    实际是 AIGC 早报专辑，与 `convert_daily.py` 的 `DEFAULT_ALBUM_ID` 完全相同
  - 影响：AIGC 早报被同步发布到主博客 lishuhang.me（应仅在 lishuhang.me/daily/ 显示）
  - 修复：从 `ALBUMS` 移除该条目，升级 convert_blog.py 至 v3.1
  - 现支持 7 个合集（原 8 个），如有真实"贴图"合集需另配 album_id

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.8": {"maliang_register", "blog"}`
- `keepitrun.py` 主调度器新增 03:00 马良生图注册任务
- 首次启动任务步骤从 6 步扩展为 7 步（新增步骤 7：马良生图注册）
- `.env.example` 新增马良生图配置字段
- 安装依赖新增 `python-dotenv`
- 版本号升级至 1.8

### v1.7 (2026-06-13)

**新增:**
- 重新启用 Unsplash 照片管理任务 (12:00, 每 3 天)
  - 新增 `unsplash_update.py` 脚本，使用官方 API 认证 (无需 Cookie)
  - 支持 Client-ID (Access Key) 公开读取 + Bearer Token 用户操作
  - 内置 Demo 等级速率限制 (50 请求/小时，脚本预留 40 次/小时)
  - 支持照片上传、收藏集管理、状态查询
  - 新增 .env.example 中 Unsplash 相关字段

### v1.6 (2026-06-13)

**新增:**
- blog/daily 文章归档机制：GitHub 同步成功后自动将本地 .md 和 images/ 移入 archived/

**修复:**
- 打包包含 .env 导致用户解压覆盖后 GitHub Token 丢失的问题
  - 发行包不再包含 .env，改为 .env.example 模板

### v1.5 (2026-06-12)

**修复:**
- photos_update.py: `api_get()` 增加 401 认证失败检测，输出友好提示而非原始 traceback
- keepitrun.py: blog 首次启动时不再默认使用 `album:diff`（8 合集全量遍历会超时 600s）
  - 无爬取记录时改为 `album:YYYYMMDD`（最近 30 天），大幅缩短首次执行时间
  - `album:diff` 仍可手动使用

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.5": {"blog", "photos_update"}`
- 版本号升级至 1.5

### v1.4 (2026-06-12)

**修复:**
- 所有子脚本添加 Windows 控制台 UTF-8 编码修复
  - 解决 emoji 输出导致的 `UnicodeEncodeError: 'charmap' codec can't encode character`
  - 受影响脚本: photos_update.py, convert_blog.py, convert_daily.py, getrss.py, keepitrun.py
  - 已有修复的脚本: combine-gemini.py, model-process.py (确认无问题)
- photos_update.py 纳入 keepitrun 发行包 (之前为外部脚本)

**变更:**
- `VERSION_TASK_CHANGES` 新增 `"1.4": {"photos_update"}`
- 版本号升级至 1.4

### v1.3 (2026-06-11)

- 版本感知任务完成追踪系统
- convert_daily.py 重新启用

### v1.2 (2026-06-11)

- 重新启用微信公众号文章抓取
- 使用合集API替代Cookie登录

### v1.1 (2026-06-10)

- 分级文件清理策略
- 子脚本日志统一到 logs/
- 去除文件名时间戳

### v1.0 (2026-04-20)

- 初始正式版本

## Agent Debug 指南

### 日志位置

- 主日志: `logs/YYYYMMDD.log`
- RSS 抓取日志: `logs/getrss_YYYYMMDD_HHMMSS.log`
- AIGC早报日志: `logs/daily_YYYYMMDD_HHMMSS.log`
- 微信文章日志: `logs/blog_YYYYMMDD_HHMMSS.log`
- 马良生图注册日志：嵌入主日志 `[maliang]` 前缀
- 任务完成记录: `logs/task_completion.json`

### 常见问题

**GitHub 认证失败 (401 Unauthorized)**
- 访问 https://github.com/settings/tokens 确认 Token 状态是否为 Active
- 检查 .env 文件中的 GITHUB_TOKEN 是否正确（无多余空格、引号、行内注释）
- 确认 Token 有 repo 完整读写权限
- 如果系统环境变量中设置了旧 GITHUB_TOKEN，优先级高于 .env 文件
- 可用 `curl -H "Authorization: token YOUR_TOKEN" https://api.github.com/user` 验证

**Photos 同步失败 (UnicodeEncodeError)**
- v1.4 已修复：所有子脚本已添加 UTF-8 编码重配置
- 如果仍然出现，确认运行的是 v1.4+ 版本的脚本

**Blog 首次启动超时**
- v1.5 已修复：首次启动不再使用 `album:diff`，改为抓取最近 30 天
- 如需全量对比，可手动运行 `python convert_blog.py album:diff`

**AIGC 早报被同步到主博客 (v1.8 已修复)**
- v1.8 修复：`convert_blog.py` 已移除误纳的 AIGC 早报专辑条目
- 如需清理之前误同步的内容，运行 `python cleanup_daily_from_blog.py --dry-run`
- 确认无误后运行 `python cleanup_daily_from_blog.py` 实际删除

**马良生图注册全部失败 (IP 限制)**
- 检查 `maliang_accounts.json` 中 `daily_stats` 的 `ip_limited_*` 字段
- 若两个 Worker URL 均被标记，需等待次日自动重置
- 或手动修改 JSON 删除 `ip_limited_*` 标记后重试
- 也可通过手动添加账号的方式补充（参考主脚本 UI 的"手动添加"按钮）

**RSS 抓取结果为空**
- 检查网络连接和 RSS 源 URL
- 确认 keywords.json 中的关键词是否过于狭窄

**合并翻译失败**
- 检查 Gemini API Key 是否有效
- 确认 tmp/ 中有 rss_*.md 文件

**版本升级后任务没有重做**
- 检查 logs/task_completion.json 中的版本记录
- 确认 VERSION_TASK_CHANGES 中是否包含对应的版本和任务

### 文件引用关系

```
keepitrun.py → getrss.py → keywords.json, rss_feeds.json
             → combine-gemini.py → tmp/rss_*.md
             → convert_daily.py → .env, 微信专辑 API (→ lishuhang/daily)
             → convert_blog.py → .env, 微信合集 API (→ lishuhang.github.io)
             → photos_update.py → .env (同目录或上级)
             → unsplash_update.py → .env (UNSPLASH_*)
             → maliang_register.py → .env (MALIANG_*), maliang_accounts.json
             → cleanup_daily_from_blog.py → .env (GITHUB_TOKEN, 一次性手动运行)
```
