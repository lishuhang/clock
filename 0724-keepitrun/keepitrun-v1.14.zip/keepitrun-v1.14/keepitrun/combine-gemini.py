#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
# google.generativeai imported lazily in v1.14
import time
import re
import locale
import argparse
import glob
import logging

# ================= 核心修复 =================
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())
# ===========================================

# 脚本所在目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 临时文件目录 (v1.1: 从 tmp/ 读取中间结果)
TMP_DIR = os.path.join(SCRIPT_DIR, "tmp")

# 日志目录 (v1.1: 统一日志到 logs/)
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# --- v1.14 翻译引擎配置 ---
# 从 .env 读取 API key，不再硬编码
def _load_dotenv():
    env_path = os.path.join(SCRIPT_DIR, ".env")
    if not os.path.isfile(env_path): return
    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line: continue
                key, _, val = line.partition("=")
                key = key.strip(); val = val.strip().strip('"').strip("'")
                if key and key not in os.environ: os.environ[key] = val
    except OSError: pass

_load_dotenv()

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GLM_API_KEY = os.environ.get("GLM_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
GLM_MODEL = os.environ.get("GLM_MODEL", "glm-4-flash")

generation_config = {
    "temperature": 0.3,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 8192,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

# --- 分类关键词配置 ---
COMPANY_MAP = {
    'NVIDIA': ['NVIDIA', '英伟达', 'Jensen Huang', 'Huang Renxun', '黄仁勋', 'GeForce', 'RTX', 'Blackwell', 'H100', 'H200', 'B100', 'B200', 'GB200', 'Rubin', 'CUDA', '显卡', 'GPU', 'Omniverse', 'Vera', 'X800'],
    'OpenAI': ['OpenAI', 'ChatGPT', 'GPT', 'Sora', 'Sam Altman', 'Altman', '奥特曼', 'Murati', 'DALL-E', 'O1', 'Strawberry', 'Q*', 'DevDay', 'SearchGPT', 'Canvas', 'Greg Brockman', 'Ilya'],
    'Google': ['Google', '谷歌', 'DeepMind', 'Gemini', 'Sundar Pichai', 'Demis Hassabis', 'Waymo', 'AlphaFold', 'Android', 'Pixel', 'TPU', 'DeepResearch', 'Veo', 'Imagen', 'Jarvis', 'Project Astra', 'NotebookLM'],
    'Microsoft': ['Microsoft', '微软', 'Copilot', 'Azure', 'Satya Nadella', 'Nadella', 'Windows', 'Xbox', 'Phi-3', 'Phi-4', 'Recall', 'Surface'],
    'Anthropic': ['Anthropic', 'Claude', 'Dario Amodei', 'Amodei', 'Constitutional AI'],
    'Apple': ['Apple', '苹果', 'iPhone', 'iPad', 'Mac', 'Siri', 'Tim Cook', 'Cook', 'M4', 'M5', 'A18', 'A19', 'Apple Intelligence', 'Vision Pro', 'Ferret', 'MM1'],
    'Meta': ['Meta', 'Facebook', 'Zuckerberg', 'Llama', 'Yann LeCun', 'LeCun', 'PyTorch', 'Ray-Ban', 'Orion', 'Quest', 'Threads', 'Instagram'],
    'xAI/Tesla': ['xAI', 'Grok', 'Musk', 'Elon Musk', '马斯克', 'Tesla', '特斯拉', 'Optimus', 'SpaceX', 'Starlink', 'Robotaxi', 'FSD'],
    'Amazon': ['Amazon', '亚马逊', 'AWS', 'Bedrock', 'Olympus', 'Rufus', 'Bezos', 'Jassy', 'Q '],
    'ByteDance': ['ByteDance', '字节', 'Doubao', '豆包', 'TikTok', 'Liang Rubo', 'Zhang Yiming', '张一鸣', 'Jimeng', '即梦', 'Seed-TTS'],
    'Alibaba': ['Alibaba', '阿里', 'Qwen', '通义', 'Tongyi', '千问', 'Joe Tsai', 'Eddie Wu', '蔡崇信', '吴泳铭', 'Wan', 'Animate Anyone'],
    'Baidu': ['Baidu', '百度', 'Ernie', '文心', 'Robin Li', '李彦宏', 'Apollo'],
    'Tencent': ['Tencent', '腾讯', 'Hunyuan', '混元', 'Pony Ma', '马化腾', 'WeChat'],
    'DeepSeek': ['DeepSeek', '深度求索', '幻方', 'Liang Wenfeng', '梁文锋', 'Fire-Flyer'],
    'Moonshot': ['Moonshot', '月之暗面', 'Kimi', 'Yang Zhilin', '杨植麟'],
    'MiniMax': ['MiniMax', '海螺', 'Hailuo', 'Yan Junjie', '闫俊杰', 'Video-01'],
    '01.AI': ['01.AI', '零一万物', 'Yi-Large', 'Yi-Pro', 'Lee Kai-fu', '李开复'],
    'Huawei': ['Huawei', '华为', 'Ascend', '昇腾', 'Kunpeng', '鲲鹏', 'HarmonyOS', '鸿蒙', 'Pura', 'Mate', 'CANN'],
    'Xiaomi': ['Xiaomi', '小米', 'Lei Jun', '雷军', 'SU7', 'HyperOS', 'XiaoAI', '小爱'],
    'SenseTime': ['SenseTime', '商汤', 'Xu Li', '徐立', 'SenseNova', '日日新', 'Vais'],
    'Adobe': ['Adobe', 'Photoshop', 'Firefly', 'Premiere'],
    'Midjourney/Stability': ['Midjourney', 'Stability', 'Stable Diffusion', 'Runway', 'Gen-2', 'Gen-3', 'Pika', 'Suno', 'Udio']
}

PRIORITY_ORDER = [
    'NVIDIA', 'OpenAI', 'Google', 'Microsoft', 'Apple', 'Meta', 'Anthropic', 
    'xAI/Tesla', 'Huawei', 'DeepSeek', 'ByteDance', 'Alibaba', 'Tencent', 
    'Baidu', 'Amazon', 'Moonshot', 'MiniMax', '01.AI', 'Xiaomi', 
    'SenseTime', 'Midjourney/Stability', 'Adobe'
]

# --- 辅助函数 ---

def parse_money_value(text):
    text = text.lower()
    RATE_USD = 7.2
    value = 0.0
    found = False
    
    usd_match = re.search(r'\$\s*(\d+(?:\.\d+)?)\s*([mbk]?)', text)
    if usd_match:
        num = float(usd_match.group(1))
        unit = usd_match.group(2)
        multiplier = 1
        if unit == 'k': multiplier = 1000
        elif unit == 'm': multiplier = 1000000
        elif unit == 'b': multiplier = 1000000000
        value = num * multiplier * RATE_USD
        found = True
        return found, value

    cny_match = re.search(r'(\d+(?:\.\d+)?)\s*(亿|万)', text)
    if cny_match:
        num = float(cny_match.group(1))
        unit = cny_match.group(2)
        multiplier = 1
        if unit == '万': multiplier = 10000
        elif unit == '亿': multiplier = 100000000
        value = num * multiplier
        found = True
        return found, value

    en_text_match = re.search(r'(\d+(?:\.\d+)?)\s*(million|billion)', text)
    if en_text_match:
        num = float(en_text_match.group(1))
        unit = en_text_match.group(2)
        multiplier = 1000000 if 'million' in unit else 1000000000
        value = num * multiplier * RATE_USD
        found = True
        return found, value

    return found, 0.0

def parse_news_list_file(filepath):
    header_lines = []
    content_lines = []
    footer_lines = []
    in_content = False

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if not lines: return None

        for line in lines:
            s_line = line.strip()
            if not s_line:
                continue
                
            if s_line.startswith("- ") or s_line.startswith("• "):
                in_content = True
                content_lines.append(s_line)
            else:
                if not in_content:
                    header_lines.append(line)
                else:
                    footer_lines.append(line)

        return header_lines, content_lines, footer_lines
    except Exception as e:
        print(f"Error parsing {filepath}: {e}")
        return None

def is_primarily_english(text):
    if not text: return False
    clean = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)
    clean = re.sub(r'[-`*#_~]', '', clean).strip()
    if not clean: return False
    ascii_count = sum(1 for c in clean if ord(c) < 128)
    return ascii_count / len(clean) > 0.8

def parse_markdown_link(line):
    match = re.match(r'^([-•]\s*)\[(.*?)\]\((.*?)\)(.*)$', line)
    if match:
        return match.group(1), match.group(2), match.group(3), match.group(4)
    
    match_no_link = re.match(r'^([-•]\s*)(.*)$', line)
    if match_no_link:
        return match_no_link.group(1), match_no_link.group(2), "", ""
        
    return "- ", line.lstrip("- ").lstrip("• "), "", ""

def translate_batch_gemini(api_key, model_name, texts):
    """v1.14: 使用 Gemini 翻译"""
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(model_name)
    
    prompt = (
        "Translate the following news headlines to Chinese. "
        "Maintain the original meaning but make it concise, professional, and suitable for a tech news briefing. "
        "Strictly output one translation per line, corresponding exactly to the input order. "
        "Do not include any numbering or bullet points in your output, just the translated text.\n\n"
    )
    for i, t in enumerate(texts):
        prompt += f"{i+1}. {t}\n"
    
    response = model.generate_content(prompt, generation_config=generation_config, safety_settings=safety_settings)
    if not response.parts or not response.text:
        raise Exception("Empty response from Gemini")
    
    lines = response.text.strip().split('\n')
    results = []
    for line in lines:
        line = re.sub(r'^\d+\.\s*', '', line.strip())
        line = re.sub(r'\*\*', '', line)
        line = line.lstrip("- ").lstrip("• ")
        if line: results.append(line)
    
    if len(results) != len(texts):
        raise Exception(f"Translation count mismatch: sent {len(texts)}, got {len(results)}")
    return results


def translate_batch_glm(api_key, model_name, texts):
    """v1.14: 使用 GLM (智谱) 翻译"""
    from zhipuai import ZhipuAI
    client = ZhipuAI(api_key=api_key)
    
    prompt = (
        "Translate the following news headlines to Chinese. "
        "Maintain the original meaning but make it concise, professional, and suitable for a tech news briefing. "
        "Strictly output one translation per line, corresponding exactly to the input order. "
        "Do not include any numbering or bullet points in your output, just the translated text.\n\n"
    )
    for i, t in enumerate(texts):
        prompt += f"{i+1}. {t}\n"
    
    response = client.chat.completions.create(
        model=model_name,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3,
        max_tokens=8192,
    )
    
    content = response.choices[0].message.content.strip()
    lines = content.split('\n')
    results = []
    for line in lines:
        line = re.sub(r'^\d+\.\s*', '', line.strip())
        line = re.sub(r'\*\*', '', line)
        line = line.lstrip("- ").lstrip("• ")
        if line: results.append(line)
    
    if len(results) != len(texts):
        raise Exception(f"Translation count mismatch: sent {len(texts)}, got {len(results)}")
    return results


def translate_batch(translator, texts):
    """v1.14: 统一翻译入口, translator = (engine, api_key, model_name)"""
    if not texts: return []
    engine, api_key, model_name = translator
    clean_texts = [t.lstrip("- ").lstrip("• ") for t in texts]
    
    if engine == "gemini":
        return translate_batch_gemini(api_key, model_name, clean_texts)
    elif engine == "glm":
        return translate_batch_glm(api_key, model_name, clean_texts)
    else:
        raise Exception(f"Unknown translator engine: {engine}")

def classify_and_sort_items(items):
    investment_items = []
    classified_buckets = {k: [] for k in PRIORITY_ORDER}
    unclassified = []
    
    invest_keywords_cn = ['融资', '获投', '筹资', '募资', '投资']
    invest_keywords_en = ['raised', 'funding', 'financing', 'series a', 'series b', 'seed round', 'invest']
    
    source_pattern = re.compile(r'\s*\([^)]*?\)$', re.IGNORECASE)

    for item in items:
        if not (item.startswith("- ") or item.startswith("• ")):
            item = "- " + item
            
        match = re.match(r'^[-•]\s*\[(.*?)\]\((.*?)\)(.*)$', item)
        if match:
            title_for_analysis = match.group(1)
        else:
            title_for_analysis = item[2:].strip()
            
        lower_content = title_for_analysis.lower()
        
        has_invest_kw = any(k in lower_content for k in invest_keywords_cn) or \
                        any(k in lower_content for k in invest_keywords_en)
        
        is_investment = False
        if has_invest_kw:
            has_money, money_val = parse_money_value(title_for_analysis)
            if has_money:
                investment_items.append({'text': item, 'value': money_val})
                is_investment = True
        
        if is_investment:
            continue
            
        clean_content = source_pattern.sub('', title_for_analysis).lower()
        assigned = False
        for company in PRIORITY_ORDER:
            keywords = COMPANY_MAP.get(company, [])
            if any(k.lower() in clean_content for k in keywords):
                classified_buckets[company].append(item)
                assigned = True
                break
        
        if not assigned:
            unclassified.append(item)

    final_output = []
    
    if investment_items:
        investment_items.sort(key=lambda x: x['value'], reverse=True)
        final_output.extend([x['text'] for x in investment_items])
        final_output.append("")

    for company in PRIORITY_ORDER:
        bucket = classified_buckets[company]
        if bucket:
            try: bucket.sort(key=locale.strxfrm)
            except: bucket.sort()
            final_output.extend(bucket)
            final_output.append("")
            
    if unclassified:
        try: unclassified.sort(key=locale.strxfrm)
        except: unclassified.sort()
        final_output.extend(unclassified)
    
    while final_output and final_output[-1] == "":
        final_output.pop()
        
    return final_output

def main():
    parser = argparse.ArgumentParser(description="Merge, Translate and Categorize RSS MD files.")
    parser.add_argument('files', nargs='+', help='Input markdown files')
    parser.add_argument('-api', help='Gemini API Key (overrides .env)', default=None)
    parser.add_argument('-engine', choices=['gemini', 'glm', 'auto'], default='auto',
                        help='Translation engine: gemini, glm, or auto (try gemini first, fallback to glm)')
    args = parser.parse_args()

    # v1.14: 初始化翻译引擎
    # 优先级: -api 参数 > GEMINI_API_KEY (.env) > GLM_API_KEY (.env)
    gemini_key = args.api if args.api else GEMINI_API_KEY
    translator = None
    translator_engine = None

    if args.engine in ('gemini', 'auto') and gemini_key:
        try:
            import google.generativeai as genai
            genai.configure(api_key=gemini_key)
            m = genai.GenerativeModel(GEMINI_MODEL)
            # 快速测试
            m.generate_content("Say OK")
            translator = ("gemini", gemini_key, GEMINI_MODEL)
            translator_engine = "gemini"
            print(f"✓ Gemini engine ready (model: {GEMINI_MODEL})")
        except Exception as e:
            print(f"✗ Gemini init failed: {e}")
            if args.engine == "gemini":
                print("  (forced gemini mode, not falling back)")
    
    if translator is None and args.engine in ('glm', 'auto') and GLM_API_KEY:
        try:
            from zhipuai import ZhipuAI
            client = ZhipuAI(api_key=GLM_API_KEY)
            client.chat.completions.create(
                model=GLM_MODEL,
                messages=[{"role": "user", "content": "Say OK"}],
                max_tokens=10,
            )
            translator = ("glm", GLM_API_KEY, GLM_MODEL)
            translator_engine = "glm"
            print(f"✓ GLM engine ready (model: {GLM_MODEL})")
        except Exception as e:
            print(f"✗ GLM init failed: {e}")

    if translator is None:
        print("⚠ No translation engine available. Set GEMINI_API_KEY or GLM_API_KEY in .env")
        print("  .env format:")
        print("  GEMINI_API_KEY=AIza...")
        print("  GLM_API_KEY=your_glm_key...")

    all_content_lines = set()
    first_header = []
    first_footer = []
    
    for i, fpath in enumerate(args.files):
        # v1.1: 先尝试在 tmp/ 中查找，再在脚本目录查找
        full_path = os.path.join(TMP_DIR, fpath)
        if not os.path.isfile(full_path):
            full_path = os.path.join(SCRIPT_DIR, fpath)
        
        parsed = parse_news_list_file(full_path)
        if not parsed: continue
        h, c, f = parsed
        if i == 0:
            first_header = h
            first_footer = f
        
        for line in c:
            all_content_lines.add(line)

    print(f"Total unique lines loaded: {len(all_content_lines)}")

    cn_lines = []
    en_lines = []
    for line in all_content_lines:
        content_only = re.sub(r'^[-•]\s*', '', line)
        if is_primarily_english(content_only):
            en_lines.append(line)
        else:
            cn_lines.append(line)

    print(f"Chinese lines: {len(cn_lines)}, English lines: {len(en_lines)}")

    translated_lines = []
    translation_failed = False
    
    if en_lines and translator:
        print(f"Starting translation using {translator_engine}...")
        batch_size = 20
        for i in range(0, len(en_lines), batch_size):
            batch = en_lines[i:i+batch_size]
            
            batch_titles = []
            batch_meta = []
            for line in batch:
                prefix, title, url, suffix = parse_markdown_link(line)
                batch_titles.append(title)
                batch_meta.append((prefix, url, suffix))
                
            try:
                print(f"Translating batch {i//batch_size + 1} (Items: {len(batch)})...")
                results = translate_batch(translator, batch_titles)
                
                for j, translated_title in enumerate(results):
                    prefix, url, suffix = batch_meta[j]
                    if url:
                        reconstructed = f"- [{translated_title}]({url}){suffix}"
                    else:
                        reconstructed = f"- {translated_title}{suffix}"
                    translated_lines.append(reconstructed)
                    
                time.sleep(1.5) 
            except Exception as e:
                print(f"× Translation failed (stopping translation): {e}")
                # v1.14: 如果 gemini 失败，尝试回退到 glm
                if translator_engine == "gemini" and args.engine == "auto" and GLM_API_KEY:
                    print("  Attempting fallback to GLM...")
                    try:
                        from zhipuai import ZhipuAI
                        client = ZhipuAI(api_key=GLM_API_KEY)
                        client.chat.completions.create(
                            model=GLM_MODEL,
                            messages=[{"role": "user", "content": "Say OK"}],
                            max_tokens=10,
                        )
                        translator = ("glm", GLM_API_KEY, GLM_MODEL)
                        translator_engine = "glm"
                        print(f"  ✓ Fallback to GLM successful, retrying batch...")
                        results = translate_batch(translator, batch_titles)
                        for j, translated_title in enumerate(results):
                            prefix, url, suffix = batch_meta[j]
                            if url:
                                reconstructed = f"- [{translated_title}]({url}){suffix}"
                            else:
                                reconstructed = f"- {translated_title}{suffix}"
                            translated_lines.append(reconstructed)
                        time.sleep(1.5)
                        continue
                    except Exception as e2:
                        print(f"  ✗ GLM fallback also failed: {e2}")
                translation_failed = True
                break
    elif en_lines and not translator:
        print("Skipping translation (No API Key or engine init failed)")
        translation_failed = True

    output_body = []
    
    if not translation_failed:
        combined = cn_lines + translated_lines
        output_body = classify_and_sort_items(combined)
    else:
        print("！ Entering fallback mode: separating Chinese and English.")
        cn_sorted = classify_and_sort_items(cn_lines)
        en_sorted = classify_and_sort_items(en_lines)
        output_body.extend(cn_sorted)
        if cn_sorted and en_sorted:
            output_body.append("")
            output_body.append("--- English Content (Translation Skipped) ---")
            output_body.append("")
        output_body.extend(en_sorted)

    # v1.1: 最终输出文件保存在脚本根目录 (非 tmp/)
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    output_filename = os.path.join(SCRIPT_DIR, f"{timestamp}.md")
    
    with open(output_filename, 'w', encoding='utf-8') as f:
        if first_header:
            f.writelines(first_header)
            if not first_header[-1].endswith('\n'): f.write('\n')
        for line in output_body:
            f.write(line + "\n")
        if first_footer:
            if output_body and output_body[-1].strip(): f.write('\n')
            f.writelines(first_footer)

    print(f"√ Process complete. Saved to: {output_filename}")

if __name__ == "__main__":
    main()
