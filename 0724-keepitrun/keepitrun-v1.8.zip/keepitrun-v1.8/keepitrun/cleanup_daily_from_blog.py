#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cleanup_daily_from_blog.py - 一次性清理脚本 (v1.8 配套)

用途：
  清理之前因 convert_blog.py bug 误同步到主博客 lishuhang.me 的 AIGC 早报内容。
  AIGC 早报应仅在 lishuhang.me/daily/ 显示（由 convert_daily.py 发布到
  lishuhang/daily 仓库），不应出现在主博客 lishuhang.github.io 仓库。

工作流程：
  1. 列出 lishuhang/lishuhang.github.io 仓库 _posts/ 目录下所有 .md 文件
  2. 逐个读取文件内容，检查 front matter 中：
     - categories 包含 "AIGC日报" 或 "AIGC"
     - 或 tags 包含 "AIGC"
     - 或标题包含 "AIGC 早报" / "每日 AIGC"
  3. 匹配的文件通过 GitHub API 删除（commit message 标注清理原因）
  4. 输出清理报告（删除了哪些文件、跳过了哪些文件）

用法:
  python cleanup_daily_from_blog.py                # 执行清理
  python cleanup_daily_from_blog.py --dry-run      # 仅列出待删除文件，不实际删除
  python cleanup_daily_from_blog.py --verbose      # 详细日志

环境变量 (.env):
  GITHUB_TOKEN  - GitHub Personal Access Token（需 repo 权限）

注意：
  - 此脚本为一次性清理工具，运行后即可删除
  - 删除操作不可恢复，建议先 --dry-run 确认
  - 只清理 lishuhang.github.io 仓库，不影响 lishuhang/daily 仓库
"""

import os
import sys
import re
import json
import argparse
import requests
from datetime import datetime

# ================= Windows 编码修复 =================
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except AttributeError:
        import codecs
        sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())
        sys.stderr = codecs.getwriter("utf-8")(sys.stderr.detach())

# ================= 配置 =================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# 主博客仓库（AIGC 早报误同步到这里）
BLOG_REPO = "lishuhang/lishuhang.github.io"
BLOG_REPO_POSTS_PATH = "_posts"
BLOG_REPO_BRANCH = "master"  # 主博客仓库分支

# 匹配 AIGC 早报的判断关键词
AIGC_CATEGORY_PATTERNS = [
    r'AIGC日报',
    r'AIGC\s*早报',
]
AIGC_TAG_PATTERNS = [
    r'\bAIGC\b',
]
AIGC_TITLE_PATTERNS = [
    r'AIGC\s*早报',
    r'每日\s*AIGC',
]

GITHUB_API_BASE = "https://api.github.com"


def load_env():
    """加载同目录 .env 文件"""
    env_path = os.path.join(SCRIPT_DIR, ".env")
    if not os.path.isfile(env_path):
        return
    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = val
    except OSError:
        pass


def github_request(method, path, token, json_body=None, raw=False):
    """发送 GitHub API 请求"""
    url = f"{GITHUB_API_BASE}{path}"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }
    try:
        resp = requests.request(
            method, url, headers=headers,
            json=json_body, timeout=30
        )
        if resp.status_code in (200, 201):
            return resp.json() if not raw else resp.content, None
        elif resp.status_code == 404:
            return None, "not found"
        elif resp.status_code == 401:
            return None, "认证失败 (401)：检查 GITHUB_TOKEN 是否有效"
        elif resp.status_code == 403:
            return None, f"权限不足或触发限流 (403): {resp.text[:200]}"
        else:
            return None, f"HTTP {resp.status_code}: {resp.text[:200]}"
    except requests.RequestException as e:
        return None, str(e)


def list_posts(token, verbose=False):
    """列出 _posts 目录下所有 .md 文件"""
    # GitHub API 一次最多 1000 个，分页获取
    all_files = []
    page = 1
    while True:
        path = f"/repos/{BLOG_REPO}/contents/{BLOG_REPO_POSTS_PATH}?ref={BLOG_REPO_BRANCH}&per_page=100&page={page}"
        result, err = github_request("GET", path, token)
        if err:
            if "not found" in err:
                # 可能 _posts 不存在或仓库为空
                return [], None
            return None, err
        if not isinstance(result, list):
            return None, f"意外的响应类型: {type(result)}"
        all_files.extend(result)
        if len(result) < 100:
            break
        page += 1
        if page > 20:  # 最多 2000 个文件
            break
    if verbose:
        print(f"[INFO] _posts/ 目录共找到 {len(all_files)} 个文件")
    return all_files, None


def get_file_content(file_info, token):
    """读取文件内容（解析 base64）"""
    # file_info 中已包含 content 字段（base64 编码）
    import base64
    content_b64 = file_info.get("content", "")
    if not content_b64:
        return ""
    try:
        return base64.b64decode(content_b64).decode("utf-8", errors="replace")
    except Exception:
        return ""


def is_aigc_daily_post(filename, content, verbose=False):
    """判断文件是否为 AIGC 早报"""
    # 1. 文件名模式匹配 (e.g., 2026-06-01-aigc-daily.md, 2026-06-01-每日aigc早报.md)
    fn_lower = filename.lower()
    if "aigc" in fn_lower or "早报" in filename:
        if verbose:
            print(f"  [MATCH filename] {filename}")
        return True

    # 2. 解析 front matter
    fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if fm_match:
        fm = fm_match.group(1)

        # 检查 categories
        cat_match = re.search(r'^categories:\s*(.+?)$', fm, re.MULTILINE)
        if cat_match:
            cat_val = cat_match.group(1).strip()
            for pat in AIGC_CATEGORY_PATTERNS:
                if re.search(pat, cat_val, re.IGNORECASE):
                    if verbose:
                        print(f"  [MATCH categories={cat_val}] {filename}")
                    return True

        # 检查 tags (可能是 [a, b] 或 - a 形式)
        tag_section_match = re.search(r'^tags:\s*(.*?)$', fm, re.MULTILINE)
        if tag_section_match:
            tag_val = tag_section_match.group(1).strip()
            # 数组形式 [a, b]
            if tag_val.startswith("["):
                for pat in AIGC_TAG_PATTERNS:
                    if re.search(pat, tag_val, re.IGNORECASE):
                        if verbose:
                            print(f"  [MATCH tags={tag_val}] {filename}")
                        return True
            else:
                # 多行 - a / - b 形式，需要继续读取
                pass

        # 多行 tags
        tag_multi = re.findall(r'^-\s+(.+?)$', fm, re.MULTILINE)
        for tag in tag_multi:
            for pat in AIGC_TAG_PATTERNS:
                if re.search(pat, tag, re.IGNORECASE):
                    if verbose:
                        print(f"  [MATCH tags item={tag}] {filename}")
                    return True

    # 3. 标题检查
    title_match = re.search(r'^title:\s*["\']?(.+?)["\']?\s*$', content, re.MULTILINE)
    if title_match:
        title = title_match.group(1)
        for pat in AIGC_TITLE_PATTERNS:
            if re.search(pat, title, re.IGNORECASE):
                if verbose:
                    print(f"  [MATCH title={title}] {filename}")
                return True

    return False


def delete_file(file_info, token, reason="v1.8 cleanup: 移除误同步的 AIGC 早报"):
    """通过 GitHub API 删除文件"""
    path = file_info.get("path", "")
    sha = file_info.get("sha", "")
    if not path or not sha:
        return False, "缺少 path 或 sha"

    body = {
        "message": f"cleanup: {reason} - {os.path.basename(path)}",
        "sha": sha,
        "branch": BLOG_REPO_BRANCH,
    }
    _, err = github_request("DELETE", f"/repos/{BLOG_REPO}/contents/{path}", token, json_body=body)
    if err:
        return False, err
    return True, ""


def main():
    parser = argparse.ArgumentParser(
        description="清理主博客 lishuhang.github.io 中误同步的 AIGC 早报内容"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="仅列出待删除文件，不实际删除"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="详细日志"
    )
    args = parser.parse_args()

    load_env()
    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if not token:
        print("[ERROR] 未设置 GITHUB_TOKEN 环境变量")
        print("  请在 .env 文件中配置：GITHUB_TOKEN=ghp_xxxxx")
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"AIGC 早报清理脚本 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"目标仓库: {BLOG_REPO}")
    print(f"目标路径: {BLOG_REPO_POSTS_PATH}/ (branch: {BLOG_REPO_BRANCH})")
    print(f"模式: {'DRY-RUN (仅列出)' if args.dry_run else '实际删除'}")
    print(f"{'=' * 60}\n")

    # 1. 列出所有 .md 文件
    print("[1/3] 列出 _posts/ 目录下所有 .md 文件...")
    files, err = list_posts(token, verbose=args.verbose)
    if err:
        print(f"[ERROR] 列出文件失败: {err}")
        sys.exit(1)

    md_files = [f for f in files if f.get("name", "").endswith(".md")]
    print(f"  共 {len(md_files)} 个 .md 文件")

    # 2. 逐个检查是否为 AIGC 早报
    print("\n[2/3] 检查每个文件是否为 AIGC 早报...")
    to_delete = []
    skipped = []

    for i, f in enumerate(md_files, 1):
        name = f.get("name", "")
        path = f.get("path", "")
        if args.verbose:
            print(f"  [{i}/{len(md_files)}] 检查: {name}")

        content = get_file_content(f, token)
        if not content:
            skipped.append((name, "无法读取内容"))
            continue

        if is_aigc_daily_post(name, content, verbose=args.verbose):
            to_delete.append(f)
            print(f"  [MATCH] {name} → 待删除")

    print(f"\n  匹配 AIGC 早报: {len(to_delete)} 个")
    print(f"  跳过: {len(skipped)} 个")

    if not to_delete:
        print("\n[OK] 没有需要清理的 AIGC 早报文件")
        sys.exit(0)

    # 3. 删除文件
    print(f"\n[3/3] {'列出待删除文件' if args.dry_run else '删除文件'}...")
    success_count = 0
    fail_count = 0

    for i, f in enumerate(to_delete, 1):
        name = f.get("name", "")
        path = f.get("path", "")
        print(f"  [{i}/{len(to_delete)}] {name}")

        if args.dry_run:
            print(f"      [DRY-RUN] 将删除: {path}")
            success_count += 1
            continue

        ok, err = delete_file(f, token)
        if ok:
            print(f"      [OK] 已删除")
            success_count += 1
            # GitHub API 限流：每秒 1 个请求左右
            import time
            time.sleep(1.0)
        else:
            print(f"      [FAIL] {err}")
            fail_count += 1
            import time
            time.sleep(2.0)

    # 汇总
    print(f"\n{'=' * 60}")
    print(f"清理完成 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"成功: {success_count} / 失败: {fail_count}")
    if args.dry_run:
        print("(DRY-RUN 模式，未实际删除)")
    else:
        print(f"已从 {BLOG_REPO} 的 {BLOG_REPO_POSTS_PATH}/ 移除 AIGC 早报内容")
        print(f"AIGC 早报今后仅在 lishuhang.me/daily/ 显示")
    print(f"{'=' * 60}\n")

    sys.exit(0 if fail_count == 0 else 1)


if __name__ == "__main__":
    main()
